from decimal import Decimal

v1 = Decimal("100")
v2 = Decimal("140")
v3 = v1 + 100
