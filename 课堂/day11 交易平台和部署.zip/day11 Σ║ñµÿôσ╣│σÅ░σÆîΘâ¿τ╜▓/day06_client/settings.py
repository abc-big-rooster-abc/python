REDIS_PARAMS = {
    "host": '127.0.0.1',
    "port": "6379",
    "password": 'qwe123',
    "encoding": 'utf-8'
}

QUEUE_TASK_NAME = "YANG_TASK_QUEUE"

MYSQL_CONN_PARAMS = {
    'host': "127.0.0.1",
    'port': 3306,
    'user': 'root',
    'passwd': "root123",
    'charset': "utf8",
    'db': "day06",
}
