from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.request import Request
from rest_framework import serializers
from rest_framework.authentication import BaseAuthentication
from rest_framework import exceptions
from ext import ret
from base import models
from utils.encrypt import md5
from utils.jwt_auth import create_token, parse_payload


class LoginSerializer(serializers.Serializer):
    mobile = serializers.CharField(required=True)
    password = serializers.CharField(required=True)

    def validate_password(self, value):
        md5_string = md5(value)
        return md5_string


class LoginView(APIView):
    """ 用户登录 """

    def post(self, request):
        # 1.数据格式校验（不为空）
        print(request.data)
        ser = LoginSerializer(data=request.data)
        # ser.is_valid(raise_exception=True)
        if not ser.is_valid():
            print(ser.errors)
            return Response({"code": ret.FIELD_ERROR, 'msg': "error", 'detail': ser.errors})

        # 2.数据库合法性校验 print(ser.data) # {user,pwd,}  mobile  password
        # 18630087660  root123
        # print(ser.data)
        instance = models.Company.objects.filter(**ser.data).first()

        # 2.1 登录失败
        if not instance:
            return Response({"code": ret.SUMMARY_ERROR, 'msg': "用户名或密码错误"})

        # 2.2 登录成功，返回用户信息
        token = create_token({'user_id': instance.id, 'name': instance.name})
        return Response({"code": ret.SUCCESS, 'msg': "success", 'data': {"token": token, 'name': instance.name}})


class JwtAuthentication(BaseAuthentication):
    def authenticate(self, request):
        """
        Authenticate the request and return a two-tuple of (user, token).
        """
        if request.method == "OPTIONS":
            return
        # raise NotImplementedError(".authenticate() must be overridden.")
        # 1.读取请求头中的token
        authorization = request.META.get('HTTP_AUTHORIZATION', '')
        print(authorization)

        # 2.token校验
        # {'user_id': instance.id, 'name': instance.name}
        status, info_or_error = parse_payload(authorization)

        # 3.校验失败，返回失败信息，前端重新登录
        if not status:
            raise exceptions.AuthenticationFailed({"code": 8888, 'msg': info_or_error})

        # 4.校验成功，继续向后  request.user  request.auth
        return (info_or_error, authorization)

    def authenticate_header(self, request):
        """
        Return a string to be used as the value of the `WWW-Authenticate`
        header in a `401 Unauthenticated` response, or `None` if the
        authentication scheme should return `403 Permission Denied` responses.
        """
        return 'Basic realm="API"'


class BasicView(APIView):
    authentication_classes = [JwtAuthentication, ]

    def get(self, request):
        print(request.data)
        print(request.user)
        print(request.auth)
        return Response({"code": ret.SUCCESS, 'msg': "success"})
