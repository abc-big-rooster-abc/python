import jwt
import datetime
from jwt import exceptions

SALT = 'iv%x6xo7l7_u9bf_u!9#g#m*)*=ej@bek5)(@u3kh*72+unjv='


def create_token():
    # 构造header
    headers = {
        'typ': 'jwt',
        'alg': 'HS256'
    }

    # 构造payload
    payload = {
        'user_id': 1,  # 自定义用户ID
        'username': 'wupeiqi',  # 自定义用户名
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=5)  # 超时时间
    }

    result = jwt.encode(payload=payload, key=SALT.encode('utf-8'), algorithm="HS256", headers=headers)
    return result


if __name__ == '__main__':
    # eyJhbGciOiJIUzI1NiIsInR5cCI6Imp3dCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6Ind1cGVpcWkiLCJleHAiOjE2Njk1NDM2Nzd9.i7A8yQZo2CWvot_BbDwDKf8fdHQ-XymTY9W0ss1plvM
    token = create_token()
    print(token)
