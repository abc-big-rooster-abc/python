# day22 供应链系统



# 1.内容回顾

- 前端项目创建

  ```
  - vue项目
  - vuex/router/axios...
  - 基本配置
  ```

- 路由的设计

  ```
  - APP.vue
  	<router-link/>登录<router-link/>
  	<router-link/>注册<router-link/>
  	<router-view></router-view>
  - LoginView.vue
  - RegisterView.vue
  - FrontView.vue
  	<router-link/>菜单1<router-link/>
  	<router-link/>菜单2<router-link/>
  	<router-view></router-view>
  - AuthView.vue
  - BasicView.vue
  ```

  ```javascript
  {
      {name:"Login",..LoginView.vue.}
      {name:"Register",..RegisterView.vue.}
      {name:"Front",..FrontView.vue,children:{
      	{name:"Auth",..AuthView.vue.}
  	    {name:"Basic",..BasicView.vue.}
      }}
  }
  ```

  小问题：默认选中菜单的设计。

- 表单（展示 + 前端校验 + 后端校验）

  ```vue
  <template>
  	<div>
          <el-form size="large" :model="userModel" :rules="userRules" ref="userRef">
              <el-form-item  prop="mobile" :error="userError.mobile">
                  <el-input v-model="userModel.mobile" placeholder="手机号"/>
      </el-form-item>
              <el-form-item  prop="password" :error="userError.password">
                  <el-input v-model="userModel.password" placeholder="密码"/>
      </el-form-item>
              <el-form-item>
                  <el-button @click="doPwdLogin" type="primary">登 录</el-button>
      </el-form-item>
      </el-form>
      </div>
  </template>
  
  <script setup>
  import {ref, reactive, getCurrentInstance} from 'vue'
  const userModel = reactive({
      mobile: '18630087660',
      password: 'root123',
  })
  const userRules = reactive({
      mobile: [
          {required: true, message: '手机不能为空', trigger: 'blur'},
      ],
  })
  const userError = reactive({
      mobile: '',
      password: '',
  })
  
  </script>
  ```

  ```vue
  <template>
  	<div>
          <el-form size="large" :model="userModel">
              <el-form-item  :error="userError.mobile">
                  <el-input v-model="userModel.mobile" placeholder="手机号"/>
      </el-form-item>
              <el-form-item :error="userError.password">
                  <el-input v-model="userModel.password" placeholder="密码"/>
      </el-form-item>
              <el-form-item>
                  <el-button @click="doPwdLogin" type="primary">登 录</el-button>
      </el-form-item>
      </el-form>
      </div>
  </template>
  
  <script setup>
  import {ref, reactive, getCurrentInstance} from 'vue'
  const userModel = reactive({
      mobile: '18630087660',
      password: 'root123',
  })
  const userError = reactive({
      mobile: '',
      password: '',
  })
  
  </script>
  ```

  思考题：页面初始化请求获取结果，设置给model

  ```vue
  <template>
  	<div>
          <el-form size="large" :model="state.userModel">
              <el-form-item  :error="state.userError.mobile">
                  <el-input v-model="state.userModel.mobile" placeholder="手机号"/>
      </el-form-item>
              <el-form-item :error="state.userError.password">
                  <el-input v-model="state.userModel.password" placeholder="密码"/>
      </el-form-item>
              <el-form-item>
                  <el-button @click="doPwdLogin" type="primary">登 录</el-button>
      </el-form-item>
      </el-form>
      </div>
  </template>
  
  <script setup>
  import {ref, reactive, getCurrentInstance} from 'vue'
  const state = reactive({
      userModel:{
          mobile: '18630087660',
          password: 'root123',
      },
      userError:{
          mobile: '',
          password: '',
      }
  })
      
  function initRequest(){
      proxy.$axios.get(....).then((res)=>{
          // res.data.data    {"mobile:999,password:123}
          state.userModel = res.data.data; // 
      })
  }
  initRequest();
  </script>
  ```

- 前端校验：单独字段校验 + 整体校验 + 主动单独校验

  ```javascript
  //调用rules中的设置的规则
  proxy.$refs.userRef.validate((valid) => {
      // 校验失败
      if (!valid) {
          console.log("校验失败");
          return false;
      }
  
      // 校验成功，发送网络请求（基于axios发送）
      console.log("校验成功", userModel)
  });
  ```

  ```javascript
  //调用rules中的设置的规则
  proxy.$refs.userRef.validateField("mobile",(valid)=>{
      // 校验失败
      if (!valid) {
          console.log("校验失败");
          return false;
      }
      // 校验成功，发送网络请求（基于axios发送）
      console.log("校验成功", userModel)
  })
  ```

- 后端

  - 跨域，用cors解决跨域

    ```
    本质：返回数据时候设置响应头。
    我们：编写django的中间件在相应数据数据时，给他设置相应响应头的内容：网址、方法、请求头
    
    扩展：简单请求和复杂请求
    	- 简单，直接发送。
    	- 复杂，预检OPTIONS，真正的请求。
    	
    其他方式解决跨域：JSONP，只能发送GET请求的跨域。
    ```

  - jwt token + 传统token

    ```
    本质：jwt，算法+数据   ->  校验时不要经过数据库
    ...
    ```

  - drf...

- 前端：拦截器

  - 路由拦截器（导航守卫）
  - axios拦截器



# 2.短信登录

- 发送短信验证码
  - 前端校验
  - API 
    - 后端校验
    - 发短信接口（腾讯短信）
    - redis实现短信存储 + 过期
- 手机+短信登录
  - 前端校验
  - 后端校验（钩子）
  - 生成jwt token

详见示例：`src-1.zip`      `dahe-1.zip`



# 3.注册

- 前端校验（自定义校验）
- 提交数据
  - 接收数据
  - 格式校验 （手机号不存在、密码重复）
  - 保存到数据库（ModelSerilszer）
  - 返回
- 前端跳转登录界面



详见示例：`src-2.zip`      `dahe-2.zip`



# 4.代码的整理



## 4.1 前端

详见示例：`src-3.zip`    

## 4.2 后端

详见示例：  `dahe-3.zip`



# 5.基本信息

- 展示数据
- 修改数据
  - 名称，对话框
  - 手机号，对话框



## 5.1 展示数据

- 页面

- 加载页面发送请求 + 获取数据 + 显示

- 问题：

  - 认证成功后访问，认证  

    ```
    request.user    {'user_id': 1, 'name': '大和实业', 'exp': 1670212872}
    ```

  - 只能看自己的请求，自定义筛选条件

    ```
    filter
    ```



详见示例：`src-4.zip`        `dahe-4.zip`





## 5.3 更新数据

![image-20221204181849552](assets/image-20221204181849552.png)



详见示例：`src-5.zip`        `dahe-5.zip`



# 6.账号认证

- 页面的开发
  - 图片
  - 上传
- 交互
  - 初始页面请求
  - 图片上传请求（百度AI接口）
  - 提交审核





## 6.1 页面

![image-20221204182707676](assets/image-20221204182707676.png)



![image-20221204182729088](assets/image-20221204182729088.png)





详见示例：`src-6.zip`        `dahe-6.zip`





# 7.课下

- 认证功能，自己去实现。

- 支付宝支付 / 转账

  ```
  https://opendocs.alipay.com/common/02kkv7
  
  支付：https://opendocs.alipay.com/open/028r8t?scene=22
  提现：https://opendocs.alipay.com/open/02byuo?ref=api&scene=ca56bca529e64125a2786703c6192d41
  ```

  























































