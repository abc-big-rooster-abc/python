SUCCESS = 0
ERROR = -3

# 字段校验失败，错误返回码（表单提示）
FIELD_ERROR = -1

# 整体校验，错误返回码（messagebox提示）
SUMMARY_ERROR = -2

# 对象不存在
NOT_FOUND = -4
