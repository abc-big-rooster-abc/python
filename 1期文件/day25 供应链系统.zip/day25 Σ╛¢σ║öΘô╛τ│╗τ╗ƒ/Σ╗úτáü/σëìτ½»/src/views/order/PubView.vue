<template>
    <el-card class="box-card" shadow="never" style="min-width: 1120px">
        <template #header>
            <div class="card-header">
                <span style="font-weight: bold;font-size: 18px;">发布运单</span>
            </div>
        </template>

        <div style="padding: 0 20px;">
            <div>
                <h4 style="margin: 5px;">地址信息</h4>
                <el-row :gutter="30">
                    <el-col :span="12">
                        <h5 style="display: flex;align-items: center;">
                            <el-icon color="#0088f5" size="24">
                                <Location/>
                            </el-icon>
                            发货地
                        </h5>

                        <el-form label-width="80px" style="max-width: 500px;">
                            <el-form-item label="发货地址" :error="state.formError.from_addr">
                                <el-input v-model="state.form.from_addr">
                                    <template #append>
                                        <el-button style="font-weight: 400;" @click="showAddressTable('from')">
                                            地址库
                                        </el-button>
                                    </template>
                                </el-input>
                            </el-form-item>

                            <el-row :gutter="10">
                                <el-col :span="10">
                                    <el-form-item label="发货人" :error="state.formError.from_name">
                                        <el-input v-model="state.form.from_name"/>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="14">
                                    <el-form-item label-width="10" :error="state.formError.from_mobile">
                                        <el-input v-model="state.form.from_mobile"/>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-form-item label="发货时间" :error="state.formError.from_date">
                                <el-date-picker
                                    v-model="state.form.from_date"
                                    type="date"
                                    placeholder="计划发货时间"
                                    :disabled-date="disabledDate"
                                    :shortcuts="shortcuts"
                                    format="YYYY-MM-DD"
                                    value-format="YYYY-MM-DD"
                                    style="width: 100%"
                                />
                            </el-form-item>
                        </el-form>
                    </el-col>
                    <el-col :span="12">
                        <h5 style="display: flex;align-items: center;">
                            <el-icon color="#ff6772" size="24">
                                <Location/>
                            </el-icon>
                            收货地
                        </h5>

                        <el-form label-width="80px" style="max-width: 500px;">
                            <el-form-item label="收货地址" :error="state.formError.to_addr">
                                <el-input v-model="state.form.to_addr">
                                    <template #append>
                                        <el-button style="font-weight: 400;" @click="showAddressTable('to')">地址库
                                        </el-button>
                                    </template>
                                </el-input>
                            </el-form-item>

                            <el-row :gutter="10">
                                <el-col :span="10">
                                    <el-form-item label="收货人" :error="state.formError.to_name">
                                        <el-input v-model="state.form.to_name"/>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="14">
                                    <el-form-item label-width="10" :error="state.formError.to_mobile">
                                        <el-input v-model="state.form.to_mobile"/>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-form-item label="收货时间" :error="state.formError.to_date">
                                <el-date-picker
                                    v-model="state.form.to_date"
                                    type="date"
                                    placeholder="计划发货时间"
                                    :disabled-date="disabledDate"
                                    :shortcuts="shortcuts"
                                    format="YYYY-MM-DD"
                                    value-format="YYYY-MM-DD"
                                    style="width: 100%"
                                />
                            </el-form-item>
                        </el-form>


                    </el-col>
                </el-row>
            </div>
            <el-divider border-style="dotted"/>
            <div>
                <h4 style="margin-bottom: 20px;">货物信息</h4>
                <el-form label-width="110px">
                    <el-row :gutter="50">
                        <el-col :span="8">
                            <el-form-item label="货物类型" :error="state.formError.goods_type">
                                <el-select v-model="state.form.goods_type" placeholder="货物类型"
                                           style="min-width: 260px;max-width: 260px">
                                    <el-option
                                        v-for="item in state.goods_type_options"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value"
                                    />
                                </el-select>
                            </el-form-item>

                            <el-form-item label="重量（吨）" :error="state.formError.weight">
                                <el-input v-model="state.form.weight" style="min-width: 260px;max-width: 260px"/>
                            </el-form-item>

                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="货物名称" :error="state.formError.title">
                                <el-input v-model="state.form.title" style="min-width: 260px;max-width: 260px"/>
                            </el-form-item>

                            <el-form-item label="单价（元/吨）" :error="state.formError.unit_price">
                                <el-input v-model="state.form.unit_price" style="min-width: 260px;max-width: 260px"/>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="货物价值" :error="state.formError.cost">
                                <el-input v-model="state.form.cost" style="min-width: 260px;max-width: 260px"/>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-form-item label="备注" :error="state.formError.remark">
                            <el-input v-model="state.form.remark" type="textarea" :autosize="{ minRows: 4}"
                                      style="min-width: 260px;max-width: 260px"/>
                        </el-form-item>
                    </el-row>

                </el-form>
            </div>

        </div>


        <el-row justify="center" align="middle" style="height: 80px;">
            <el-button type="primary" style="width: 200px;height: 40px;" @click="doPublish()">发布运单</el-button>
        </el-row>
    </el-card>

    <el-drawer v-model="state.showDrawer" title="我的地址库" direction="rtl" size="40%">

        <el-table :data="state.tableData">
            <el-table-column property="name" label="姓名"/>
            <el-table-column property="mobile" label="手机号"/>
            <el-table-column property="addr" label="地址" :show-overflow-tooltip="true"/>
            <el-table-column label="选项" fixed="right">
                <template #default="scope">
                    <el-button size="small" type="primary" @click="doSelectAddress(scope.row)">选择</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div style="margin-top: 20px;">
            <el-pagination
                :total="state.page.totalCount"
                :page-size="state.page.perPageSize"
                background
                layout="prev, pager, next,jumper"
                @current-change="doChangePage">
            </el-pagination>
        </div>

    </el-drawer>
</template>

<script setup>
import {ref, reactive, getCurrentInstance, onMounted} from 'vue'
import {UploadFilled, Delete, Location, Calendar} from '@element-plus/icons-vue'
import {ElMessage, ElNotification} from "element-plus";
import {validateFormError, clearFormError} from "@/plugins/form";
import router from "@/router";

const {proxy} = getCurrentInstance()

const shortcuts = [
    {
        text: '今天',
        value: new Date(),
    },
    {
        text: '明天',
        value: () => {
            const date = new Date()
            date.setTime(date.getTime() + 3600 * 1000 * 24)
            return date
        },
    }
]

const state = reactive({
    form: {
        from_addr: "",
        from_name: "",
        from_mobile: "",
        from_date: "2022-11-11",

        to_addr: "",
        to_name: "",
        to_mobile: "",
        to_date: "2022-11-11",

        title: "信息",
        goods_type: 2,
        weight: "12",
        unit_price: "11",
        cost: "100",
    },
    formError: {
        from_addr: "",
        from_name: "",
        from_mobile: "",
        from_date: "",

        to_addr: "",
        to_name: "",
        to_mobile: "",
        to_date: "",

        title: "",
        goods_type: "",
        weight: "",
        unit_price: "",
        cost: "",
    },
    goods_type_options: [
        {value: 1, label: '电子产品'},
        {value: 2, label: '大宗货物'},
        {value: 3, label: '冷藏货物'},
        {value: 4, label: '农产品'},
        {value: 5, label: '其他'}
    ],
    showDrawer: false,
    tableData: [
        {
            name: '2016-05-03',
            mobile: '1999999999',
            addr: '北京朝阳区',
        },
    ],
    page: {
        totalCount: 90,
        perPageSize: 10,
        currentPage: 1
    },
    addressLoaded: false,
    clickAddressField: ""
})

function doChangePage(page) {
    state.page.currentPage = page;
    initAddressTable(page);
}

function initAddressTable(page) {
    // 发送axiso请求  /api/shipper/address/?page=2
    proxy.$axios.get("/api/shipper/address/", {params: {page: page}}).then(res => {
        // {code:0,data:{ data:数据,total:总数据条数,page_size:每页几条数据 }}

        if (res.data.code === 0) {
            state.tableData = res.data.data.data;

            state.page.totalCount = res.data.data.total;
            state.page.perPageSize = res.data.data.page_size;
        } else {
            // this.$message.error("请求失败");
            ElMessage.error("请求失败");
        }
    })
}

function showAddressTable(field) {
    state.clickAddressField = field; // from  to
    state.showDrawer = true;
    if (state.addressLoaded) {
        return;
    }

    // 加载地址库
    initAddressTable(1);
    state.addressLoaded = true;
}

function doSelectAddress(row) {
    for (let key in row) {
        let filed = `${state.clickAddressField}_${key}`;
        state.form[filed] = row[key];
    }
    state.showDrawer = false;
}

function doPublish() {
    clearFormError(state.formError);
    proxy.$axios.post("/api/shipper/order/", state.form).then(res => {
        //console.log(res.data);
        if (res.data.code === 0) {
            ElMessage.success("发布成功");
            router.push({name: "PubList"});

        } else if (res.data.code === -1) {
            validateFormError(state.formError, res.data.detail);
        } else {
            //{"code": -2, 'msg': "用户名或密码错误"}
            ElMessage.error(res.data.msg);
        }
    })
}
</script>


<style scoped>

</style>
