<template>
    <el-card class="box-card" shadow="never" style="min-width: 1120px">
        <template #header>
            <div class="card-header">
                <span style="font-weight: bold;font-size: 18px;">运单管理</span>
            </div>
        </template>

        <el-row>
            <el-button-group>
                <el-button :type="item.id===state.selectIdx?'primary':''" v-for="(item,idx) in state.groups" :key="idx"
                           @click="doGroupSearch(item.id)">
                    {{ item.title }}
                </el-button>
            </el-button-group>
        </el-row>

        <div style="margin-top: 20px;">
            <el-form label-width="70px" inline ref="searchForm" :model="state.searchForm">

                <el-form-item label="货物类型" prop="goods_type">
                    <el-select v-model="state.searchForm.goods_type" placeholder="交易类型" style="width: 220px;">
                        <el-option
                            v-for="item in state.goods_type_options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                        />
                    </el-select>
                </el-form-item>

                <el-form-item label="订单号" prop="trans_id">
                    <el-input style="width: 220px;" placeholder="订单号" v-model="state.searchForm.trans_id"/>
                </el-form-item>

                <el-form-item label="交易时间" prop="date_range">
                    <el-date-picker
                        v-model="state.searchForm.date_range"
                        type="daterange"
                        style="width: 200px;"
                        start-placeholder="起始"
                        end-placeholder="结束"
                        format="YYYY-MM-DD"
                        value-format="YYYY-MM-DD"
                        :clearable="false"
                    />
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="doSearch">搜 索</el-button>
                    <el-button type="primary" plain>重 置</el-button>
                </el-form-item>

            </el-form>
        </div>



        <el-row :justify="'end'" class="menus">

            <el-dropdown class="menu" trigger="click" @command="handleCommand">
                <el-button>更多操作
                    <el-icon class="el-icon--right">
                        <ArrowDown/>
                    </el-icon>
                </el-button>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item command="a">批量导入</el-dropdown-item>
                        <el-dropdown-item command="b">导出EXCEL</el-dropdown-item>
                        <el-dropdown-item command="c">A...</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>

            <el-button class="menu" >批量取消</el-button>

            <router-link :to="{name:'Pub'}">
                <el-button type="primary" class="menu">发布运单</el-button>
            </router-link>

        </el-row>


        <el-row style="margin-top: 20px;">
            <el-table :data="state.tableData" style="width: 100%;" :border="true"
                      @selection-change="handleSelectionChange">
                <el-table-column type="selection" width="55"/>
                <el-table-column prop="oid" label="订单号" width="260"/>
                <el-table-column prop="title" label="货物名称"/>
                <el-table-column prop="weight" label="重量"/>
                <el-table-column prop="unit_price" label="单价"/>
                <el-table-column prop="from_name" label="发货人"/>
                <el-table-column prop="to_name" label="收货人"/>
                <el-table-column prop="status_text" label="状态"/>
            </el-table>
            <div style="margin-top: 20px;">
                <el-pagination
                    :total="state.page.totalCount"
                    :page-size="state.page.perPageSize"
                    background
                    layout="prev, pager, next,jumper"
                    @current-change="handleChangePage">
                </el-pagination>
            </div>

        </el-row>
    </el-card>
</template>

<script setup>
import {getCurrentInstance, onMounted, reactive} from "vue";
import {ArrowDown, Delete, Location, Calendar} from '@element-plus/icons-vue'
import {ElMessage} from "element-plus";
import router from "@/router";
import {validateFormError} from "@/plugins/form";

const {proxy} = getCurrentInstance()

const state = reactive({
    selectIdx: -1,
    groups: [
        {id: -1, title: '全部'},
        {id: 0, title: '已发布'},
        {id: 1, title: '待接单'},
        {id: 2, title: '待提货'},
        {id: 3, title: '运输中'}
    ],
    searchForm: {
        date_range: "",
        goods_type: "",
        trans_id: "",
    },
    goods_type_options: [
        {value: 1, label: '电子产品'},
        {value: 2, label: '大宗货物'},
        {value: 3, label: '冷藏货物'},
        {value: 4, label: '农产品'},
        {value: 5, label: '其他'}
    ],
    checkList: [],
    tableData: [
        {
            id: 1,
            oid: '2016-05-03',
            title: '2016-05-03',
            tran_type_text: '2016-05-03',
            amount: 'Tom',
            auditor_status_text: 'Tom',
        },
        {
            id: 2,
            oid: '2016-05-03',
            title: '2016-05-03',
            tran_type_text: '2016-05-03',
            amount: 'Tom',
            auditor_status_text: 'Tom',
        },
    ],
    page: {
        totalCount: 90,
        perPageSize: 10,
        currentPage: 1
    },
});

function doGroupSearch(idx) {
    state.selectIdx = idx;
    // TODO 搜索
}

function handleSelectionChange(valueList) {
    state.checkList = valueList;
}
function handleCommand(command){
    console.log(command, JSON.stringify(state.checkList));
}

function initTable(page) {
    proxy.$axios.get("/api/shipper/order/", {params: {page: page}}).then(res => {
        console.log(res.data);
        if (res.data.code === 0) {
            state.tableData = res.data.data.data;
            state.page.totalCount = res.data.data.total;
            state.page.perPageSize = res.data.data.page_size;
        } else {
            // this.$message.error("请求失败");
            ElMessage.error("请求失败");
        }
    })
}
onMounted(() => {
    initTable(1);
})

</script>

<style scoped>
.menus {
    font-weight: 400;
}

.menus a {
    text-decoration: none;
}

.menus .menu {
    margin-left: 10px;
}
</style>

