# day25 供应链系统

今日概要：

- 钱包 取消、重新支付

- 发布运单

  ```
  - 发布司机看到
  - 签合同（企业账号，个人自己无法使用）
  ```

- 运单管理（表格）

- 电子签合同（企业账号，个人自己无法使用）



# 1.钱包

## 1.1 展示按钮

条件：类型=充值 + 状态=未支付

```
tran_type
pay_status
```

![image-20230108102405381](assets/image-20230108102405381.png)





## 1.2 重新支付

- 向后台发送请求，携带交易记录ID
- 后端生成支付宝的链接，返回      订单号+金额
- 跳转



















## 1.3 取消支付

- 补充SDK
- 沙箱无法实现（订单不存在等）



实现流程：

- 点击发送请求，携带ID
- 后端根据ID，获取：商户订单号（我们生成并传递给支付宝）
- SDK生成连接 + 直接访问
- 提示 + 数据库状态更新



## 1.4 其他

- 参考文档补充自己的需求

- 异步通知 & 宕机

  ```
  - 交易查询接口
  - 订单号比对，是否已支付（自己平台更新）
  ```

- 退款





# 2.发布运单



## 2.1 页面的展示

基于抽屉实现历史地址。

- 抽屉区域，默认隐藏

- 点击地址库，展示抽屉

  - 是否已有，不再获取。

  - 发送请求，获取当前登录用的地址列表，返回 

    ```
    - 新建地址库
    - URL -> 视图（我的地址、分页、序列化）
    ```

  - 页面渲染



## 2.2 发布

曾经自定义View:

```
mixins.CreateModelMixin,
mixins.RetrieveModelMixin,
mixins.UpdateModelMixin,
mixins.DestroyModelMixin,
mixins.ListModelMixin,
```

```
RetrieveModelMixin
ListRetrieveModelMixin
UpdateModelMixin
CreateUpdateModelMixin
ListPageNumberModelMixin
```

视图其实就是帮我们实现：

```
- 查看列表  ListModelMixin      -> ListPageNumberModelMixin/ListRetrieveModelMixin
- 查看详细  RetrieveModelMixin  -> RetrieveModelMixin

- 删除	RetrieveModelMixin
- 新建	DestroyModelMixin
- 修改	UpdateModelMixin
```



```python
class DestroyModelMixin:
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        res = self.perform_destroy(instance)
        
        // return Response(status=status.HTTP_204_NO_CONTENT)
    	return res or Response({"code": return_code.SUMMARY_ERROR, 'msg': "请求失败"})

    def perform_destroy(self, instance):
        instance.delete()
        
        
  class MyView2(DestroyModelMixin...):
    ...
    
    def perform_destroy(self, instance):
        # 删除(删除数据库 + 图片在百度网盘 + 百度AI识别)
        
		# 1.一些数据去其他地方操作，成功
        return Response('code:10000')
    
		# 2.一些数据去其他地方操作，成功
		# 3.一些数据去其他地方操作，成功
        return Response('code:10000')
        
        
        
       
        
        
class MyView1(DestroyModelMixin...):
    ...
    
    def perform_destroy(self, instance):
        # 删除
        instance.delete()
```

- drf其实已考虑到， ->  抛出异常 -> dispatch中捕获 ->  {"exception":"......" }
- 扩展点



---



- 采集数据，发送POST请求

- 相关表结构

  ```
  Order表：
  	- 地址写ID
  	- 地址写一遍
  ```

  

- 返回成功或失败



# 3.运单管理



## 3.1 页面

...















## 3.2 数据处理





# 4.电子签

在线签合同：

- 腾讯电子签，未集成在腾讯云平台。

  - 企业用户

    - 申请管理后台，合同配置
      - 发起签合同的请求，手机号
    - 对方
      - 打开链接
      - 扫码
      - 小程序签署

    ```
    - 人工签合同
    - 程序自动签署
    ```

  - 个人用户，房东小程序创建合同，签署。

- 君子签。



## 4.1 人工

- 注册企业账号
- 创建合同模板
- 发起合同
- 签署





## 4.2 程序

腾讯给提供了两种环境：

```
- 正式环境，上传+签合同+签章等。
- 沙箱环境，签署通知
```

签合同的功能继承到项目，并且减少人工干预，自动完成签合同，例如：

- 平台 ->  供应商，合同。
- 平台 ->  司机，合同。

所以，平台需要自动实现一些功能：

- 自动生成PDF格式合同，只有合同部分信息（不包含签署信息）
- 自动上传给腾讯电子签
- 自定义签署位置
  - 坐标来找位置
  - 关键字找位置（推荐）
- 触发签合同
  - 自动签署，公章上传平台 + 开通自动签章的服务。（企业静默签）
  - 手动签署，小程序扫码
- 对方签完了怎么通知我们？电子签平台通知（网址）。



## 4.3 代码示例

### 1.PDF合同

```
pip install reportlab
```

- 字体（思源宋体）
- 学习模块的API实现写文字、图片、段落等。

```python
"""
思源宋体 https://source.typekit.com/source-han-serif/cn/#get-the-fonts
"""
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('Song', 'files/ttf/SourceHanSerifSC-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Song-Bold', 'files/ttf/SourceHanSerifSC-Medium.ttf'))

from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER

story = []

story.append(
    Paragraph(
        "货物运输合同",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=20,
            leading=1.5 * 20,
            alignment=TA_CENTER,
        )
    )
)
story.append(
    Paragraph(
        "根据国家的相关法律、法规，经甲乙双方友好协商，就乙方为甲方提供货物运输达成如协议，以便双方共同遵守。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            spaceBefore=10,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "第一条 服务项目及内容",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=14,
            leading=2 * 14,
            spaceBefore=10,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "1、甲方聘请乙方进行进行货物运输。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            # spaceBefore=20,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "第二条 双方权利与义务",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=14,
            leading=2 * 14,
            spaceBefore=10,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "1、甲方聘请乙方进行进行货物运输。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            # spaceBefore=20,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "2、甲方聘请乙方进行进行货物运输。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            # spaceBefore=20,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "第七条 文本时效于约定",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=14,
            leading=2 * 14,
            spaceBefore=10,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "1、本协议未尽事宜，经双方友好协商后可签订补充协议，补充协议与本协 议具有同等法律效力。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            # spaceBefore=20,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "2、本协议壹式贰份，甲乙双方各执壹份，均具有同等法律效力。",
        ParagraphStyle(
            name="t1",
            fontName="Song",
            fontSize=12,
            leading=2 * 12,
            # spaceBefore=20,  # 段前间距
            leftIndent=0,  # 左缩进
            rightIndent=0,  # 右缩进
            # firstLineIndent=20,  # 首行缩进，每个汉字为10
        )
    )
)

story.append(
    Paragraph(
        "【以下无正文】",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=12,
            leading=2 * 12,
            spaceBefore=10,  # 段前间距
            alignment=TA_CENTER,
        )
    )
)

story.append(
    Paragraph(
        f"甲方（签字）：{'&nbsp' * 50}乙方（盖章）：",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=12,
            spaceBefore=30,  # 段前间距
        )
    )
)
story.append(
    Paragraph(
        f"{'&nbsp' * 8}签约日期：{'&nbsp' * 58}签约日期：",
        ParagraphStyle(
            name="t1",
            fontName="Song-Bold",
            fontSize=12,
            spaceBefore=60,  # 段前间距
        )
    )
)

doc = SimpleDocTemplate("demo3.pdf")
doc.build(story)
```



### 2.上传合同

https://cloud.tencent.com/document/product/1323/73066

```
pip install tencentcloud-sdk-python 
```

```python
import json
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ess.v20201111 import ess_client, models
import base64

cred = credential.Credential("AKID3ymNjrmUxCCtOehX9XjhV8XhfOsAJGzU", "KRKzUlpfHemhO1TksnX4QZXIsFPPDpHa")
# 实例化一个http选项，可选的，没有特殊需求可以跳过
httpProfile = HttpProfile()
# httpProfile.endpoint = "ess.tencentcloudapi.com"
httpProfile.endpoint = "file.ess.tencent.cn"

# 实例化一个client选项，可选的，没有特殊需求可以跳过
clientProfile = ClientProfile()
clientProfile.httpProfile = httpProfile
# 实例化要请求产品的client对象,clientProfile是可选的
client = ess_client.EssClient(cred, "", clientProfile)

# ################################################ 上传 ################################################
with open("demo3.pdf", mode='rb') as f:
    body = f.read()
b64_body = base64.b64encode(body).decode('utf-8')


req = models.UploadFilesRequest()
params = {
    "Caller": {
        "OperatorId": "yDRTrUU3heltbUycG3bXb8PZTxlkAdyP"
    },
    "BusinessType": "DOCUMENT",
    "FileInfos": [
        {
            "FileName": "demo3.pdf",
            "FileBody": b64_body,
        }
    ]
}
req.from_json_string(json.dumps(params))

# 返回的resp是一个UploadFilesResponse的实例，与请求对象对应
resp = client.UploadFiles(req)
# 输出json格式的字符串回包
print(resp.to_json_string())

# {"FileIds": ["yDwc1UUk0yocuUxTH3T4vuDLOElaKHCS"], "TotalCount": 1, "RequestId": "983478f3-074b-45b1-bf6c-e3e48dc4a2c4"}
```



### 3.创建签署流程

https://cloud.tencent.com/document/product/1323/70360

```python
import json
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ess.v20201111 import ess_client, models

cred = credential.Credential("AKID3ymNjrmUxCCtOehX9XjhV8XhfOsAJGzU", "KRKzUlpfHemhO1TksnX4QZXIsFPPDpHa")
httpProfile = HttpProfile()
httpProfile.endpoint = "ess.tencentcloudapi.com"

clientProfile = ClientProfile()
clientProfile.httpProfile = httpProfile
client = ess_client.EssClient(cred, "", clientProfile)

# ################################################ 1.根据PDF创建签署流程 ################################################
# 实例化一个请求对象,每个接口都会对应一个request对象

req = models.CreateFlowByFilesRequest()
params = {
    "Operator": {
        "UserId": "yDRTrUU3heltbUycG3bXb8PZTxlkAdyP"
    },
    "FlowName": "测试3",
    "Approvers": [
        {
            "ApproverType": 1,
            "ApproverName": "武沛齐",
            "ApproverMobile": "15131255089",
            "SignComponents": [
                {
                    "ComponentType": "SIGN_SIGNATURE",
                    "FileIndex": 0,
                    "ComponentHeight": 43,
                    "ComponentWidth": 119,
                    "ComponentPage": 1,
                    # "ComponentPosX": 191.95485691253523,
                    # "ComponentPosY": 124.79703534777651,
                    "ComponentName": "签署区0",

                    "GenerateMode": "KEYWORD",
                    "ComponentId": "甲方（签字）：",
                    "KeywordOrder": "Positive",
                    "KeywordIndexes":[0],
                    "RelativeLocation": "LowerRight",
                    "OffsetX": 0,
                    "OffsetY": 0,

                },
            ]
        },
        {
            # "ApproverType": 0,
            "ApproverType": 3,
            "OrganizationName": "河北源代码教育咨询有限公司",
            "ApproverName": "武沛齐",
            "ApproverMobile": "15131255089",
            "SignComponents": [
                {
                    "ComponentType": "SIGN_SEAL",
                    "FileIndex": 0,
                    "ComponentHeight": 119,
                    "ComponentWidth": 119,
                    "ComponentPage": 1,
                    # "ComponentPosX": 417.9817009270455,
                    # "ComponentPosY": 124.79703534777651,
                    "ComponentName": "签署区1",
                    "ComponentValue": "yDRTTUU3jqsp3UuxJsRfveCAY8YOZwAu",
                    "GenerateMode": "KEYWORD",
                    "ComponentId": "乙方（盖章）：",
                    "KeywordOrder": "Positive",
                    "KeywordIndexes": [0],
                    "RelativeLocation": "LowerRight",
                    "OffsetX": 0,
                    "OffsetY": 0,
                },
            ]
        }
    ],
    "FileIds": [
        "yDwc1UUk0yocuUxTH3T4vuDLOElaKHCS"
    ],
    # "NeedPreview": True,
    # "PreviewType": 1,
    # "Unordered": False
}

# print(json.dumps(params,ensure_ascii=False))
req.from_json_string(json.dumps(params))
resp = client.CreateFlowByFiles(req)
FlowId = resp.FlowId
# # 输出json格式的字符串回包
print(resp.to_json_string())
# {"FlowId": "yDRTKUU33taweURu5CzNEPFMa46WBdMC", "PreviewUrl": "", "RequestId": "dd7b9f1c-d295-4fe6-8399-868423efbc1b"}
```



### 4.获取小程序链接

```python
import json
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ess.v20201111 import ess_client, models

# 实例化一个认证对象，入参需要传入腾讯云账户secretId，secretKey,此处还需注意密钥对的保密
# 密钥可前往https://console.cloud.tencent.com/cam/capi网站进行获取
# cred = credential.Credential("SecretId", "SecretKey")
# cred = credential.Credential("AKyDRTrUUgyg3209akUxJeypPR6bnmIrsS", "SKn447daUCKQMNY2f7InIlLWq1AAP4KxG0")
# cred = credential.Credential("AKID6xmOjHdlfL1RcHkz0m24tUr9Z7VkkV5R", "FI8kBRUYWVN4c0B90jHdlfMrBJFyWL4m")
cred = credential.Credential("AKID3ymNjrmUxCCtOehX9XjhV8XhfOsAJGzU", "KRKzUlpfHemhO1TksnX4QZXIsFPPDpHa")
# 实例化一个http选项，可选的，没有特殊需求可以跳过
httpProfile = HttpProfile()
httpProfile.endpoint = "ess.tencentcloudapi.com"

# 实例化一个client选项，可选的，没有特殊需求可以跳过
clientProfile = ClientProfile()
clientProfile.httpProfile = httpProfile
# 实例化要请求产品的client对象,clientProfile是可选的
client = ess_client.EssClient(cred, "", clientProfile)

# ################################################ 1.根据PDF创建签署流程 ################################################
# 实例化一个请求对象,每个接口都会对应一个request对象

req = models.CreateFlowByFilesRequest()
params = {
    "Operator": {
        "UserId": "yDRTrUU3heltbUycG3bXb8PZTxlkAdyP"
    },
    "FlowName": "测试3",
    "Approvers": [
        {
            "ApproverType": 1,
            "ApproverName": "wupeiqi",
            "ApproverMobile": "15131255089",
            "SignComponents": [
                {
                    "ComponentType": "SIGN_SIGNATURE",
                    "FileIndex": 0,
                    "ComponentHeight": 43,
                    "ComponentWidth": 119,
                    "ComponentPage": 2,
                    "ComponentPosX": 191.95485691253523,
                    "ComponentPosY": 124.79703534777651,
                    "ComponentId": "componentId_0",
                    "ComponentName": "签署区0"
                },
                {
                    "ComponentType": "SIGN_DATE",
                    "FileIndex": 0,
                    "ComponentHeight": 20,
                    "ComponentWidth": 119,
                    "ComponentPage": 2,
                    "ComponentPosX": 191.95485691253523,
                    "ComponentPosY": 167.7970353477765,
                    "ComponentId": "componentId_0date",
                    "ComponentName": "签署日期"
                },
            ]
        },
        {
            "ApproverType": 3,
            # "ApproverType": 0,
            "OrganizationName": "河北源代码教育咨询有限公司",
            "ApproverName": "武沛齐",
            "ApproverMobile": "15131255089",
            # "ApproverIdCardNumber":"yDRTTUU3jqsp3UuxJsRfveCAY8YOZwAu",
            "SignComponents": [
                {
                    "ComponentType": "SIGN_SEAL",
                    "FileIndex": 0,
                    "ComponentHeight": 119,
                    "ComponentWidth": 119,
                    "ComponentPage": 2,
                    "ComponentPosX": 417.9817009270455,
                    "ComponentPosY": 124.79703534777651,
                    "ComponentId": "componentId_1",
                    "ComponentName": "签署区1",
                    "ComponentValue":"yDRTTUU3jqsp3UuxJsRfveCAY8YOZwAu"
                },
                {
                    "ComponentType": "SIGN_DATE",
                    "FileIndex": 0,
                    "ComponentHeight": 20,
                    "ComponentWidth": 119,
                    "ComponentPage": 2,
                    "ComponentPosX": 417.9817009270455,
                    "ComponentPosY": 243.7970353477765,
                    "ComponentId": "componentId_1date",
                    "ComponentName": "签署日期",

                }
            ]
        }
    ],
    "FileIds": [
        # "yDRTzUU3qzvveUEspfBqRA2BmSYhloTw"
        "yDRTOUU31ol96UuzHd8fukSYM6mola6R"
    ],
    # "NeedPreview": True,
    # "PreviewType": 1,
    # "Unordered": False
}

# print(json.dumps(params,ensure_ascii=False))
req.from_json_string(json.dumps(params))
# {"FlowId": "yDRTKUU33taweURu5CzNEPFMa46WBdMC", "PreviewUrl": "", "RequestId": "dd7b9f1c-d295-4fe6-8399-868423efbc1b"}
resp = client.CreateFlowByFiles(req)
FlowId = resp.FlowId
# # 输出json格式的字符串回包
print(resp.to_json_string())


# ################################################ 4.获取小程序链接 ################################################
req = models.CreateSchemeUrlRequest()
params = {
    "Operator": {
        "UserId": "yDRTrUU3heltbUycG3bXb8PZTxlkAdyP"
    },
    "FlowId": FlowId
}
req.from_json_string(json.dumps(params))

# 返回的resp是一个CreateSchemeUrlResponse的实例，与请求对象对应
resp = client.CreateSchemeUrl(req)
# 输出json格式的字符串回包
print(resp.to_json_string())
```



### 5.签完如何通知？

![image-20230108183726845](assets/image-20230108183726845.png)



#### 5.1 接收请求

- 服务器
- flask脚本

```python
from flask import Flask, render_template,request

app = Flask(__name__)


@app.route("/info",methods=["GET","POST"])
def index():
    print(request.data)
    return "OK"


if __name__ == '__main__':
    app.run(host='0.0.0.0',port=80)
```





#### 5.2 解码

```
pip install pycryptodomex
```

```python
# -*- coding: utf-8 -*-
"""
 pip install pycryptodomex
"""
import base64

from Cryptodome.Cipher import AES


def decode_aes256(data, encryption_key):
    iv = encryption_key[0:16]
    aes = AES.new(encryption_key, AES.MODE_CBC, iv)
    d = aes.decrypt(data)
    unpad = lambda s: s[0:-ord(d[-1:])]
    return unpad(d)

# 此处传入密文
data = '4u/mAbN4y1RV0DsgMp1MfHt7VIg5GkXdHT4EYIB829ODv0c8XObGi2016GECglyHUMK58KeKLzhsVS3BRt6TELrJ1pMWnQ7jjUVFLSYptdsMIqOne2KU96+C4/wT2TpdQur3DGl4K6YE7lZByjulZ77fIMv2vF/jAV+M2n0DgUEl84q+oKVS+iXw8JEAal3NwIdUkLgNEYg0odnpdWCwLagWiIlm6+hCNaGM1gDacpCAE0znFK/pzs91mI5cLlaIear/DkU0bBKk1Q0swGf8/b79W6F48TE0XETvHL+LWOmm1Xmxai4DluYd/bD12kBUKK4OAgz2di20lgh4tnm4Ri8NDt30SOV+WQejIwdi6DeFOnLcZu0QnTyYveoaQWXHx4YUEMZlwN5txpHlh6UGOhjV89v6vyjxi6id5/fgz/7zrz+PqbVUwWWfU/NTL2P4otJ+NAMeWZoQfguBX36mUlosrQox2M+gmz+bpiQxgCICgPLr4q2Qh1L0vgdd5xzSaEQhNNDTCp9WcpmlRjbc9kqjOu3mqQmjWytMuMasa2r7fy4ZUsBs3adF4ArBZa1CJiyVtqBUHmfKYqtcyvhQn4nMJW9O46zDkVhpkBhWL7MOcoLtKv4x9JLEfTHFL+2pOuQm+E2beT0cxYdbjuIMXKdlWMAjEIj4NyCaGBdQtu+HmICvU9cyJl+EetDHi3AqYKXfEh3EPQGZ/qn7Y40UcWGOeIODWobYBBRRi70jGRPea8ZQdG13MW3Wok6/PP8i1FKBDPsT4KmVm+29Wug60EWVm5WY4JQdrORJedq3Yx0Hboyb58Tqesds7YtgNjxsaDTfYnTeHmpGQ+aqqrHBF8ByKNDCkmmmQcIL9cHh9YPBX7OyA0p8RVCgNI42MzTVO+1R/slgt1djsYJoSVvM9CzIBmwvB5JPhWDH9/UVMejvqHKetX1Ludcbo2cwU6qu90mTodxy6//LFawarEFk5ZBIFEj1tK7Ky8Uf+iJOIUVd5wPKyxnQN2ztqIRJujgFaFg+wFUCTn8U6kiEPakjkKghE42zLDvIoKmCemhbd9Q5QeBDHaChxNxWdCeMaftNWY63Lg9cVT3TRKYrPUYbljquylu/sh/gzzUEWMk9/Hu4YmiATHOAoKrJQVxLPtvcdgq51Tj6MIroRyJzwfWKXrRmnQZWFJSa5CqO+f9kgZw='

data = base64.b64decode(data)
e = decode_aes256(data, bytes('A7B0A2FFF3B841B58DC748EE302DF98B', encoding="utf8"))
print(type(e))
print(str(e, encoding="utf8"))
```























































































































# 其他

- 进度条 ` <el-progress :percentage="100" :format="format" />`

  - 轮训，每n秒发送请求获取数据。
  - 长轮训，每n秒发送请求获取数据。
  - WebSocket，更好。

  ```
  https://www.bilibili.com/video/BV1uA411b77M/    轮训
  https://www.bilibili.com/video/BV1BE411W71n/    WebSocket
  ```

- 权限

  - 代码控制

    ```
    if role == "admin":
    	data = ...
    else:
    	data = ...
    ```

  - 字段的位

    ```
    000010
    	- 第3个位置：用户管理，如果0则表示无权限；如果是1则表示有权限。
    ```

  - URL级别（很不错的系统） + 条件

    ```
    权限表：
        /front/wallet       充值
        /front/wallet       kd
    分配：
    	充值     用户A
    ```

  - 行级别（很不错的系统）

    ```
    条件表：（难度在分配角色）
    	名字     		条件
    	mine    	id={PK}
    	A      	    ....
    	
    	字段 + PK
    	
    	
    权限表：
        /front/wallet       充值
        /front/wallet       kd
        
    分配：
    	充值     用户A
    ```

    







