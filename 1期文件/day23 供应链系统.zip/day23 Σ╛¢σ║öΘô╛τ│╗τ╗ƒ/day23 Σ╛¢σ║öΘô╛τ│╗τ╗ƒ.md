# day23 供应链系统

今日概要：

- 账号认证

- 我的钱包
  - 账户余额
  - 充值/提现
  - 交易记录（搜索区域、表格、分页）

- 其他
  - 支付宝支付
  - 图像识别



# 1.关于跨域补充

> cors，返回响应头。

- 中间件，让所有的响应的内容加入响应头。

  ```python
  from django.utils.deprecation import MiddlewareMixin
  
  
  class AuthMiddleware(MiddlewareMixin):
      def process_response(self, request, response):
          response["Access-Control-Allow-Origin"] = "*"
          response["Access-Control-Allow-Methods"] = "*"
          response["Access-Control-Allow-Headers"] = "*"
          return response
  ```

- 简单请求 or 复杂请求

  ```
  - OPTIONS请求，预检
  	- 中间件，拦截（返回空内容+响应头）		
  	
  - 真正请求 GET/POST/PUT...
  	- dispatch，认证、权限、限流等
  		- 认证组件中 return None，继续向后走（匿名用户 request.user/request.auth）
  		
  	- 视图方法 get/post/put/delete -> list/update/retrive/destory等
  		- Retrieve方法
  			instance = self.get_object()
              serializer = self.get_serializer(instance)
              return Response({"code":..., 'data': serializer.data})
  ```

  

# 2.账号认证



## 2.1 关于静态资源

- static，开发所需要的图片、css、js等。例如：默认头像
- media，用户上传excel、图片等。         例如：用户上传头像
  - 上传逻辑，视图-> 写入media目录
  - 配置media路径
  - 路由配置
  - 用户观看



## 2.2 上传逻辑

- 定义URL

  - 传统

    ```
    path('upload/', account.RegisterSmsView.as_view()),
    ```

  - 结合SimpleRouter扩展URL

    ```python
    from django.urls import path
    from rest_framework import routers
    from .views import account, basic,auth
    
    router = routers.SimpleRouter()
    router.register(r'auth', auth.AuthView)
    
    urlpatterns = [
        path('login/', account.LoginView.as_view()),
    ]
    urlpatterns += router.urls
    
    ```

- 视图函数

  ```python
  class AuthView(ModelViewSet):
      queryset = models.CompanyAuth.objects.all()
      serializer_class = AuthModelSerializers
  
      @action(detail=False, methods=['post'], url_path="upload")
      def upload(self, request):
          # 1.读取上传的文件
          #    request.POST  request.GET   request.FILES
          #    request.data  request.FILES = request._request.FILES
  
          # {name:"", file:文件}
          upload_object = request.FILES.get("file")
          upload_object.size  # 文件大小
          upload_object.name  # 文件名
          upload_object.read()  # 文件名
          for chunk in upload_object.chunks(1024):  # 文件名
              pass  # 读取内容写入文本路径
  
          # 2.路径返回（第三方组件） {status:1}  {status:0 }
          return Response("...")
  ```

  

## 2.3 实现上传

详见：src-1.zip      dahe-1.zip

```vue
<el-upload  class="avatar-uploader"
           :action="imageUploadUrl"
           :on-success="wrappUploadSuccess('leader_identity_front')"
           :data="{type:'front'}"
           :show-file-list="false">
    
    <img v-if="state.form.leader_identity_front"
         :src="state.form.leader_identity_front"
         class="avatar"/>
    <el-icon v-else class="avatar-uploader-icon">
        <upload-filled/>
    </el-icon>
    
</el-upload>
```

```vue
<script setup>

//http://127.0.0.1:8000/api/shipper/auth/upload/?type=front
//http://127.0.0.1:8000/api/shipper/auth/upload/?type=back
const imageUploadUrl = "http://127.0.0.1:8000/api/shipper/auth/upload/"
const state = reactive({
	form: {
        leader_identity_front: "",
        leader_identity_back: "",
        leader_identity_license: "",
    }
});
function wrappUploadSuccess(field){
    return function(res){
        state.form = res.data.图片路径;
    }
}

</script>
```



## 2.4 识别（本地文件）

基于百度AI接口，进入文字识别区域。

- 领取/购买 资源

- 创建应用

  ```
  AppID
  API Key
  Secret Key
  ```

- 文档调用



```python
import base64
import requests

# client_id 为官网获取的AK， client_secret 为官网获取的SK
host = 'https://aip.baidubce.com/oauth/2.0/token'
response = requests.get(
    url="https://aip.baidubce.com/oauth/2.0/token",
    params={
        "grant_type": "client_credentials",
        "client_id": "PhGc5UK5e5UOkSqpNakZLpxL",
        "client_secret": "cS1OaU3GngGDdsZj2Fo7scd4j7S3M3Gw",
    }
)
data_dict = response.json()
access_token = data_dict['access_token']
print(access_token)

request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/idcard"
# 二进制方式打开图片文件
f = open('files/x.jpeg', 'rb')
img = base64.b64encode(f.read())

params = {"id_card_side": "front", "image": img}  # front/back
request_url = request_url + "?access_token=" + access_token
headers = {'content-type': 'application/x-www-form-urlencoded'}
res = requests.post(request_url, data=params, headers=headers)
res_dict = res.json()
for k, v in res_dict['words_result'].items():
    print(k, v)
```



```python
import base64
import requests

# client_id 为官网获取的AK， client_secret 为官网获取的SK
host = 'https://aip.baidubce.com/oauth/2.0/token'
response = requests.get(
    url="https://aip.baidubce.com/oauth/2.0/token",
    params={
        "grant_type": "client_credentials",
        "client_id": "PhGc5UK5e5UOkSqpNakZLpxL",
        "client_secret": "cS1OaU3GngGDdsZj2Fo7scd4j7S3M3Gw",

    }
)
data_dict = response.json()
access_token = data_dict['access_token']
print(access_token)


request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/business_license"
# 二进制方式打开图片文件
f = open('files/营业执照.png', 'rb')
img = base64.b64encode(f.read())

params = {"image":img}
request_url = request_url + "?access_token=" + access_token
headers = {'content-type': 'application/x-www-form-urlencoded'}
res = requests.post(request_url, data=params, headers=headers)
res_dict = res.json()
for k, v in res_dict['words_result'].items():
    print(k, v)
```





## 2.5 识别（上传文件）

- 区分是什么图片？ `:data="{type:'font'}"`

  ```
  type="front"
  type="back"
  type="license"
  ```

  ```python
  img_type = request.data.get("type")
  ```

  

## 2.6 加载

加载框来实现。

详见：src-2.zip      dahe-2.zip







## 2.7 认证读取

加载页面，发送请求，获取结果再展示在页面上。

- 前端页面，加载发送网络请求 & 未认证显示无

- 后端接受

  - 网址是否带ID

    ```
    http://127.0.0.1:8000/api/shipper/auth/
    	GET  列表 request.user条件
    	POST 新增
    	
    http://127.0.0.1:8000/api/shipper/auth/1/   【推荐】
    	GET  单条信息
    	PUT  更新
    ```

  - 后端去数据库获取数据 + 序列化展示

    ```
    - 无法获取数据，按照默认数据展示，即：无
    - 获取数据 id=1且登录用户id=1，序列化
    ```

    



## 2.8 编辑认证（展示）

## 2.9 编辑认证（提交）

详见：src-3.zip      dahe-3.zip



- 提交的图片不带http前缀的（不带_url后缀的字段）

- 点击审核：新建或更新

  ```
  http://127.0.0.1:8000/api/shipper/auth/
  	GET  列表 request.user条件
  	POST 新增
  	
  http://127.0.0.1:8000/api/shipper/auth/1/   【推荐】
  	GET  单条信息
  	PUT  更新
  ```

  ```
  http://127.0.0.1:8000/api/shipper/auth/
  	POST 新增+存在就更新
  ```

- 三个注意点

  - 查看个人信息 or 更新信息，必须是自己认证信息。

    ```
    获取认证信息
    	http://127.0.0.1:8000/api/shipper/auth/1/ 
    	
    后端比对
    	request.user 中已登录用户比对
    ```

    ```
    id到底是谁的ID？
    	- Company_id       不能为空
    	- CompanyAuth_id   是否可以为空？
    ```

  - 备注信息，再次提交时，原来的审核信息是否保留？

    - 保留

      ```python
      extra_kwargs = {
          'remark': {"read_only": True},
      }
      ```

    - 不保留

      ```python
      def perform_create(self, serializer):
          user_id = self.request.user['user_id']
          serializer.save(company_id=user_id, remark="")
      
      def perform_update(self, serializer):
          serializer.save(remark="")
      ```

    - 关于状态

      ```
      更新或新建时，更新状态（其他表中）
      ```

      

# 3.我的钱包



## 3.1 支付宝相关

- 正式环境

- 沙箱环境

  - 支付宝账号开发者平台，开通沙箱。

    ```
    2016082500309412
    
    应用私钥
    应用公钥
    支付宝公钥
    
    https://openapi.alipaydev.com/gateway.do
    ```

  - 账号

    - 商家
    - 卖家

  - 手机沙箱客户端

- 关于文档

  - API（代码+API参数什么意思）

    ```
    https://openapi.alipay.com/gateway.do
    加密/签名
    参数
    ```

    ```
    - 支付：https://opendocs.alipay.com/open/028r8t?scene=22
    - 转账：https://opendocs.alipay.com/open/02byuo?scene=ca56bca529e64125a2786703c6192d41
    ```

  - SDK 

    ```
    把接口和参数进行封装，更简单的调用。
    ```

    ```
    pip install xxxxxx
    
    xxxxx.send(..)
    ```

- 案例

  - 支付

    ```
    1.点击支付按钮
    2.网关地址+构造URL参数（商品信息 + 签名信息）
    3.跳转 网关地址+构造URL参数，用户扫码->扫码界面
    4.支付宝跳转回去我们的界面，用于通知扫码成功结果。
    ```

    ```
    {
    	"app_id":"",
    	"method":"."
    	"biz_content":{
    		"out_trade_no":".."
    		"total_amount":"..."
    	},
    	
    }
    app_id=123&biz_content=asdfadfadfasdfasdf&method=asdf
    
    app_id=123&biz_content=asdfadfadfas%20ddfasdf&method=asdf&sign=asdfasdfad
    ```

    ```
    https://openapi.alipaydev.com/gateway.do?app_id=231....sign=sdfsdf
    ```

    ```
    NOTIFY_URL，发送POST请求通知支付成功。
    	https://opendocs.alipay.com/open/270/105902/
    	return HttpResponse("success")   -> 我知道他支付成功了
    	
    	支付宝服务器会不断重发通知，直到超过 24 小时 22 分钟。一般情况下，25 小时以内完成 8 次通知（通知的间隔频率一般是：4m,10m,10m,1h,2h,6h,15h）。
    	
    RETURN_URL，GET,为什么GET能访问呀？是基于js做的跳转。location.href = 地址
    ```

  - 提现，我们给对方账户转账

    ```
    ...
    ```

    



# 4.提前做（预习）



## 4.1 我的钱包页面

![image-20221211185805875](assets/image-20221211185805875.png)

![image-20221211185826751](assets/image-20221211185826751.png)



## 4.2 充值+转账

...







# 总结

- 跨域

- 静态资源

- 文件上传

- 百度AI调用

- drf相关

  - 认证组件，多个认证组件；

  - mixin

    ```
    增伤改查
    新增或更新
    ```

  - 序列化器

    ```
    self.context   request/view/format   -> 看源码
    ```

  - 视图类

    ```
    perform_create
    	instance = ser.save(...)
    perform_update
    	instance = ser.save(...)
    ```

  - 分页再看看

- 支付宝支付





































对于restful规范不要盲目的跟从，要解决实际情况来进行调整：

```
http://127.0.0.1:8000/api/shipper/auth/   
	GET  列表   request.user => user_id = company
	POST 新增
	
http://127.0.0.1:8000/api/shipper/auth/1/   【推荐】
	GET  单条信息
	PUT  更新
```

两种处理方案：

- 默认是0，登录成功后 用户ID返回，认证ID返回=0；

  ```
  1.用户登录成功，后端返回auth_id=0
  2.保存vuex
  3.state拿到
  ```

- 使用 `/api/shipper/auth/   ` + `request.user`









































































































