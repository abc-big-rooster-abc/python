// pages/info/info.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      name:"武沛齐",
      city:"北京",
      nameList:["武沛齐","张开","波波"],
      isHide:false
  },
  changeName(){
    //this.data.nameList.push("alex")
    
    var info = this.data.nameList;
    info.push("alex")
    console.log(info);

    this.setData({
      name:"张开",
      nameList:info
    });
  },
  doChange(e){
    //console.log("doChange",e.detail.value);
    this.setData({
      name:e.detail.value
    });
  },
  doChange2(e){
    
  },

  clickMe(e){
      console.log("点我了")
      console.log(e.target.dataset);
  },
  clickGo(e){

    //跳转，微信API
    wx.navigateTo({
      url: '/pages/mine/mine',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})