#!/usr/bin/env python
# -*- coding:utf-8 -*-

class DB(object):
    FRV_DATA_DICT = {}
    THRESHOLD = 60


db = DB()
