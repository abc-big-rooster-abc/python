# day31 小程序



# 1.环境搭建



## 1.1 开发者工具

https://mp.weixin.qq.com/cgi-bin/wx

![image-20230324100619762](assets/image-20230324100619762.png)

![image-20230324100715310](assets/image-20230324100715310.png)

![image-20230324100806700](assets/image-20230324100806700.png)



![image-20230324113228502](assets/image-20230324113228502.png)



## 1.2 账号注册

- 游客登录，本地开发没问题，发布和支付等功能无法使用。

- 注册小程序账号，后期发布代码等需要使用。

  - 个人版小程序

  - 企业版小程序（建议）

    ```
    后期支付业务需要企业版小程序 + 商户平台 + 账号绑定，才可以
    ```




https://mp.weixin.qq.com/

![image-20230325113953994](assets/image-20230325113953994.png)

![image-20230325114012429](assets/image-20230325114012429.png)

![image-20230325114029080](assets/image-20230325114029080.png)



![image-20230324195154376](assets/image-20230324195154376.png)



## 1.3 创建项目

![image-20230324113258744](assets/image-20230324113258744.png)

![image-20230324201343337](assets/image-20230324201343337.png)

![image-20230325114251043](assets/image-20230325114251043.png)



## 1.4 目录文件

```python
├── pages   					【页面文件目录】
│   ├── index					【页面】
│   │   ├── index.js				【页面JS】
│   │   ├── index.json				【页面配置】
│   │   ├── index.wxml				【页面HTML】
│   │   └── index.wxss				【页面CSS】
│   └── logs					【页面】
│       ├── logs.js					...
│       ├── logs.json				...
│       ├── logs.wxml				...
│       └── logs.wxss				...
├── utils						【自定义工具】
│	└── utils.js					【功能的定义】
├── app.js						【全局JS】
├── app.json					【全局配置】
├── app.wxss					【全局CSS】
├── project.config.json			【开发者工具默认配置】
├── project.private.config.json	【开发者工具用户配置】
├── .eslintrc.js				【ESlint语法检查配置】
├── sitemap.json				【微信收录页面，用于搜索】
```



# 2.纯净版项目

![image-20230325125530833](assets/image-20230325125530833.png)





# 3.快速上手



## 3.1 TabBar

```json
"tabBar": {
    "selectedColor": "#b4282d",
    "position": "bottom",
    "list": [
        {
            "pagePath": "pages/menu/menu",
            "text": "首页",
            "iconPath": "assets/img/home.png",
            "selectedIconPath": "assets/img/home_select.png"
        },
        {
            "pagePath": "pages/my/my",
            "text": "我的",
            "iconPath": "assets/img/my.png",
            "selectedIconPath": "assets/img/my_select.png"
        }
    ]
},
```





## 3.2 组件（标签）

https://developers.weixin.qq.com/miniprogram/dev/component/

- text，类似于span

  ```xml
  <text>武沛齐</text>
  ```

- view，类似于div

  ```xml
  <view>
      <view>源代码学城</view>
      <view>武沛齐</view>
      <view>微信：wupeiqi888</view>
  </view>
  ```

- image，类似于img标签

  ```xml
  <image src="/images/1.png" style="width: 750rpx;height: 400rpx;"></image>
  ```

- icon

  ```xml
  <icon type="success" size='198rpx' color="red"/>
  <icon type="download" size='198rpx' color="#ddd"/>
  ```

  ```
  success, success_no_circle, info, warn, waiting, cancel, download, search, clear
  ```

- 跳转，类似于a标签

  ```xml
  <navigator class="menu" url="/pages/index/index">
      <label class="fa fa-superpowers" style="color:#32CD32"></label>
    <view>信息采集</view>
  </navigator>
  ```
  
  ```xml
  <navigator 	open-type="switchTab" class="menu" url="/pages/index/index">
      <label class="fa fa-superpowers" style="color:#32CD32"></label>
      <view>信息采集</view>
  </navigator>
  ```
  
  绑定事件，在js中跳转：
  
  ```xml
  <view bindtap="clickMe" data-nid="123" >点我跳转</view>
  ```
  
  ```javascript
  Page({
    clickMe:function(e){
      var nid = e.currentTarget.dataset.nid;
      console.log(nid);
    }
  })
  ```
  
  ```
  wx.navigateTo({
  	url: '/pages/form/form'
  })
  ```
  
  ```
  wx.switchTab({
  	url: '/pages/my/my'
  })
  ```
  
  跳转到其他页面之后，可以在onLoad中获取参数，例如：
  
  ```
  wx.navigateTo({
  	url: '/pages/redirect/redirect?id='+nid
  })
  ```
  
  ```javascript
  Page({
    onLoad: function (options) {
      console.log(options);
    }
  })
  ```
  
  

## 3.2 数据绑定

https://developers.weixin.qq.com/miniprogram/dev/reference/wxml/



### 3.2.1 基本展示

```
<!--wxml-->
<view> {{message}} </view>
```

```js
// page.js
Page({
  data: {
    message: 'Hello MINA!'
  }
})
```



### 3.2.2 列表渲染

```xml
<!--wxml-->
<!--pages/goods/goods.wxml-->
<text>商品列表</text>
<view>
  <view wx:for="{{dataList}}" >{{index}} -  {{item}}</view>
  <view wx:for="{{dataList}}" wx:for-index="idx" wx:for-item="x">		{{idx}} -  {{x}}
  </view>
    
</view>
<view>
  {{userInfo.name}}
  {{userInfo.age}}
</view>
<view>
  <view wx:for="{{userInfo}}">{{index}} - {{item}}</view>
</view>
```

```javascript
// page.js
Page({
  data: {
    dataList:["武沛齐","张开","关闭"],
    userInfo:{
      name:"alex",
      age:18
    }
  }
})

```



### 3.2.3 条件

```xml
<!--wxml-->
<view wx:if="{{view == 'WEBVIEW'}}"> WEBVIEW </view>
<view wx:elif="{{view == 'APP'}}"> APP </view>
<view wx:else="{{view == 'MINA'}}"> MINA </view>
```

```javascript
Page({
  data: {
    view: 'MINA'
  }
})
```



关于block：

```xml
<block wx:if="{{true}}">
  <view> view1 </view>
  <view> view2 </view>
</block>
```

**注意：** `<block/>` 并不是一个组件，它仅仅是一个包装元素，不会在页面中做任何渲染，只接受控制属性。



关于hidden：

```xml
<view hidden="{{false}}">
  <icon type="success" size='198rpx' color="red"/>
  <icon type="download" size='198rpx' color="#ddd"/>
</view>
```



### 3.2.4 双向绑定

- wxml

  ```xml
  <view> {{city}} </view>
  
  <input value="{{city}}" bindinput="textBind" />
  ```

  ```xml
  <input model:value="{{city}}" bindinput="textBind" />
  ```

- 修改数据

  ```javascript
  // pages/info/info.js
  Page({
      data: {
          city:"北京"
      },
      textBind(e){
          //console.log(e);
          this.setData({city:e.detail.value});
      }
  }
  ```



## 3.4 样式

### 3.4.1 像素

- px
- rpx，750rpx（小程序）



### 3.4.2 flex布局

一种非常方便的布局方式。 

在容器中记住4个样式即可。

```css
display: flex;   				flex布局
flex-direction: row;			规定主轴的方向：row/column
justify-content: space-around;	元素在主轴方向上的排列方式:flex-start/flex-end/space-around/space-between		
align-items: center;			元素在副轴方向上的排列方式:flex-start/flex-end/space-around/space-between		
```



## 3.5 fontawesome

内置的icon不够用，可以引入fontawesome图库

https://fontawesome.com.cn/v4/icons

https://cloud.tencent.com/developer/article/1969962



## 3.5 API

微信小程序中为我们提供的功能，例如：发送请求、弹窗、拍照等。

https://developers.weixin.qq.com/miniprogram/dev/api/



### 3.5.1 showToast

```javascript
wx.showToast({
  title: '成功',
  icon: 'success',
  duration: 2000
})
```

```
wx.hideToast()
```



### 3.5.2 showLoading

```javascript
wx.showLoading({
  title: '加载中',
})

setTimeout(function () {
  wx.hideLoading()
}, 2000)
```



### 3.5.3 showModal

```javascript
wx.showModal({
  title: '提示',
  content: '这是一个模态弹窗',
  success (res) {
    if (res.confirm) {
      console.log('用户点击确定')
    } else if (res.cancel) {
      console.log('用户点击取消')
    }
  }
})
```

### 3.5.4 showActionSheet

```javascript
 wx.showActionSheet({
     itemList: ['中共重要', 'B', 'C'],
     itemColor:"#9ff9ff",
     success (res) {
         console.log(res.tapIndex)
     },
     fail (res) {
         console.log(res.errMsg)
     }
 })
```



### 3.5.5 request

```javascript
wx.request({
  method:"GET",
  url: 'example.php', //仅为示例，并非真实的接口地址
  data: {
    x: '',
    y: ''
  },
  header: {
    'content-type': 'application/json' // 默认值
  },
  dataType:"json",
  success (res) {
    console.log(res.data)
  }
})
```



### 3.5.6 uploadFile

```javascript
wx.uploadFile({
    url: 'https://example.weixin.qq.com/upload', 
    filePath: tempFilePaths[0],
    name: 'file',
    formData: {
        'user': 'test'
    },
    success (res){
        const data = res.data
        //do something
	}
})
```











































