<template>
    <h2>发布运单</h2>
</template>

<script>
export default {
    name: "PubView"
}
</script>

<style scoped>

</style>
