<template>
    <div class="main">
        <div style="width: 1000px;margin: 10px auto;">
            <el-card class="box-card" shadow="never">
                <template #header>
                    <div class="card-header">
                        <span>用户注册</span>
                    </div>
                </template>
                <div>
                    <div style="width: 460px;margin: 20px auto;">
                        <el-form size="large" :model="state.form" :rules="state.rules" ref="regRef" label-width="80px">
                            <el-form-item style="margin-top: 24px;" prop="name" :error="state.errors.name" label="企业简称">
                                <el-input v-model="state.form.name" placeholder="请输入企业简称"/>
                            </el-form-item>

                            <el-form-item style="margin-top: 24px;" prop="mobile" :error="state.errors.mobile"
                                          label="手机号">
                                <el-input v-model="state.form.mobile" placeholder="手机号"/>
                            </el-form-item>

                            <el-form-item style="margin-top: 24px;" prop="code" :error="state.errors.code" label="验证码">
                                <el-row justify="space-between" style="width: 100%">
                                    <el-input v-model="state.form.code" placeholder="验证码" style="width: 220px"/>
                                    <el-button>发送短信</el-button>
                                </el-row>
                            </el-form-item>

                            <el-form-item style="margin-top: 24px;" prop="pwd" :error="state.errors.password"
                                          label="密码">
                                <el-input v-model="state.form.password" placeholder="密码"/>
                            </el-form-item>

                            <el-form-item style="margin-top: 24px;" prop="confirm_password"
                                          :error="state.errors.confirm_password"
                                          label="重复密码">
                                <el-input v-model="state.form.confirm_password" placeholder="重复密码"/>
                            </el-form-item>

                            <el-form-item style="margin-top: 24px;">
                                <el-button type="primary" @click="doRegister">注 册</el-button>
                            </el-form-item>


                        </el-form>
                    </div>
                </div>
            </el-card>
        </div>
    </div>

</template>

<script setup>
// 用户名和密码登录
import {getCurrentInstance, reactive} from "vue";
import {ElMessage} from "element-plus";
import {useRouter} from "vue-router";
import {validateFormError, clearFormError} from '../plugins/form'

const router = useRouter()
const {proxy} = getCurrentInstance()


const validatePass2 = (rule, value, callback) => {
    if (value === '') {
        callback(new Error('重复密码不能为空'))
    } else if (value !== state.form.password) {
        callback(new Error("密码不一致"))
    } else {
        callback()
    }
}

const state = reactive({
    form: {
        name: '大和药业',
        mobile: '18630087660',
        code: '12312',
        password: 'qwe123',
        confirm_password: 'qwe123'
    },
    rules: {
        name: [
            {required: true, message: '企业名称不能为空', trigger: 'blur'},
        ],
        mobile: [
            {required: true, message: '手机号不能为空', trigger: 'blur'},
            //{ pattern:/^[a-z]+$/, message: '格式错误', trigger: 'blur'},
        ],
        code: [
            {required: true, message: '验证码不能为空', trigger: 'blur'},
        ],
        password: [
            {required: true, message: '密码不能为空', trigger: 'blur'},
            {min: 6, max: 28, message: '密码长度至少6个字符', trigger: 'blur'}
        ],
        confirm_password: [
            {required: true, message: '密码不能为空', trigger: 'blur'},
            {validator: validatePass2, trigger: 'blur'},
        ]
    },
    errors: {
        name: '',
        mobile: '',
        code: '',
        password: '',
        confirm_password: '',
    }
})

/**
 * 注册
 */
function doRegister() {
    // 清除自定义错误
    clearFormError(state.errors)

    // 表单验证 ref 属性
    // this.$refs.userRef
    proxy.$refs.regRef.validate((valid) => {
        // 校验失败
        if (!valid) {
            return false;
        }
        // 校验成功，发送网络请求（基于axios发送）
        console.log("校验成功", state.form)
        proxy.$axios.post(
            "/api/shipper/register/",
            state.form
        ).then((res) => {
            if (res.data.code === 0) {
                // 跳转到登录
                ElMessage.success("注册成功");
                router.push({name: "Login"})
            } else if (res.data.code === -1) {
                validateFormError(state.errors, res.data.detail);
            } else {
                ElMessage.error(res.data.msg);
            }
        })

    });

}

</script>

<style scoped>
.main {
    background-color: #f5f5f5;
    height: calc(100vh - 72px);
}

</style>
