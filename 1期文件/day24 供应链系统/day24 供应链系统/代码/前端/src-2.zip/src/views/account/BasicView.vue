<template>
    <div>
        <el-card class="box-card" v-loading="state.loading">
            <template #header>
                <div class="card-header">
                    <span style="font-weight: bold;font-size: 18px;">基本信息</span>
                </div>
            </template>
            <div style="padding: 0 20px">
                <el-row justify="start">
                    <el-row justify="center" align="middle">
                        <img src="../../assets/avatar.png" style="height: 90px;">
                    </el-row>
                    <div class="info">
                        <div>
                            <span>用户ID：</span>
                            <span>{{ state.model.id }}</span>
                        </div>
                        <div>
                            <span>注册时间：</span>
                            <span>{{ state.model.ctime }}</span>
                        </div>

                        <el-tag v-if="state.model.auth_type===3" style="margin-top: 10px;" type="success">
                            {{ state.model.auth_type_text }}
                        </el-tag>
                        <div>
                            <el-tag style="margin-top: 10px;" type="danger">{{ state.model.auth_type_text }}</el-tag>
                            <router-link :to="{name:'Auth'}">
                                <el-link type="info" style="font-weight: normal;margin-left: 10px;"> 点击前往认证</el-link>
                            </router-link>
                        </div>

                    </div>
                </el-row>

                <el-divider border-style="dotted"/>

                <div class="rows">
                    <div class="group">
                        <div class="key">
                            <el-icon>
                                <User/>
                            </el-icon>
                            <span>用户名</span>
                        </div>

                        <div class="txt">{{ state.model.name }}</div>
                    </div>
                    <div>
                        <a class="link" href="#" @click="userDialogVisible = true">
                            <el-icon>
                                <Edit/>
                            </el-icon>
                            修改
                        </a>
                    </div>
                </div>

                <el-divider border-style="dotted"/>

                <div class="rows">
                    <div class="group">
                        <div class="key">
                            <el-icon>
                                <Iphone/>
                            </el-icon>
                            <span>绑定手机</span>
                        </div>

                        <div class="txt">您已绑定 {{ state.model.mobile }}（该手机号用于登录、找回密码）</div>
                    </div>
                    <div>
                        <a class="link" href="#" @click="mobileDialogVisible = true">
                            <el-icon>
                                <Edit/>
                            </el-icon>
                            修改
                        </a>
                    </div>
                </div>
                <el-divider border-style="dotted"/>

                <el-row justify="center" align="middle" style="height: 80px;">
                    <el-button type="primary" style="width: 200px;height: 40px;">退出登录</el-button>
                </el-row>

            </div>
        </el-card>


        <el-dialog v-model="userDialogVisible" title="修改用户名称" width="30%">
            <div>
                <el-form :model="state.userDialog.form" :rules="state.userDialog.rules" ref="userRef"
                         label-width="80px">
                    <el-form-item style="margin-top: 24px;" prop="name" :error="state.userDialog.errors.name"
                                  label="企业名称">
                        <el-input v-model="state.userDialog.form.name" placeholder="建议企业名称简写"></el-input>
                    </el-form-item>
                    <el-row justify="center" align="middle" style="height: 80px;">
                        <el-button type="primary" style="width: 200px;height: 40px;" @click="doUpdateName">提交审核
                        </el-button>
                    </el-row>
                </el-form>
            </div>
        </el-dialog>

        <el-dialog v-model="mobileDialogVisible" title="修改绑定手机" width="30%">
            <div>
                <el-form :model="state.mobileDialog.form" label-width="80px">

                    <el-form-item style="margin-top: 24px;" :error="state.mobileDialog.errors.old" label="原手机号">
                        <el-input v-model="state.mobileDialog.form.old" placeholder="原手机号"></el-input>
                    </el-form-item>

                    <el-form-item style="margin-top: 24px;" :error="state.mobileDialog.errors.mobile" label="新手机号">
                        <el-input v-model="state.mobileDialog.form.mobile" placeholder="新手机号"></el-input>
                    </el-form-item>

                    <el-row justify="center" align="middle" style="height: 80px;">
                        <el-button type="primary" style="width: 200px;height: 40px;" @click="doUpdateMobile">提交审核
                        </el-button>
                    </el-row>
                </el-form>
            </div>
        </el-dialog>
    </div>
</template>

<script setup>
import {User, Edit, Iphone} from '@element-plus/icons-vue'
import {getCurrentInstance, reactive, onMounted, ref} from 'vue'
import {useStore} from 'vuex'
import {ElMessage} from "element-plus";
import {validateFormError, clearFormError} from '../../plugins/form'

const store = useStore();
const {proxy} = getCurrentInstance()

const state = reactive({
    model: {
        id: "",
        name: "",
        mobile: "",
        ctime: "",
        auth_type: "",
        auth_type_text: "",
    },
    loading: true,
    userDialog: {
        form: {
            name: ""
        },
        rules: {
            name: [
                {required: true, message: '企业名称不能为空', trigger: 'blur'},
            ]
        },
        errors: {
            name: ""
        }
    },
    mobileDialog: {
        form: {
            old: "",
            mobile: ""
        },
        errors: {
            old: "",
            mobile: ""
        }
    }
})

const userDialogVisible = ref(false)
const mobileDialogVisible = ref(false)

function doUpdateName() {
    clearFormError(state.userDialog.errors);

    let id = store.state.id;
    proxy.$axios.patch(`/api/shipper/basic/${id}/?type=name`, state.userDialog.form).then((res) => {
        if (res.data.code === 0) {
            state.model.name = res.data.data.name;
            userDialogVisible.value = false;
            ElMessage.success("更新成功");
        } else if (res.data.code === -1) {
            validateFormError(state.userDialog.errors, res.data.detail);
        } else {
            ElMessage.error(res.data.msg);
        }
    })
}

function doUpdateMobile() {
    clearFormError(state.mobileDialog.errors);

    let id = store.state.id;
    proxy.$axios.patch(`/api/shipper/basic/${id}/?type=mobile`, state.mobileDialog.form).then((res) => {
        if (res.data.code === 0) {
            state.model.mobile = res.data.data.new_mobile; // new_mobile中间 ****
            mobileDialogVisible.value = false;
            ElMessage.success("更新成功");

        } else if (res.data.code === -1) {
            validateFormError(state.mobileDialog.errors, res.data.detail);
        } else {
            ElMessage.error(res.data.msg);
        }
    })
}

function initRequest() {
    let id = store.state.id;
    // let id = 2;
    proxy.$axios.get(`/api/shipper/basic/${id}/`).then((res) => {
        if (res.data.code === 0) {
            state.model = res.data.data;
            state.userDialog.form.name = res.data.data.name;
            state.loading = false;
        } else {
            ElMessage.error(res.data.msg);
        }

    })
}

onMounted(() => {
    initRequest()
})
</script>


<style scoped>
.info {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;

    margin-left: 20px;
}

.info > div {
    font-size: 14px;
    padding: 2px 0;
    color: #666;
}

.rows {
    display: flex;
    justify-content: space-between;
}

.rows .group {
    display: flex;
}

.rows .group .key {
    display: flex;
    align-items: center;
    width: 200px;
    font-size: 18px;
}

.rows .group .key span {
    display: inline-block;
    margin-left: 10px;
}

.rows .group .txt {
    font-size: 14px;
    color: #666;
}

.rows .link {
    display: flex;
    align-items: center;
    color: #0088f5;
    font-size: 14px;
}
</style>

