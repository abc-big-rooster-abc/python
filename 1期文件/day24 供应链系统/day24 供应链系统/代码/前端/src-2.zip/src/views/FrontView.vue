<template>
    <div class="main">
        <el-container style="height: 100%">
            <el-aside width="300px">
                <!-- <router-link :to="{name:'Basic'}">基本信息</router-link>-->
                <!-- <router-link :to="{name:'Auth'}">实名认证</router-link>-->
                <el-scollbar>
                    <el-menu :default-active="activeRouter" :router="true">

                        <el-menu-item index="Home" :route="{name:'Home'}">
                            <el-icon>
                                <IconMenu/>
                            </el-icon>
                            <span>首页</span>
                        </el-menu-item>

                        <el-sub-menu index="user">
                            <template #title>
                                <el-icon>
                                    <User/>
                                </el-icon>
                                <span>会员中心</span>
                            </template>

                            <el-menu-item index="Basic" :route="{name:'Basic'}">基本信息</el-menu-item>
                            <el-menu-item index="Auth" :route="{name:'Auth'}">账号认证</el-menu-item>
                            <el-menu-item index="Wallet" :route="{name:'Wallet'}">我的钱包</el-menu-item>
                        </el-sub-menu>

                        <el-sub-menu index="order">
                            <template #title>
                                <el-icon>
                                    <Box/>
                                </el-icon>
                                <span>运单中心</span>
                            </template>

                            <el-menu-item index="Pub" :route="{name:'Pub'}">发布运单</el-menu-item>
                            <el-menu-item index="PubList" :route="{name:'PubList'}">运单管理</el-menu-item>
                        </el-sub-menu>

                    </el-menu>
                </el-scollbar>

            </el-aside>
            <el-main class="body">
                <router-view></router-view>
            </el-main>
        </el-container>
    </div>
</template>

<script setup>
import {Menu as IconMenu, Box, User} from '@element-plus/icons-vue'
import {useRoute} from 'vue-router'
import {computed} from 'vue'

//1.获取当前路由
const route = useRoute();

//2.设置
const activeRouter = computed(() => route.name);
</script>

<style scoped>
.el-menu {
    border-right: 0;
}

.main {
    height: calc(100vh - 72px);
}

.body {
    background-color: #f5f5f5;
}
</style>
