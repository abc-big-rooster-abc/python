<template>
    <h2>运单管理</h2>
</template>

<script>
export default {
    name: "PubListView"
}
</script>

<style scoped>

</style>
