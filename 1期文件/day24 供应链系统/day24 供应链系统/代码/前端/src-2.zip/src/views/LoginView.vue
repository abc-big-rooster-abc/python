<template>
    <div class="main">
        <div class="login-box">
            <div class="tab-box-switch">
                <ul class="switch-ul">
                    <li @click="tabSelected=index" :class="tabSelected === index?'tab-active' : ''"
                        v-for="(txt,index) in tabList" :key="index">{{ txt }}
                    </li>
                </ul>

                <div v-show="tabSelected===0">
                    <el-form size="large" :model="userModel" :rules="userRules" ref="userRef">
                        <el-form-item style="margin-top: 24px;" prop="mobile" :error="userError.mobile">
                            <el-input v-model="userModel.mobile" placeholder="手机号"/>
                        </el-form-item>
                        <el-form-item style="margin-top: 24px;" prop="password" :error="userError.password">
                            <el-input v-model="userModel.password" placeholder="密码"/>
                        </el-form-item>
                        <el-form-item style="margin-top: 24px;">
                            <el-button @click="doPwdLogin" type="primary">登 录</el-button>
                        </el-form-item>
                    </el-form>

                </div>
                <div v-show="tabSelected===1">
                    <el-form size="large" :model="smsModel" :rules="smsRules" ref="smsRef">
                        <el-form-item style="margin-top: 24px;" prop="mobile" :error="smsError.mobile">
                            <el-input v-model="smsModel.mobile" placeholder="手机号"/>
                        </el-form-item>
                        <el-form-item style="margin-top: 24px;" prop="code" :error="smsError.code">
                            <el-row justify="space-between" style="width: 100%">
                                <el-input v-model="smsModel.code" placeholder="验证码" style="width: 220px"/>
                                <el-button :disabled="btnSmsDisabled" @click="doSendSms">{{ bntSmsText }}</el-button>
                            </el-row>
                        </el-form-item>
                        <el-form-item style="margin-top: 24px;">
                            <el-button type="primary" @click="doSmsLogin">登 录</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
        </div>

    </div>
</template>

<script setup>
import {ref, reactive, getCurrentInstance} from 'vue'
import {ElMessage} from 'element-plus'
import {useStore} from 'vuex'
import {useRouter} from 'vue-router'
import {validateFormError, clearFormError} from '../plugins/form'

const store = useStore();
const router = useRouter();


const {proxy} = getCurrentInstance()

// 登录模式
let tabSelected = ref(0)
const tabList = reactive(["密码登录", "免密码登录"])

// 用户名和密码登录
const userModel = reactive({
    mobile: '18630087660',
    password: 'root123',
})
const userRules = reactive({
    mobile: [
        {required: true, message: '手机不能为空', trigger: 'blur'},
    ],
    password: [
        {required: true, message: '密码不能为空', trigger: 'blur'},
        //{ pattern:/^[a-z]+$/, message: '格式错误', trigger: 'blur'},
        // {min: 6, max: 28, message: '密码长度至少6个字符', trigger: 'blur'}
    ]
})
const userError = reactive({
    mobile: '',
    password: '',
})


// 短信登录
const smsModel = reactive({
    mobile: '18630087660',
    code: '',
})
const smsRules = reactive({
    mobile: [
        {required: true, message: '手机号不能空', trigger: 'blur'},
    ],
    code: [
        {required: true, message: '验证码不能为空', trigger: 'blur'},
    ]
})
const btnSmsDisabled = ref(false);
const bntSmsText = ref("发送验证码")
const smsError = reactive({
    mobile: '',
    code: '',
})

/**
 * 用户名和密码登录
 */
function doPwdLogin() {

    // 清除自定义错误
    clearFormError(userError)

    // 表单验证 ref 属性
    // this.$refs.userRef
    proxy.$refs.userRef.validate((valid) => {
        // 校验失败
        if (!valid) {
            console.log("校验失败");
            return false;
        }

        // 校验成功，发送网络请求（基于axios发送）
        console.log("校验成功", userModel)
        proxy.$axios.post(
            "/api/shipper/login/",
            userModel
        ).then((res) => {
            // {"code":-1,"msg":"error","detail":{"user":["该字段不能为空。"],"pwd":["该字段不能为空。"]}}
            if (res.data.code === 0) {
                // 登录成功
                console.log("登录成功", res.data)
                // 1.保存到vuex + 持久化
                store.commit("login", res.data.data);
                // 2.跳转到后台
                router.replace({name: "Basic"})

                // proxy.$store.commit("login", res.data.data);
                // proxy.router({name: "Basic"})
            } else if (res.data.code === -1) {
                // {code: -1, error: {user: "用户名错误", pwd: "密码格式出问题了"}}
                validateFormError(userError, res.data.detail);
            } else {
                //{"code": -2, 'msg': "用户名或密码错误"}
                ElMessage.error(res.data.msg);
            }

        })

    });

}


/**
 * 短信登录
 */
function doSmsLogin() {

    clearFormError(smsError);

    proxy.$refs.smsRef.validate((valid) => {
        // 校验失败
        if (!valid) {
            // console.log("校验失败");
            return false;
        }

        // 校验成功，发送网络请求（基于axios发送）
        // console.log("校验成功", smsModel)
        // 1.请求成功，token写入vuex + 跳转
        // 2.错误提示
        // ElMessage.error('用户名或密码错误');
        // let res = {code: -1, error: {mobile: "手机号已存在", code: "验证失效"}}
        // validateFormError(smsError, res.error);
        proxy.$axios.post(
            "/api/shipper/login/sms/",
            smsModel
        ).then((res) => {
            // {"code":-1,"msg":"error","detail":{"user":["该字段不能为空。"],"pwd":["该字段不能为空。"]}}
            if (res.data.code === 0) {
                // 登录成功
                // console.log("登录成功", res.data)
                // 1.保存到vuex + 持久化
                store.commit("login", res.data.data);
                // 2.跳转到后台
                router.replace({name: "Basic"})

                // proxy.$store.commit("login", res.data.data);
                // proxy.router({name: "Basic"})
            } else if (res.data.code === -1) {
                // {code: -1, error: {user: "用户名错误", pwd: "密码格式出问题了"}}
                validateFormError(smsError, res.data.detail);
            } else {
                //{"code": -2, 'msg': "用户名或密码错误"}
                ElMessage.error(res.data.msg);
            }
        })

    });
}

/**
 * 发送短信
 */
function doSendSms() {
    // 1.校验手机号
    proxy.$refs.smsRef.validateField("mobile", (valid) => {
        // 校验失败
        if (!valid) {
            console.log("校验失败");
            return false;
        }
        // 2.校验成功，发送网络请求（基于axios发送）
        // console.log("校验成功", smsModel.mobile)
        proxy.$axios.post(
            "/api/shipper/send/sms/",
            {
                mobile: smsModel.mobile
            }
        ).then((res) => {
            if (res.data.code === 0) {
                // 提示
                ElMessage.success("发送成功");
                // 倒计时
                btnSmsDisabled.value = true;
                let txt = 5;
                let interval = window.setInterval(() => {
                    txt -= 1;
                    bntSmsText.value = `${txt}秒后重发`
                    if (txt < 1) {
                        bntSmsText.value = "重新发送";
                        // 停止定时器
                        window.clearInterval(interval);
                        btnSmsDisabled.value = false;
                    }
                }, 1000)
            } else if (res.data.code === -1) {
                // {code: -1, error: {user: ["用户名错误",] pwd: "密码格式出问题了"}}
                validateFormError(smsError, res.data.detail);
            } else {
                //{"code": -2, 'msg': "用户名或密码错误"}
                ElMessage.error(res.data.msg);
            }
        })

        // 3.发送成功，倒计时效果
    })


}


</script>

<style scoped>
.main {
    background-color: #f5f5f5;
    height: calc(100vh - 72px);
}

.login-box {
    width: 350px;
    min-height: 200px;
    background-color: white;
    margin: 150px auto;
    border-radius: 2px;

    padding: 0 44px 10px;
    box-shadow: 0 1px 3px rgba(26, 26, 26, 0.1);
}


.tab-box-switch .switch-ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tab-box-switch .switch-ul li {
    display: inline-block;
    height: 60px;
    font-size: 16px;
    line-height: 60px;
    margin-right: 24px;
    cursor: pointer;
}

.tab-active {
    position: relative;
    color: #1a1a1a;
    font-weight: 600;
    font-synthesis: style;
}


.tab-active::before {
    display: block;
    position: absolute;
    bottom: 0;
    content: "";
    width: 100%;
    height: 3px;
    background-color: #0084ff;
}
</style>
