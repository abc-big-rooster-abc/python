<template>
    <el-empty description="页面没找到"/>
</template>

<script>
export default {
    name: "NotFoundView"
}
</script>

<style scoped>

</style>
