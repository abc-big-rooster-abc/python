from rest_framework import serializers
from rest_framework import exceptions
from rest_framework.authentication import BaseAuthentication
from rest_framework.permissions import BasePermission
from rest_framework.throttling import BaseThrottle
from . import models
from utils.exceptions import ExtraException

from rest_framework.viewsets import ModelViewSet


# from utils.viewsets import ModelViewSet


class ExtraAuthentication(BaseAuthentication):
    def authenticate(self, request):
        raise exceptions.AuthenticationFailed("认证失败")
        # raise exceptions.AuthenticationFailed({"code": 11, "msg": "123"})

    def authenticate_header(self, request):
        return "api"


class ExtraPermission(BasePermission):
    def has_permission(self, request, view):
        return False

    def has_object_permission(self, request, view, obj):
        return False


class ExtraThrottle(BaseThrottle):
    def allow_request(self, request, view):
        return False


class DemoModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.UserInfo
        fields = "__all__"


class DemoView(ModelViewSet):
    # authentication_classes = [ExtraAuthentication, ]
    # permission_classes = [ExtraPermission, ]
    # throttle_classes = [ExtraThrottle, ]
    queryset = models.UserInfo.objects.all()
    serializer_class = DemoModelSerializer

    def perform_create(self, serializer):
        self.dispatch
        # 余额是否足够，自定义异常
        # raise ExtraException("余额不足", 9999)
        # int("asdf")
        serializer.save()

