from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import HttpResponse
from django.http import JsonResponse
from rest_framework.response import Response


class ReturnCodeMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        if not hasattr(response, 'exception'):
            return response

        if response.exception:
            return response

        response.data = {'code': 0, 'data': response.data}
        response._is_rendered = False
        response.content = response.render().content
        return response
