from rest_framework.exceptions import APIException


class ExtraException(APIException):
    def __init__(self, detail=None, ret_code=None, code=None):
        super().__init__(detail, code)
        self.ret_code = ret_code
