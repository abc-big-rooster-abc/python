import settings
import logging

# 3. 写日志
run = logging.getLogger('run')
run.info("测试测1111")
