# day20 vue3+前后端分离



# 1.回顾和扩展



## 1.1 常见ES6



### 1.变量和常量

```
var/let/const
```

```html
<script>
    function show(){
        if(1==1){
            var name = "武沛齐";  //函数作用域=Python
        }
        consolo.log(name);
    }
    show();
</script>
```

```html
<script>
    if(1==1){
    	let age = 19;  // 块级作用域
    }
    console.log(age);
</script>
```

```html
<script>
    if(1==1){
    	const age = 19;  // 块级作用域 + 常量（ref）
    }
    console.log(age);
</script>
```

```html
<script>
    const info = {id:1,value:18};  // 块级作用域 + 常量（ref）
    
    info.value = 999;
</script>
```



### 2.模板字符串

```javascript
let info = "我是" + "?" + "今年技术";
```

```html
<script>
    let name = "张开";
    let age = 73;
    
	let info =  `我叫${name}，今年${age}岁`;
</script>
```



### 3.动态参数

```html
<script>
	function info(v1,...data){
        console.log(v1,data);
    }
	info(11);
    info(11,22);
    info(11,22,333,444,55);
</script>
```

```html
<script>
	function info(v1,v2,v3,v4){
        console.log(v1,v2,v3,v4);
    }

    info(11,22,333,444);
    nums = [22,33,44,55,66,77,88];
    info(11,...nums)
</script>
```



### 4.解构赋值

```html
<script>
	let info = {name:"武沛齐",email:"wupeiqi@live.com",addr:"北京"};
	let {name,addr} = info;
    
    console.log(name);
    console.log(addr);
</script>
```

Vue3中需要什么就要导入什么，不像vue2中`this.$router` `this.$route`。

```
import {name,addr} from 'vue'
```

```html
<script>
    
    function getData(n1,{name,addr}){
    	//let {name,addr} = info; 
        
	    console.log(name);
		console.log(addr);
    }
    
    let info = {name:"武沛齐",email:"wupeiqi@live.com",addr:"北京"};
    getData(111,info);
	
</script>
```

```
      前端                                    API
     发送请求                ->               返回
    对象.code
```

---

```html
<script>
    let nums = [11,22,33,44];
    let [n1,n2] = nums;
</script>
```

```html
<script>
    function getData(n1,[n2,n3,n4]){
        console.log(n1,n2,n3,n4)
    }
    let nums = [11,22,33,44];
    getData(100,nums);
</script>
```



### 5.箭头函数

注意：发送网络请求时，回调函数必须要使用箭头函数。

```html
<script>
	function f1(name,age){
        console.log(name,age);
    }
    f1("张开",99);
	
    //箭头函数
    let f2 = (name,age) =>{
        console.log(name,age);
    }
    f2("张开",99);
</script>
```



----

```html
<script>
    var name = "源代码";
    let info = {
        name: "武沛齐",
        func: function () {
            console.log(this.name); // 函数内部默认都有this关键字
        }
    }
    info.func();

    function getData() {
        console.log(this.name); // 函数内部默认都有this关键字，this=window
    }

    getData();
</script>
```

```html
<script>
    var name = "源代码";
    let info = {
        name: "武沛齐",
        func: function () {
            console.log(this.name); // 函数内部默认都有this关键字,this=info对象

            function getData() {
                console.log(this.name); // 函数内部默认都有this关键字，this=window
            }
            getData();
        }
    }
    info.func();
</script>
```

```html
<script>
    var name = "源代码";
    let info = {
        name: "武沛齐",
        func: function () {
            console.log(this.name); // 函数内部默认都有this关键字,this=info对象

            let getData = () => {
                console.log(this.name); // 函数内部默认都有this关键字
            }
            getData();
        }
    }
    info.func();


</script>
```

---

```html
<script src="https://cdn.bootcdn.net/ajax/libs/axios/0.21.1/axios.min.js"></script>
<script>

    let info = {
        data: null,
        send: function () {
            axios({
                method: "post",
                url: "https://api.luffycity.com/api/v1/auth/password/login/?loginWay=password",
                data: {
                    username: "alex",
                    password: "dsb"
                },
                headers: {
                    "content-type": "application/json"
                }
            }).then(function (res) {
                console.log(this,res);
                this.data = res;
            })
        }
    }
    info.send();
</script>
```

```html
<script src="https://cdn.bootcdn.net/ajax/libs/axios/0.21.1/axios.min.js"></script>
<script>

    let info = {
        data: null,
        send: function () {
            axios({
                method: "post",
                url: "https://api.luffycity.com/api/v1/auth/password/login/?loginWay=password",
                data: {
                    username: "alex",
                    password: "dsb"
                },
                headers: {
                    "content-type": "application/json"
                }
            }).then((res) => {
                console.log(this,res);
                this.data = res;
            })
        }
    }
    info.send();
</script>
```



### 6.模块

![image-20221113100640595](assets/image-20221113100640595.png)

![image-20221113100708949](assets/image-20221113100708949.png)

![image-20221113100834135](assets/image-20221113100834135.png)

## 1.2 关于环境

- 关于node.js
  ![image-20221113102414428](assets/image-20221113102414428.png)

  ```
  =======如果想要更新node.js的版本=======
  
  1.先查看本机node.js版本：
  	node -v
  	
  2.清除node.js的cache：
  	sudo npm cache clean -f
  
  3.安装 n 工具，这个工具是专门用来管理node.js版本的，别怀疑这个工具的名字，是他是他就是他，他的名字就是 "n"（科学上网）
  	sudo npm install -g n
  
  4.安装最新版本的node.js
  	sudo n stable
  
  5.再次查看本机的node.js版本：
  	node -v
  ```

- 关于npm

  ```
  sudo npm install npm@latest -g
  ```

  ```
  npm config set registry https://registry.npm.taobao.org
  
  npm install -g cnpm --registry=https://registry.npm.taobao.org
  ```

- vue-cli

  ```
  # 安装（最新版）
  sudo npm install -g @vue/cli
  
  # 安装（指定版本）
  sudo npm install -g @vue/cli@5.0.8
  
  # 卸载
  sudo npm uninstall -g @vue/cli
  ```

  ```
  @vue/cli@5.0.8
  ```

  

## 1.3 创建项目

- 命令
- WebStorm

![image-20221113103525514](assets/image-20221113103525514.png)



## 1.4 项目部署

具体步骤如下：

- 第一步：编译

  ```
  npm run build
  ```

- 第二步：将编译后的代码dist文件上传到服务器（阿里云、腾讯云）

  ![image-20220312123432759](assets/image-20220312123432759.png)

- 第三步：安装nginx + 配置 + 启动

  ```
  yum install nginx
  ```


  vim /etc/nginx/nginx.conf

  ```
  user nginx;
  worker_processes auto;
  error_log /var/log/nginx/error.log;
  pid /run/nginx.pid;
  
  # Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
  include /usr/share/nginx/modules/*.conf;
  
  events {
      worker_connections 1024;
  }
  
  http {
      log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                        '$status $body_bytes_sent "$http_referer" '
                        '"$http_user_agent" "$http_x_forwarded_for"';
  
      access_log  /var/log/nginx/access.log  main;
  
      sendfile            on;
      tcp_nopush          on;
      tcp_nodelay         on;
      keepalive_timeout   65;
      types_hash_max_size 4096;
  
      include             /etc/nginx/mime.types;
      default_type        application/octet-stream;
  
      include /etc/nginx/conf.d/*.conf;
  
      server {
          listen       80;
          listen       [::]:80;
          server_name  _;
          # 项目目录
          root         /data/mysite;
  
          # Load configuration files for the default server block.
          include /etc/nginx/default.d/*.conf;
  
          error_page 404 /404.html;
          location = /404.html {
          }
  
          error_page 500 502 503 504 /50x.html;
          location = /50x.html {
          }
      }
  }
  ```

  ```
  >>>systemctl start nginx
  >>>systemctl restart nginx
  ```

- 第四步：访问
  ![image-20221112172411638](assets/image-20221112172411638.png)





# 2.flex布局

- 传统的页面布局：div+css+float实现。
- flex布局更简单。

```html
<div class='menu'>
	<div class='item'>北京</div>
	<div class='item'>上海</div>
</div>
```



## 2.1 容器



### 1.布局

```html
<div class='menu'>
	<div class='item'>北京</div>
	<div class='item'>上海</div>
</div>

<style>
    .menu{
        
        display:flex;
    }
</style>
```



### 2.元素方向

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
</div>


</body>
</html>

```

### 3.元素排列方式

```
justify-content: 主轴
align-items: 副轴
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/
            /*justify-content: space-evenly;*/
            justify-content: space-between;

        }
        .menu .item{
            width: 45px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
    <div class='item'>深圳</div>
</div>


</body>
</html>
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/
            /*justify-content: space-evenly;*/
            justify-content: space-between;

            align-items: center;
            /*align-items: flex-start;*/
            /*align-items: flex-end;*/
        }
        .menu .item{
            width: 45px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
    <div class='item'>深圳</div>
</div>


</body>
</html>
```



### 4.换行

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/
            /*justify-content: space-evenly;*/
            justify-content: flex-start;

            /*align-items: center;*/
            align-items: flex-start;
            /*align-items: flex-end;*/

            flex-wrap: wrap;
        }
        .menu .item{
            width: 45px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
</div>


</body>
</html>
```



### 5.多行控制

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/
            /*justify-content: space-evenly;*/
            justify-content: flex-start;

            /*align-items: center;*/
            align-items: flex-start;
            /*align-items: flex-end;*/

            flex-wrap: wrap;
            align-content: center;
        }
        .menu .item{
            width: 45px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
</div>


</body>
</html>
```



### 案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/


            /*justify-content: space-between;*/
            justify-content: space-around; /*横轴*/

            align-items: flex-start; /*纵轴*/

            flex-wrap: wrap;

            align-content: flex-start; /*多行文本，从顶部开始*/
        }

        .menu .item {
            width: 150px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item'>北京</div>
    <div class='item'>上海</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
    <div class='item'>深圳</div>
</div>


</body>
</html>
```



## 2.2 元素

### 1.顺序

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/


            /*justify-content: space-between;*/
            justify-content: space-around; /*横轴*/

            align-items: flex-start; /*纵轴*/

            flex-wrap: wrap;

            align-content: flex-start; /*多行文本，从顶部开始*/
        }

        .menu .item {
            width: 50px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item' style="order: 1">北京</div>
    <div class='item' style="order: 0">上海</div>
    <div class='item' style="order: 2">深圳</div>
</div>


</body>
</html>
```



### 2.剩余空间

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .menu {
            border: 1px solid red;
            width: 500px;
            height: 500px;

            display: flex;
            flex-direction: row; /*主轴=横向*/


            /*justify-content: space-between;*/
            justify-content: flex-start; /*横轴*/
        }

        .menu .item {
            width: 50px;
            height: 50px;
            border: 1px solid green;
        }
    </style>
</head>
<body>
<div class='menu'>
    <div class='item' style="">北京</div>
    <div class='item' style="flex-grow: 2">上海</div>
    <div class='item' style="flex-grow: 1">深圳</div>
</div>


</body>
</html>
```



### 案例

![image-20221113112314914](assets/image-20221113112314914.png)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .container {
            width: 1100px;
            margin: 0 auto;
        }

        .row1 {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }

        .row1 .company {
            width: 210px;
            height: 180px;
            background-color: saddlebrown;
        }

        .row1 .pic {
            width: 266px;
            height: 180px;
            background-color: cadetblue;
        }

        .row2 .title {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }

        .row2 .pic-list {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }

        .row2 .pic-list .big {
            background-color: aquamarine;
            height: 610px;
            width: 210px;
            margin-right: 20px;
        }

        .row2 .pic-list .right-list {
            background-color: antiquewhite;
            flex-grow: 1;
        }

        .row2 .pic-list .right-list .group {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .row2 .pic-list .right-list .phone {
            margin-bottom: 10px;
            border: 1px solid red;
            width: 200px;
            height: 300px;
        }

        .course-list {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .course-list .item {
            width: 24%;
            height: 100px;
            background-color: skyblue;
            margin-top: 15px;
        }
        /*如果最后一个元素，是第3个，右边距=一个位置 + 所有空白位置/3（有三个空白位置）*/
        .course-list .item:last-child:nth-child(4n - 1) {
            margin-right: calc(24% + 4% / 3);
        }
        .course-list .item:last-child:nth-child(4n - 2) {
            margin-right: calc(48% + 8% / 3);
        }
    </style>
</head>
<body>

<div class="container">

    <div class="row1">
        <div class="company"></div>
        <div class="pic"></div>
        <div class="pic"></div>
        <div class="pic"></div>
    </div>

    <div class="row2">
        <div class="title">
            <div>手机</div>
            <div>查看更多</div>
        </div>

        <div class="pic-list">
            <div class="big"></div>
            <div class="right-list">
                <div class="group">
                    <div class="phone"></div>
                    <div class="phone"></div>
                    <div class="phone"></div>
                    <div class="phone"></div>
                </div>
                <div class="group">
                    <div class="phone"></div>
                    <div class="phone"></div>
                    <div class="phone"></div>
                    <div class="phone"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="course-list">
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>

    </div>
</div>

</body>
</html>
```





# 3.vue-router

## 3.1 安装

```
npm install vue-router --save
手动创建文件+配置
```

或

```
vue add router
```

![image-20221113113912111](assets/image-20221113113912111.png)



## 3.2 必备操作



### 1.快速上手（案例）

![image-20221113114601213](assets/image-20221113114601213.png)

详细见：**src-1.zip**



### 2.URL传值（GET）

![image-20221113121504119](assets/image-20221113121504119.png)

详细见：**src-2.zip**



### 3.URL动态参数

![image-20221113142551078](assets/image-20221113142551078.png)

详细见：**src-3.zip**



### 4.路由嵌套

- router/index.js

  ```javascript
  import {createRouter, createWebHistory} from 'vue-router'
  import HomeView from '../views/HomeView.vue'
  
  const routes = [
      {
          path: '/',
          name: "Index",
          component: HomeView
      },
      {
          path: '/home',
          name: 'Home',
          component: HomeView
      },
      {
          path: '/pins',
          name: 'Pins',
          component: HomeView,
          children:[
              {
                  path: 'new',
                  name: 'New',
                  component: HomeView
              },
              {
                  path: 'hot',
                  name: 'Hot',
                  component: HomeView
              }
          ]
      },
      {
          path: '/course',
          name: 'Course',
          component: () => import('../views/CourseView.vue')
      },
      {
          path: '/detail/:id',
          name: 'Detail',
          component: () => import('../views/DetailView.vue')
      },
      {
          path: '/news',
          name: 'News',
          component: () => import('../views/NewsView.vue')
      }
  ]
  
  const router = createRouter({
      history: createWebHistory(),
      routes
  })
  
  export default router
  ```

  

- App.vue

  ```vue
  <div>
      <div class="menu">
          <div class="container">
              <router-link to="/">源代码教育</router-link>
              <router-link to="/home">首页</router-link>
              <router-link to="/pins">沸点</router-link>
              <router-link to="/course">直播</router-link>
          </div>
      </div>
      <div class="container">
          <router-view/>
      </div>
  </div>
  ```

- views/PinsView.vue

  ```vue
  <div>
      <div class="menu">
          <div>
              左边
          </div>
          <div class="container">
              <router-link to="/pins/new">最新</router-link>
              <router-link to="/pins/hot">热门</router-link>
              <router-link to="/pins/following">关注</router-link>
          </div>
          上边
          右边
      </div>
      <div class="container">
          <router-view/>
      </div>
  </div>
  ```

- views/NewView.vue

- views/HotView.vue

- views/FollowingView.vue



![image-20221113144350646](assets/image-20221113144350646.png)



![image-20221113144636223](assets/image-20221113144636223.png)



### 5.编程式导航

如果想要是跳转+加载组件：

- router-link标签
- router对象实现 this.$router.push

```vue
<template>
    <div>
        <h1>新闻页面</h1>
        <input type="button" value="跳转" @click="doClick"/>
    </div>
</template>

<script setup>
    import {useRouter} from 'vue-router'

    const router = useRouter();


    function doClick() {
        //跳转到首页 [Course,]
        // router.push({path:"/home"})
        // router.push({name:"Home"})
        // router.push({name: "Course", query: {page: 10, size: 20}})
        router.push({name: "Detail", params: {id: 100}, query: {page: 10, size: 20}})

        // router.replace({path:"/home"})
        // router.replace({name:"Home"})
        // router.replace({name: "Course", query: {page: 10, size: 20}})
        // router.replace({name: "Detail", params: {id: 100}, query: {page: 10, size: 20}})
        // router.replace({name: "Course", query: {page: 10, size: 20}})

    }
</script>

<style scoped>

</style>
```



#### 5.1 登录跳转（含顶部）

![image-20221113150609761](assets/image-20221113150609761.png)

详见：src-4.zip



#### 5.2 登录跳转（不含顶部）

![image-20221113151724446](assets/image-20221113151724446.png)

![image-20221113151735710](assets/image-20221113151735710.png)

详见：src-5.zip



### 6.导航守卫（全局）

![image-20221113154651481](assets/image-20221113154651481.png)



详见：src-6.zip



# 4.存储数据

- cookie，超时时间+发送请求自动携带。

- sessionStorage，当浏览器关闭时，自动清楚。

- localStorage，长时间存储浏览器。

  ```
  localStorage.setItem(key,value)
  localStorage.getItem(key)
  localStorage.removeItem(key)
  localStorage.clear()
  ```

  

# 5.vuex



## 5.1 安装

```
npm install vue-vuex --save
手动创建文件+配置
```

或

```
vue add vuex （推荐）
```



## 5.2 使用示例



### 5.2.1 案例（vuex）

![image-20221113160744234](assets/image-20221113160744234.png)



详见：src-7.zip



### 5.2.2 案例（vuex+存储）

![image-20221113161345848](assets/image-20221113161345848.png)

详见：src-8.zip



### 5.2.3 案例（vuex+存储+导航守卫）

详见：src-10.zip



### 5.2.4 案例（动态购物车）

详见：src-10.zip



# 6.vue3-cookies

实现将数据在cookie中进行存取。



## 6.1 安装

```
npm install vue3-cookies --save
```

- main.js

  ```javascript
  import {createApp} from 'vue'
  import App from './App.vue'
  import router from './router'
  import store from './store'
  import VueCookies from 'vue3-cookies'
  
  createApp(App).use(store).use(router).use(VueCookies).mount('#app')
  ```

- 使用

  ```
  import {useCookies} from 'vue3-cookies'
  const {cookies} = useCookies();
  cookies.set("ts", "123123", "10s")
  ```

  https://github.com/KanHarI/vue3-cookies



## 6.2 使用示例

将username和token保存到cookie中，设置生效时间。



详见：src11.zip





# 7.axios



## 7.1 安装

```
npm install axios --save
手动配置
```

或

```
vue add axios
```



## 7.2 使用示例



### 7.2.1 快速发送

详见：src12.zip



### 7.2.2 拦截器

发送每个请求执行操作，每个请求返回的执行操作。

详见：src-12.zip





# 8.后端API



## 8.1 跨域问题

当前浏览器访问地址：http://localhost:8080/news

​    点击发送网络请求：https://api.luffycity.com/api/xxxx/xxxx/



本质上想要处理跨域，添加一些响应头即可。

```python
from django.shortcuts import render
from django.http import JsonResponse


def user_list(request):
    info = {"code": 0, 'data': "success"}
    response = JsonResponse(info)

    # 响应头
    print(request.method)

    # 任意网址
    response["Access-Control-Allow-Origin"] = "*"
    # 任意的请求方式
    response["Access-Control-Allow-Methods"] = "*"  # "PUT,DELETE,GET,POST"
    # 允许任意的请求头
    response["Access-Control-Allow-Headers"] = "*"

    return response
```

注意：测试时一定要移除csrf认证。



## 8.2 现象（2个请求）

跨域时发送的是：

- 简单请求：1个请求
- 复杂请求：2个请求
  - OPTIONS请求，预检
  - 真正的请求

```
条件：
  ``1``、请求方式：HEAD、GET、POST
  ``2``、请求头信息：
    ``Accept
    ``Accept``-``Language
    ``Content``-``Language
    ``Last``-``Event``-``ID
    ``Content``-``Type` `对应的值是以下三个中的任意一个
                ``application``/``x``-``www``-``form``-``urlencoded
                ``multipart``/``form``-``data
                ``text``/``plain
```

```h
注意：同时满足以上两个条件时，则是简单请求，否则为复杂请求
```



如果非要避免这种情况，那就别跨域。

- 主域名+API域名

  ```
  https://www.luffycity.com/free-course
  https://api.luffycity.com/api/v1/course/category/actual/?courseType=actual
  ```

- 主域名+API域名

  ```
  https://www.luffycity.com/free-course
  https://www.luffycity.com/api/...
  ```

  

## 8.3 最后跨域

```python
from django.shortcuts import render
from django.http import JsonResponse


def user_list(request):
    info = {"code": 0, 'data': "success"}
    response = JsonResponse(info)

    # 响应头
    print(request.method)

    # 任意网址
    response["Access-Control-Allow-Origin"] = "*"
    # 任意的请求方式
    response["Access-Control-Allow-Methods"] = "*"  # "PUT,DELETE,GET,POST"
    # 允许任意的请求头
    response["Access-Control-Allow-Headers"] = "*"

    return response
```

写在中间件的process_response中。

```python
from django.utils.deprecation import MiddlewareMixin


class CorsMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        # 任意网址
        response["Access-Control-Allow-Origin"] = "*"
        # 任意的请求方式
        response["Access-Control-Allow-Methods"] = "*"   # "PUT,DELETE,GET,POST"
        # 允许任意的请求头
        response["Access-Control-Allow-Headers"] = "*"
        return response
```



# 预习

- jwt token
- drf示例
- elementui-plus

```
预习资源：
 1.jwt，了解前后端分离时token如何处理。
  连接：https://www.bilibili.com/video/BV1tJ411B7yJ/

 2.基于drf实现博客案例，对drf进行应用和实践（后面项目也会讲，可先看预习）

  链接: https://pan.baidu.com/s/1KU2ItEbELtTcbtTmTW_qpQ 提取码: vwms
```















































































































































