# day30 权限和应用



# 1.后端API校验

- 登录校验，后端在登录成功后，需要进行校验登录状态。
- 权限校验，登录后，再访问后端API时，需要校验是否具权限访问。



## 1.1 数据库版



实现思路A：

- 登录时，基于jwt生成用户信息token
- 访问时
  - 基于认证组件校验jwt token的合法性。
  - 基于权限组件校验是否具备当前  `api+method`的访问权限。



### 1.1.1 登录

```
pip install PyJWT
```

```python
#!/usr/bin/env python
# -*- coding:utf-8 -*-
import jwt
import datetime
from jwt import exceptions
from django.conf import settings


def create_token(payload, timeout=20):
    """
    :param payload:  例如：{'user_id':1,'username':'wupeiqi'}用户信息
    :param timeout: token的过期时间，默认20分钟
    :return:
    """
    headers = {
        'typ': 'jwt',
        'alg': 'HS256'
    }
    payload['exp'] = datetime.datetime.utcnow() + datetime.timedelta(days=timeout)
    result = jwt.encode(payload=payload, key=settings.SECRET_KEY.encode('utf-8'), algorithm="HS256", headers=headers)
    return result


def parse_payload(token):
    """
    对token进行和发行校验并获取payload
    :param token:
    :return:
    """
    try:
        verified_payload = jwt.decode(token, settings.SECRET_KEY.encode('utf-8'), algorithms=["HS256"])
        return True, verified_payload
    except exceptions.ExpiredSignatureError:
        error = 'token已失效'
    except jwt.DecodeError:
        error = 'token认证失败'
    except jwt.InvalidTokenError:
        error = '非法的token'
    return False, error
```



在用户登录成功，将用户信息写入jwt token并返回：

```python
token = create_token({'user_id': instance.id, 'name': instance.name})
context = {
    'routers': routers,
    'permissions': permissions,
    "menus": folder_dict.values(),
    "token": token
}
return Response(context)
```



### 1.1.2 校验

- 在中间件中实现cors跨域

  ```python
  from django.utils.deprecation import MiddlewareMixin
  
  
  class CorsMiddleware(MiddlewareMixin):
      def process_request(self, request):
          if request.method == "OPTIONS":
              from django.shortcuts import HttpResponse
              response = HttpResponse(request)
              return response
  
      def process_response(self, request, response):
          response["Access-Control-Allow-Origin"] = "*"
          response["Access-Control-Allow-Methods"] = "*"
          response["Access-Control-Allow-Headers"] = "*"
          return response
  
  ```

- 在认证组件中实现jwt认证校验

  ```python
  from rest_framework.authentication import BaseAuthentication
  from rest_framework import exceptions
  from utils.jwt_auth import create_token, parse_payload
  
  
  class JwtAuthentication(BaseAuthentication):
      def authenticate(self, request):
          # 1.读取请求头中的token
          authorization = request.META.get('HTTP_AUTHORIZATION', '')
  
          # 2.token校验
          # {'user_id': instance.id, 'name': instance.name}
          status, info_or_error = parse_payload(authorization)
  
          # 3.校验失败，返回失败信息，前端重新登录
          if not status:
              raise exceptions.AuthenticationFailed("认证失败")
  
          # 4.校验成功，继续向后  request.user  request.auth
          return (info_or_error, authorization)
  
      def authenticate_header(self, request):
          return 'API realm="API"'
  ```

- 在权限组件中实现 `权限获取` + `权限校验`

  ```python
  from rest_framework.permissions import BasePermission
  from api import models
  
  
  class RbacPermission(BasePermission):
  
      def has_permission(self, request, view):
          # 1.获取用户信息
          url_name = request.resolver_match.url_name
          method = request.method
  
          # 2.获取权限信息
          user_id = request.user['user_id']
          user_object = models.Admin.objects.filter(id=user_id).first()
          result_list = user_object.roles.all().values("permissions__name", "permissions__method")
          print(url_name, method)
          print(result)
  
          exists = user_object.roles.filter(permissions__name=url_name, permissions__method=method).exists()
          return exists
  
      def has_object_permission(self, request, view, obj):
          return True
  ```

  











## 1.2 缓存版

- 登录校验，后端在登录成功后，需要进行校验登录状态。
- 权限校验，登录后，再访问后端API时，需要校验是否具权限访问。



实现思路B：

- 登录时，基于jwt生成用户信息token，并将用户权限信息写入redis中。
- 访问时
  - 基于认证组件校验jwt token的合法性。
  - 基于权限组件校验读取用户权限信息并进行校验。



### 1.2.1 登录

```
pip install django-redis
```

```python
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": "redis://127.0.0.1:6379",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "CONNECTION_POOL_KWARGS": {"max_connections": 100}
            # "PASSWORD": "密码",
        }
    }
}
```



在用户登录成功，将用户信息写入jwt token并返回：

```python
from django_redis import get_redis_connection


permissions = {'role-list': ['GET'], 'xxxx': ['DELETE', 'DELETE'], 'xx': ['PATCH'], 'ff': ['PATCH'], '11': ['DELETE']}

conn = get_redis_connection("default")
conn.hmset(
    f"rbac-permission-{user_object.id}", 
    {k: json.dumps(v) for k, v in permissions.items()}
)

# info = conn.hget(f"rbac-permission-{user_object.id}", "xxxx")
# print(info)

context = {
    'routers': routers,
    'permissions': permissions,
    "menus": folder_dict.values(),
    "token": token
}
return Response(context)
```



### 1.2.3 校验

- 在中间件中实现cors跨域

  ```python
  from django.utils.deprecation import MiddlewareMixin
  
  
  class CorsMiddleware(MiddlewareMixin):
      def process_request(self, request):
          if request.method == "OPTIONS":
              from django.shortcuts import HttpResponse
              response = HttpResponse(request)
              return response
  
      def process_response(self, request, response):
          response["Access-Control-Allow-Origin"] = "*"
          response["Access-Control-Allow-Methods"] = "*"
          response["Access-Control-Allow-Headers"] = "*"
          return response
  
  ```

- 在认证组件中实现jwt认证校验

  ```python
  from rest_framework.authentication import BaseAuthentication
  from rest_framework import exceptions
  from utils.jwt_auth import create_token, parse_payload
  
  
  class JwtAuthentication(BaseAuthentication):
      def authenticate(self, request):
          # 1.读取请求头中的token
          authorization = request.META.get('HTTP_AUTHORIZATION', '')
  
          # 2.token校验
          # {'user_id': instance.id, 'name': instance.name}
          status, info_or_error = parse_payload(authorization)
  
          # 3.校验失败，返回失败信息，前端重新登录
          if not status:
              raise exceptions.AuthenticationFailed("认证失败")
  
          # 4.校验成功，继续向后  request.user  request.auth
          return (info_or_error, authorization)
  
      def authenticate_header(self, request):
          return 'API realm="API"'
  ```

- 在权限组件中实现 `权限获取` + `权限校验`

  ```python
  import json
  
  from rest_framework.permissions import BasePermission
  from api import models
  
  
  class RbacPermission(BasePermission):
  
      def has_permission(self, request, view):
          # 1.获取用户信息
          url_name = request.resolver_match.url_name
          method = request.method
  
          # 2.获取权限信息
          user_id = request.user['user_id']
          user_object = models.Admin.objects.filter(id=user_id).first()
  
          from django_redis import get_redis_connection
          conn = get_redis_connection("default")
          method_list = conn.hget(f"rbac-permission-{user_object.id}", url_name)
  
          if not method_list:
              return False
          method_list = json.loads(method_list)
          print(method_list)
          if method in method_list:
              return True
  
          return False
  
      def has_object_permission(self, request, view, obj):
          return True
  ```

  

# 2.业务功能应用

开发：供应商账户审核的功能

```
- 录入菜单和权限
- 分配权限
- 登录授权
```





# 3.供应链系统集成

- 权限组件集成到供应链系统
- 供应链审核
- 财务审核



![image-20230319181443790](assets/image-20230319181443790.png)

![image-20230319181602954](assets/image-20230319181602954.png)





![image-20230319181420666](assets/image-20230319181420666.png)

![image-20230319181741992](assets/image-20230319181741992.png)

































