"""db_dynamic_api URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include
from rest_framework import routers
from api import views

router = routers.SimpleRouter()
router.register("folder", views.FolderView, basename='folder')
router.register("router", views.RouterView, basename='router')
router.register("permission", views.PermissionView, basename='permission')  # permission-list  permission-detail

router.register("role", views.RoleView, basename='role')
router.register("admin", views.AdminView, basename='admin')
router.register("admin_role", views.AdminRoleView, basename='admin-role')

router.register("login", views.LoginView, basename='login')

urlpatterns = [
    path('api/', include(router.urls))
]
