from django import forms


class MyForm(forms.ModelForm):
    user = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        widgets = {
            "user": forms.PasswordInput
        }
