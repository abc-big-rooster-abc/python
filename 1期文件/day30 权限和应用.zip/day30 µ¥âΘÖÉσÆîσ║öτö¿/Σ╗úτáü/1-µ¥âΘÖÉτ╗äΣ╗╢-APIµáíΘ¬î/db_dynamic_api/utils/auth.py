from rest_framework.authentication import BaseAuthentication
from rest_framework import exceptions
from utils.jwt_auth import create_token, parse_payload


class JwtParamAuthentication(BaseAuthentication):
    def authenticate(self, request):
        """
        Authenticate the request and return a two-tuple of (user, token).
        """
        # 1.读取请求头中的token
        authorization = request.query_params.get("token")

        # 2.token校验
        status, info_or_error = parse_payload(authorization)

        # 3.校验失败，继续往后走
        if not status:
            return

        # 4.校验成功，继续向后  request.user  request.auth
        return (info_or_error, authorization)

    def authenticate_header(self, request):
        """
        Return a string to be used as the value of the `WWW-Authenticate`
        header in a `401 Unauthenticated` response, or `None` if the
        authentication scheme should return `403 Permission Denied` responses.
        """
        return 'API realm="API"'


class JwtAuthentication(BaseAuthentication):
    def authenticate(self, request):
        """
        Authenticate the request and return a two-tuple of (user, token).
        """
        # 1.读取请求头中的token
        authorization = request.META.get('HTTP_AUTHORIZATION', '')

        # 2.token校验
        status, info_or_error = parse_payload(authorization)

        # 3.校验失败，返回失败信息，前端重新登录
        if not status:
            raise exceptions.AuthenticationFailed("认证失败")

        # 4.校验成功，继续向后  request.user  request.auth
        return (info_or_error, authorization)

    def authenticate_header(self, request):
        """
        Return a string to be used as the value of the `WWW-Authenticate`
        header in a `401 Unauthenticated` response, or `None` if the
        authentication scheme should return `403 Permission Denied` responses.
        """
        return 'API realm="API"'


class DenyAuthentication(BaseAuthentication):
    def authenticate(self, request):
        """
        Authenticate the request and return a two-tuple of (user, token).
        """
        raise exceptions.AuthenticationFailed("认证失败")

    def authenticate_header(self, request):
        """
        Return a string to be used as the value of the `WWW-Authenticate`
        header in a `401 Unauthenticated` response, or `None` if the
        authentication scheme should return `403 Permission Denied` responses.
        """
        return 'API realm="API"'
