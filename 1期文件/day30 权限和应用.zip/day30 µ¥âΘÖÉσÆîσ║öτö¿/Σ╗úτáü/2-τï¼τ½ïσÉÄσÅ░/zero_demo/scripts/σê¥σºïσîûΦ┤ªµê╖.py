# 启动django
import os
import sys
import django

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'zero_demo.settings')
django.setup()  # 伪造让django启动

from apps.rbac import models

# 一级目录
folder_object = models.Folder.objects.create(title="权限管理",icon="User")
# folder_object = models.Folder.objects.get_or_create(title="权限管理")

# 二级目录
router_menu = models.Router.objects.create(title="菜单", name="menu", is_menu=True, folder=folder_object)
router_role = models.Router.objects.create(title="角色", name='role', is_menu=True, folder=folder_object)
router_user = models.Router.objects.create(title="用户", name='user', is_menu=True, folder=folder_object)

# 权限（bulk_create)
objs = [
    models.Permission(title="目录列表", name="folder-list", method="GET", router=router_menu),
    models.Permission(title="新建目录", name="folder-list", method="POST", router=router_menu),
    models.Permission(title="删除目录", name="folder-detail", method="DELETE", router=router_menu),

    models.Permission(title="路由列表", name="router-list", method="GET", router=router_menu),
    models.Permission(title="新建路由", name="router-list", method="POST", router=router_menu),
    models.Permission(title="删除路由", name="router-detail", method="DELETE", router=router_menu),

    models.Permission(title="权限列表", name="permission-list", method="GET", router=router_menu),
    models.Permission(title="新建权限", name="permission-list", method="POST", router=router_menu),
    models.Permission(title="删除权限", name="permission-detail", method="DELETE", router=router_menu),

    models.Permission(title="角色列表", name="role-list", method="GET", router=router_role),
    models.Permission(title="新建角色", name="role-list", method="POST", router=router_role),
    models.Permission(title="删除角色", name="role-detail", method="DELETE", router=router_role),

    models.Permission(title="所有权限", name="permission-total", method="GET", router=router_role),
    models.Permission(title="角色权限", name="role-permission", method="GET", router=router_role),
    models.Permission(title="分配权限", name="role-update_permission", method="POST", router=router_role),

    models.Permission(title="用户列表", name="admin-list", method="GET", router=router_user),
    models.Permission(title="新建用户", name="admin-list", method="POST", router=router_user),
    models.Permission(title="删除用户", name="admin-detail", method="DELETE", router=router_user),
    models.Permission(title="用户角色", name="admin-role-list", method="GET", router=router_user),
]

pk_list = []
for obj in objs:
    obj.save()
    pk_list.append(obj.pk)

# 角色
role_manager = models.Role.objects.create(title="管理员")
role_manager.permissions.set(pk_list)

# 创建用户+角色
user_object = models.Admin.objects.create(user='root', password="123")
user_object.roles.set([role_manager.id])
