from django.urls import path, include
from rest_framework import routers
from apps.rbac import views as rbac_views

router = routers.SimpleRouter()
router.register("folder", rbac_views.FolderView, basename='folder')
router.register("router", rbac_views.RouterView, basename='router')
router.register("permission", rbac_views.PermissionView, basename='permission')  # permission-list  permission-detail

router.register("role", rbac_views.RoleView, basename='role')
router.register("admin", rbac_views.AdminView, basename='admin')
router.register("admin_role", rbac_views.AdminRoleView, basename='admin-role')
router.register("login", rbac_views.LoginView, basename='login')

urlpatterns = [
    path('', include(router.urls)),
]
