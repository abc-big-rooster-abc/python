from django.shortcuts import render
from apps.rbac.utils.viewsets import GenericViewSet, ModelViewSet
from rest_framework import serializers
from . import models


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Order
        fields = "__all__"


class OrderView(ModelViewSet):
    queryset = models.Order.objects.all()
    serializer_class = OrderSerializer
