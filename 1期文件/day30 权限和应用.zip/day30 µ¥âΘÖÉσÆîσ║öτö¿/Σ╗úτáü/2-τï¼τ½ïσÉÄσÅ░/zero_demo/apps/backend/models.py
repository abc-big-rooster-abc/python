from django.db import models


class Order(models.Model):
    """ 订单表"""
    title = models.CharField(verbose_name="标题", max_length=32)
    count = models.IntegerField(verbose_name="数量")
