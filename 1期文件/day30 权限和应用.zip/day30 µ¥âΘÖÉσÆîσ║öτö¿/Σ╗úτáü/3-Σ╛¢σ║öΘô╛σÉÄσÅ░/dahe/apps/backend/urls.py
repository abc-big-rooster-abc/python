from django.urls import path, include
from rest_framework import routers

from . import views

router = routers.SimpleRouter()
router.register("shipper", views.ShipperView, basename='shipper')
router.register("finance", views.FinanceView, basename='finance')

urlpatterns = [
    path('', include(router.urls)),
]
