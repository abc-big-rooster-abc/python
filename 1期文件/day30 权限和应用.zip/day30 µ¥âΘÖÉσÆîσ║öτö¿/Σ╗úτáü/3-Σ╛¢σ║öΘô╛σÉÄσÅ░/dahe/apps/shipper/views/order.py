import random
import datetime
from utils.ext.mixins import CreateModelMixin, ListPageNumberModelMixin
from rest_framework.viewsets import GenericViewSet, ModelViewSet
from rest_framework import serializers
from rest_framework.pagination import PageNumberPagination
from apps.base import models
from utils.ext.auth import JwtAuthentication, JwtParamAuthentication, DenyAuthentication
from rest_framework.response import Response
from utils.ext import return_code

"""
form: {
        from_addr: "",
        from_name: "",
        from_mobile: "",
        from_date: "2022-11-11",

        to_addr: "",
        to_name: "",
        to_mobile: "",
        to_date: "2022-11-11",

        title: "信息",
        goods_type: 2,
        weight: "12",
        unit_price: "11",
        cost: "100",
    },
"""


class OrderPageNumberPagination(PageNumberPagination):
    page_size = 30


class OrderModelSerializer(serializers.ModelSerializer):
    # oid = serializers.CharField(read_only=True)
    status_text = serializers.CharField(source='get_status_display')

    class Meta:
        model = models.Order
        # fields = "__all__"
        exclude = ["company", "driver"]
        extra_kwargs = {
            "unit_price": {"coerce_to_string": False},
            "weight": {"coerce_to_string": False},
            "oid": {"read_only": True},
        }


class OrderView(CreateModelMixin, ListPageNumberModelMixin, GenericViewSet):
    authentication_classes = [JwtAuthentication, JwtParamAuthentication, DenyAuthentication]
    serializer_class = OrderModelSerializer
    queryset = models.Order.objects.all()
    pagination_class = OrderPageNumberPagination

    def perform_create(self, serializer):
        # 1.company_id
        company_id = self.request.user['user_id']

        # 2.检查余额
        instance = models.Company.objects.filter(id=company_id).first()
        total_amount = serializer.validated_data['unit_price'] * serializer.validated_data['weight']
        if instance.balance < total_amount:
            return Response({"code": return_code.SUMMARY_ERROR, 'msg': "余额不足"})

        # 3.订单号
        rand_number = random.randint(10000000, 99999999)
        ctime = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
        oid = "{}{}".format(ctime, rand_number)

        # 4.创建订单
        serializer.save(company_id=company_id, oid=oid)

        # 5.交易记录
        rand_number = random.randint(10000000, 99999999)
        ctime = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
        trans_id = "{}{}".format(ctime, rand_number)
        models.TransactionRecord.objects.create(
            tran_type=-2,
            trans_id=trans_id,  # 交易单号
            order_id=oid,  # 运单
            company_id=company_id,
            amount=total_amount,
            pay_status=1
        )

        # 6.可用 -> 不可用
        instance.balance -= total_amount
        instance.freeze_balance += total_amount
        instance.save()
