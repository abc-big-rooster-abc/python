import random
from rest_framework import mixins
from rest_framework.response import Response
from rest_framework import serializers
from django.core.validators import RegexValidator
from django_redis import get_redis_connection

from apps.base import models
from ..utils.viewsets import GenericViewSet
from ..utils.viewsets import APIView
from ..utils.validator import mobile_validator, message_code_validator
from ..utils.exceptions import ExtraException


class MessageCodeSerializer(serializers.Serializer):
    # phone = serializers.CharField(
    #     label='手机号',
    #     validators=[RegexValidator(r'^(1[3|4|5|6|7|8|9])\d{9}$', message="格式错误")]
    # )

    phone = serializers.CharField(label='手机号', validators=[mobile_validator, ])


class SendSms(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        # 1.获取手机号 + 格式校验
        print(request.data)
        ser = MessageCodeSerializer(data=request.data)
        if not ser.is_valid():
            print(ser.errors)
            raise ExtraException("手机格式错误", ret_code=8890)

        mobile = ser.validated_data.get('phone')
        random_code = random.randint(1000, 9999)

        # 2.调用短信API + redis+超时时间
        # result = send_china_msg(mobile, random)
        # if not result.status:
        #     raise ExtraException("验证码发送失败", ret_code=8891)

        # 3.redis写入
        # from django_redis import get_redis_connection
        # conn = get_redis_connection("default")
        # conn(mobile, random_code, ex=60)  # json string

        print(mobile, random_code)

        # 4.返回
        return Response("success")


class LoginSerializer(serializers.Serializer):
    phone = serializers.CharField(label='手机号', validators=[mobile_validator, ])
    sms_code = serializers.CharField(label="验证码", validators=[message_code_validator, ])
    wx_code = serializers.CharField(label="微信Code")

    def validate_sms_code(self, value):
        # phone = self.initial_data.get('phone')
        # conn = get_redis_connection()
        # code = conn.get(phone)
        # if not code:
        #     raise ValidationError('短信验证码已失效')
        # if value != code.decode('utf-8'):
        #     raise ValidationError('短信验证码错误')
        return value


class LoginSms(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        from ..utils.exceptions import ExtraException
        # raise ExtraException("xxxxxxx")
        # 1.获取手机号格式校验
        # 2.验证码校验  手机号+验证码
        ser = LoginSerializer(data=request.data)
        if not ser.is_valid():
            print(ser.errors)
            raise ExtraException(ser.errors, ret_code=8810)

        # 3.code去获取session_key  openid
        # wx_code = request.data.get('wx_code')
        import requests
        from django.conf import settings
        wx_code = ser.validated_data.get('wx_code')
        param_dict = {
            'appid': settings.WX_APPID,
            'secret': settings.WX_SECRET,
            'js_code': wx_code,
            'grant_type': 'authorizaion_code'
        }
        res_dict = requests.get(
            url="https://api.weixin.qq.com/sns/jscode2session",
            params=param_dict
        ).json()
        # {'session_key': 'NlDA+3m0lHePHESz8bCr3w==', 'openid': 'ofuZp5MaP33ezAlO8gcsgEY_jpac'}
        print(res_dict)

        # print(ser.validated_data)
        # 4.用户信息写入数据【注册】 # 手机号 + session_key + openid
        # 新建 或 更新
        # phone = ser.validated_data.get('phone')
        # exists = models.Driver.objects.filter(phone=phone).exists()
        # if exists:
        #     # 更新
        #     pass
        # else:
        #     # 新建
        #     pass

        # 更新或创建
        phone = ser.validated_data.get('phone')
        instance, _ = models.Driver.objects.update_or_create(phone=phone, defaults=res_dict)

        # 5.生成token返回（凭证） 【jwt token或其他】
        # import uuid
        # token = str(uuid.uuid4())
        from utils.jwt_auth import create_token
        token = create_token({'user_id': instance.id, 'phone': phone})
        return Response({"token": token, "phone": phone})


class Demo(serializers.ModelSerializer):
    class Meta:
        model = models.Company
        fields = "__all__"


class LoginView(mixins.CreateModelMixin, GenericViewSet):
    queryset = models.Company.objects.all()
    serializer_class = Demo

    def create(self, request, *args, **kwargs):
        print("来了")
        return Response("...")
