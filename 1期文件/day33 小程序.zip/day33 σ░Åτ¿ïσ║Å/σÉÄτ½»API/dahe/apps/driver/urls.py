from django.urls import path, include
from rest_framework import routers

from .view import account

router = routers.SimpleRouter()
router.register("login", account.LoginView)

urlpatterns = [
    path('sendsms/', account.SendSms.as_view()),
    path('loginsms/', account.LoginSms.as_view()),
    path('', include(router.urls)),
]
