from rest_framework import mixins
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination

from apps.base import models
from apps.rbac.utils.viewsets import ModelViewSet, GenericViewSet
from apps.rbac.utils.exceptions import ExtraException


class ShipperSerializer(serializers.ModelSerializer):
    auth_type_text = serializers.CharField(source='get_auth_type_display')

    class Meta:
        model = models.Company
        fields = ["id", 'name', "auth_type", "auth_type_text"]


class ShipperView(mixins.CreateModelMixin, mixins.ListModelMixin, GenericViewSet):
    queryset = models.Company.objects.filter(auth_type__in=[2, 3]).order_by("auth_type")
    # queryset = models.Company.objects.all()
    serializer_class = ShipperSerializer
    pagination_class = PageNumberPagination

    def create(self, request, *args, **kwargs):
        # POST   /api/backend/shipper/      {company_id:id, is_pass:True/False}
        # 1.接收用户请求传递数据
        # 2.根据数据进行审核通过/未通脱
        # raise ExtraException("自定义错误")
        return Response({"data": 123})


class FinanceSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.TransactionRecord
        fields = "__all__"


class FinanceView(mixins.CreateModelMixin, mixins.ListModelMixin, GenericViewSet):
    queryset = models.TransactionRecord.objects.filter(auditor_status=0)
    # queryset = models.TransactionRecord.objects.all()
    serializer_class = FinanceSerializer
    pagination_class = PageNumberPagination

    def create(self, request, *args, **kwargs):
        # POST   /api/backend/shipper/      {company_id:id, is_pass:True/False}
        # 1.接收用户请求传递数据

        # 2.根据数据进行审核通过/未通脱
        # raise ExtraException("自定义错误")

        return Response({"data": 123})
