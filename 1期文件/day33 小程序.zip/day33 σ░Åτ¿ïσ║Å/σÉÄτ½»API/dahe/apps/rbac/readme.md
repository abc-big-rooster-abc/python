
# RBAC组件使用概述


## 1.后端

### 1.1 拷贝rbac目录
将rbac整个app目录拷贝至 apps目录下。

### 1.2 settings中进行app注册
```python
INSTALLED_APPS = [
    ...
    "apps.rbac.apps.RbacConfig",
    ...
]
```

### 1.3 settings中restframework配置
```python

REST_FRAMEWORK = {
    "UNAUTHENTICATED_USER": None,
    "UNAUTHENTICATED_TOKEN": None,
    "EXCEPTION_HANDLER": "apps.rbac.utils.handlers.exception_handler",
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "apps.rbac.utils.auth.JwtParamAuthentication",
        "apps.rbac.utils.auth.JwtAuthentication",
        "apps.rbac.utils.auth.DenyAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "apps.rbac.utils.permission.MinePermission",
    ],
}
```
如果全局的错误和返回使用rbac的返回机制，直接用全局配置即可。
如果不是全部按照rabc的方式，则需要父类视图中
```python
from rest_framework.viewsets import GenericViewSet as DrfGenericViewSet
from rest_framework import mixins
from apps.rbac.utils.handlers import exception_handler

class GenericViewSet(DrfGenericViewSet):
    def finalize_response(self, request, response, *args, **kwargs):
        response = super().finalize_response(request, response, *args, **kwargs)
        if response.exception:
            return response
        response.data = {'code': 0, 'data': response.data}
        return response

    def get_exception_handler(self):
        """
        Returns the exception handler that this view uses.
        """
        return exception_handler


class ModelViewSet(mixins.CreateModelMixin,
                   mixins.RetrieveModelMixin,
                   mixins.UpdateModelMixin,
                   mixins.DestroyModelMixin,
                   mixins.ListModelMixin,
                   GenericViewSet):
    pass

```
自己的视图只需要继承上述 `ModelViewSet` 或 `GenericViewSet`。


### 1.4 路由配置

#### 1.4.1 根路由
```python
from django.urls import path
from django.urls import path, include

urlpatterns = [
    path('api/rbac/', include('apps.rbac.urls')),
    path('api/backend/', include('apps.backend.urls')),
]
```

#### 1.4.2 rbac路由
```python
from django.urls import path, include
from rest_framework import routers
from apps.rbac import views as rbac_views

router = routers.SimpleRouter()
router.register("folder", rbac_views.FolderView, basename='folder')
router.register("router", rbac_views.RouterView, basename='router')
router.register("permission", rbac_views.PermissionView, basename='permission')  # permission-list  permission-detail

router.register("role", rbac_views.RoleView, basename='role')
router.register("admin", rbac_views.AdminView, basename='admin')
router.register("admin_role", rbac_views.AdminRoleView, basename='admin-role')
router.register("login", rbac_views.LoginView, basename='login')

urlpatterns = [
    path('', include(router.urls)),
]

```

#### 1.4.3 业务路由
```python
from django.urls import path, include
from rest_framework import routers

from . import views

router = routers.SimpleRouter()
router.register("order", views.OrderView, basename='order')

urlpatterns = [
    path('', include(router.urls)),
]
```
自己业务相关的功能都写在这里。


### 1.5 视图
rbac中的视图，不需要去动，内部将：目录、路由、菜单、权限功能。。。
接下来需要自己去做的：业务模块
业务的视图可以有两种编写形式：
- 基于rbac的返回值和异常处理，例如：
```python
from django.shortcuts import render
from apps.rbac.utils.viewsets import GenericViewSet, ModelViewSet
from rest_framework import serializers
from . import models


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Order
        fields = "__all__"


class OrderView(ModelViewSet):
    queryset = models.Order.objects.all()
    serializer_class = OrderSerializer

```
- 基于自定义的方式返回
  - 先自定义ModelViewSet/GenericViewSet
  - 让自己的视图去继承


### 1.6 离线脚本
```python
# 启动django
import os
import sys
import django

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'zero_demo.settings')
django.setup()  # 伪造让django启动

from apps.rbac import models

# 一级目录
folder_object = models.Folder.objects.create(title="权限管理",icon="User")
# folder_object = models.Folder.objects.get_or_create(title="权限管理")

# 二级目录
router_menu = models.Router.objects.create(title="菜单", name="menu", is_menu=True, folder=folder_object)
router_role = models.Router.objects.create(title="角色", name='role', is_menu=True, folder=folder_object)
router_user = models.Router.objects.create(title="用户", name='user', is_menu=True, folder=folder_object)

# 权限（bulk_create)
objs = [
    models.Permission(title="目录列表", name="folder-list", method="GET", router=router_menu),
    models.Permission(title="新建目录", name="folder-list", method="POST", router=router_menu),
    models.Permission(title="删除目录", name="folder-detail", method="DELETE", router=router_menu),

    models.Permission(title="路由列表", name="router-list", method="GET", router=router_menu),
    models.Permission(title="新建路由", name="router-list", method="POST", router=router_menu),
    models.Permission(title="删除路由", name="router-detail", method="DELETE", router=router_menu),

    models.Permission(title="权限列表", name="permission-list", method="GET", router=router_menu),
    models.Permission(title="新建权限", name="permission-list", method="POST", router=router_menu),
    models.Permission(title="删除权限", name="permission-detail", method="DELETE", router=router_menu),

    models.Permission(title="角色列表", name="role-list", method="GET", router=router_role),
    models.Permission(title="新建角色", name="role-list", method="POST", router=router_role),
    models.Permission(title="删除角色", name="role-detail", method="DELETE", router=router_role),

    models.Permission(title="所有权限", name="permission-total", method="GET", router=router_role),
    models.Permission(title="角色权限", name="role-permission", method="GET", router=router_role),
    models.Permission(title="分配权限", name="role-update_permission", method="POST", router=router_role),

    models.Permission(title="用户列表", name="admin-list", method="GET", router=router_user),
    models.Permission(title="新建用户", name="admin-list", method="POST", router=router_user),
    models.Permission(title="删除用户", name="admin-detail", method="DELETE", router=router_user),
    models.Permission(title="用户角色", name="admin-role-list", method="GET", router=router_user),
]

pk_list = []
for obj in objs:
    obj.save()
    pk_list.append(obj.pk)

# 角色
role_manager = models.Role.objects.create(title="管理员")
role_manager.permissions.set(pk_list)

# 创建用户+角色
user_object = models.Admin.objects.create(user='root', password="123")
user_object.roles.set([role_manager.id])
```


## 2.前端
前端代码流程：
- 登录，从后端获取用户、权限等信息
- 保存vuex
- 访问其他URL，携带jwt token
- 路由拦截器中判断用户是否有访问次路由的权限
- 动态生成菜单
- 按钮粒度的权限控制

### 2.1 vue-router
- 所有的路由
- 路由导航守卫

### 2.2 vuex
- 保存用户信息
- permission.js，用户判断是否有按钮权限
### 2.3 自定义指令
自定义v-permission指令

### 2.4 其他路由
按照文件接口拷贝至项目即可。
如果想要自定义样式，是需要修改相应的样式代码。
- LoginView.vue
- AdminView.vue
- admin
  - MenuView.vue
  - ...







