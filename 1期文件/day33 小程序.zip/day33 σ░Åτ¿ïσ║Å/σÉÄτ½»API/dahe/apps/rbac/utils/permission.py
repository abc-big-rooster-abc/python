import json

from rest_framework.permissions import BasePermission

from .. import models


class MineDBPermission(BasePermission):

    def has_permission(self, request, view):
        # URL请求后都会走
        # 1.获取当前用户访问的URL相关：名称+方法
        # print(request.resolver_match)
        url_name = request.resolver_match.url_name
        method = request.method
        # print(url_name, method)  # folder-list GET

        # 2.获取当前用户已经有的权限信息 + 校验
        user_id = request.user['user_id']

        admin_object = models.Admin.objects.filter(id=user_id).first()
        has_per = admin_object.roles.filter(permissions__name=url_name, permissions__method=method).exists()
        return has_per

    def has_object_permission(self, request, view, obj):
        # self.get_object()
        return True


class MinePermission(BasePermission):

    def has_permission(self, request, view):
        # URL请求后都会走
        # 1.获取当前用户访问的URL相关：名称+方法
        # print(request.resolver_match)
        url_name = request.resolver_match.url_name
        method = request.method

        # 2.获取当前用户已经有的权限信息 + 校验
        user_id = request.user['user_id']

        from django_redis import get_redis_connection
        conn = get_redis_connection("default")

        method_list = conn.hget(f"permission-{user_id}", url_name)
        if not method_list:
            return False
        method_list = json.loads(method_list)
        if method in method_list:
            return True
        return False

    def has_object_permission(self, request, view, obj):
        # self.get_object()
        return True
