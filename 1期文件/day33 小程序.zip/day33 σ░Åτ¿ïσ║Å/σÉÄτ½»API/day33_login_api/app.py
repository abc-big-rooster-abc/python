import requests
from flask import Flask, request

app = Flask(__name__)


@app.route("/login", methods=["GET", "POST"])
def login():
    print(request.json)
    # 1.获取用户名和密码去数据库校验
    # 2.向微信后台发送请求，获取session_key,openid
    # 3.保存用户信息表中
    # 4.jwt token给小程序端返回
    wx_code = request.json.get("wx_code")
    param_dict = {
        'appid': 'wx55cca0b94f723dc7',
        'secret': 'c000e3ddc95d2ef723b9b010f0ae05d5',
        'js_code': wx_code,
        'grant_type': 'authorization_code'
    }
    res_dict = requests.get(
        url="https://api.weixin.qq.com/sns/jscode2session",
        params=param_dict
    ).json()
    # {'session_key': 'NlDA+3m0lHePHESz8bCr3w==', 'openid': 'ofuZp5MaP33ezAlO8gcsgEY_jpac'}
    print(res_dict)

    return "OK"



@app.route("/mobile/login", methods=["GET", "POST"])
def mobile_login():
    print(request.json)
    # 1.根据wx_code获取session_key,openid
    # 4.jwt token给小程序端返回
    wx_code = request.json.get("wx_code")
    encryptedData = request.json.get("encryptedData")
    iv = request.json.get("iv")

    param_dict = {
        'appid': 'wx55cca0b94f723dc7',
        'secret': 'c000e3ddc95d2ef723b9b010f0ae05d5',
        'js_code': wx_code,
        'grant_type': 'authorization_code'
    }
    res_dict = requests.get(
        url="https://api.weixin.qq.com/sns/jscode2session",
        params=param_dict
    ).json()
    # {'session_key': 'NlDA+3m0lHePHESz8bCr3w==', 'openid': 'ofuZp5MaP33ezAlO8gcsgEY_jpac'}
    # print(res_dict)
    session_key = res_dict['session_key']

    # 2.获取手机号，解密：encryptedData  （iv+session_key）
    from utils.WXBizDataCrypt import WXBizDataCrypt
    pc = WXBizDataCrypt(param_dict["appid"], session_key)
    print(pc.decrypt(encryptedData, iv))

    return "OK"


@app.route("/mobile/new/login", methods=["GET", "POST"])
def mobile_new_login():
    print(request.json)
    # 1.根据wx_code获取session_key,openid
    wx_code = request.json.get("wx_code")
    code = request.json.get("code")
    print(code)

    param_dict = {
        'appid': 'wx55cca0b94f723dc7',
        'secret': 'c000e3ddc95d2ef723b9b010f0ae05d5',
        'js_code': wx_code,
        'grant_type': 'authorization_code'
    }
    res_dict = requests.get(
        url="https://api.weixin.qq.com/sns/jscode2session",
        params=param_dict
    ).json()
    # {'session_key': 'NlDA+3m0lHePHESz8bCr3w==', 'openid': 'ofuZp5MaP33ezAlO8gcsgEY_jpac'}
    print(res_dict)

    # 2.token
    token_dict = {
        'appid': 'wx55cca0b94f723dc7',
        'secret': 'c000e3ddc95d2ef723b9b010f0ae05d5',
        'grant_type': 'client_credential'
    }
    token_res_dict = requests.get(
        url="https://api.weixin.qq.com/cgi-bin/token",
        params=token_dict
    ).json()
    print(token_res_dict)
    access_token = token_res_dict['access_token']

    # 3.获取手机号，解密：encryptedData  （iv+session_key）
    # code
    result = requests.post(
        url=f"https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={access_token}",
        json={
            "code":code
        }
    ).json()
    print(result)

    # 4.保存到数据库
    #     openid + 15131255089 => jwt token
    return "OK"

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8009)
