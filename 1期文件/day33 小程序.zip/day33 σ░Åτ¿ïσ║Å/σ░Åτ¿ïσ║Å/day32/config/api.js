const rootUrl = 'http://192.168.0.7:8000/api/driver';
// const rootUrl = 'https://s24.pythonav.com/api';

module.exports = {
  SendSms: rootUrl + "/sendsms/",
  LoginSms: rootUrl + "/loginsms/",
}