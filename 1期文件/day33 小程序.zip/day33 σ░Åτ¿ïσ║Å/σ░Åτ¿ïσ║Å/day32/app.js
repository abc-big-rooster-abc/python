// app.js
App({
  onLaunch() {
    
  },
  globalData: {
  }
})
