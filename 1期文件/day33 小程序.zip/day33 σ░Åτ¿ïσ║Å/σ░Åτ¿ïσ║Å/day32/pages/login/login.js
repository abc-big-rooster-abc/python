// pages/login/login.js
var api = require('../../config/api.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
      userInfo:{
        mobile:"18630091234",
        sms_code:9981
      },
      text:"获取验证码",
      sendSmsDisabled:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  doSendSms(e){

    this.setData({
      sendSmsDisabled:true
    })

    wx.request({
      url: api.SendSms,
      method:"POST",
      data:{
        phone:this.data.userInfo.mobile
      },
      success:(response)=>{
        if (response.data.code ==0){
          wx.showToast({
            title: "发送成功",
            icon: 'none'
          })
            
          var number = 60;
          var instance = setInterval(()=>{
              number = number - 1;
              this.setData({
                text:`${number}秒重试`
              })
              
              if(number <= 1){
                clearInterval(instance)
                this.setData({
                  sendSmsDisabled:false,
                  text:"获取验证码"
                })
              }
          },1000);
          
        }else{
          wx.showToast({
            title: response.data.detail,
            icon: 'none'
          })
          this.setData({
            sendSmsDisabled:false
          })

        }
        
      }
    })


  },

  bindPhoneInput: function(e) {
    this.setData({
      ["userInfo.mobile"]: e.detail.value
    });
  },
  bindCodeInput: function(e) {
    this.setData({
      ["userInfo.sms_code"]: e.detail.value
    });
  },

  onClickSubmit(e){
    wx.login({
      success: (res) => {
        wx.request({
          url: api.LoginSms,
          method:"POST",
          header:{
              
          },
          data:{
            wx_code:res.code,
            phone:this.data.userInfo.mobile,
            sms_code:this.data.userInfo.sms_code,
          },
          success:(response)=>{
            console.log(response);
          }
        })

      },
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})