// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    canIUseChooseAvatar:wx.canIUse('button.open-type.chooseAvatar'),
    avatarUrl:"https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  onChooseAvatar(e){
    this.setData({
      avatarUrl:e.detail.avatarUrl
    })
  },
  fetchUserProfile(e){
    wx.getUserProfile({
      desc: 'desc',
      success:(res) =>{
        console.log(res);
        console.log(res.userInfo.avatarUrl);
        console.log(res.userInfo.nickName);
        this.setData({
          avatarUrl:res.userInfo.avatarUrl
        })
      }
    })
  },
})