// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    userInfo:{
      user:"wupeiqi",
      pwd:"123123",
      avatarUrl:''
    }
  },
  
  onLoad() {
 
  },
  doLogin(e){
    //0.wx登录
    //1.获取用户名和密码+wxcode
    //2.发送到后端API
    wx.login({
      success: (res) => {
        console.log(res.code);
        wx.request({
          url: 'http://192.168.0.7:8009/login',
          method:"POST",
          data:{
            wx_code:res.code,
            user:this.data.userInfo.user,
            pwd:this.data.userInfo.pwd,
          },
          success:(response)=>{
            console.log(response);
          }
        })

      },
    })
  },
  doGetNumber(e){
    wx.login({
      success: (res) => {
        wx.request({
          url: 'http://192.168.0.7:8009/mobile/login',
          method:"POST",
          data:{
            wx_code:res.code,
            encryptedData:e.detail.encryptedData,
            iv:e.detail.iv,
          },
          success:(response)=>{
            console.log(response);
          }
        })

      },
    })
    console.log(e);
  },
  doGetNumberNew(e){
    wx.login({
      success: (res) => {
        wx.request({
          url: 'http://192.168.0.7:8009/mobile/new/login',
          method:"POST",
          data:{
            wx_code:res.code,
            code: e.detail.code
          },
          success:(response)=>{
            console.log(response);
          }
        })

      },
    })
  },
  getUserInfo(e){
    console.log(e);
  },
  fetchUserProfile(e){
    wx.getUserProfile({
      desc: 'desc',
      success:function(res){
        console.log(res);
        console.log(res.userInfo.avatarUrl);
        console.log(res.userInfo.nickName);
      }
    })
  },
  onChooseAvatar(e){
    this.setData({
      ["userInfo.avatarUrl"]:e.detail.avatarUrl
    })
  }
})
