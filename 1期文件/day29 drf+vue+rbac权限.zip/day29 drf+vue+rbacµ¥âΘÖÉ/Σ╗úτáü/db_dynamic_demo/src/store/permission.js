import store from "@/store/index";


export function hasPermission(name, method) {
    let userPermission = store.getters.permissions;
    if (!userPermission[name]) {
        return false;
    }
    if (userPermission[name].indexOf(method) !== -1) {
        return true;
    }
    return false;
}
