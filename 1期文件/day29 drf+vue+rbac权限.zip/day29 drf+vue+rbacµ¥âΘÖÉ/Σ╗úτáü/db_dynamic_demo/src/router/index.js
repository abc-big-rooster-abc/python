import {createRouter, createWebHistory} from 'vue-router'
import store from "@/store";

const routes = [
    {
        path: '/login',
        name: 'login',
        component: () => import('../views/LoginView.vue')
    },
    {
        path: '/admin',
        name: 'admin',
        component: () => import('../views/AdminView.vue'),
        children: [
            {
                path: 'menu',
                name: 'menu',
                component: () => import('../views/admin/MenuView.vue'),
            },
            {
                path: 'role',
                name: 'role',
                component: () => import('../views/admin/RoleView.vue'),
            },
            {
                path: 'user',
                name: 'user',
                component: () => import('../views/admin/UserView.vue'),
            },
            {
                path: 'more',
                name: 'more',
                component: () => import('../views/admin/MoreView.vue'),
            }
        ]
    },

]

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes
})


router.beforeEach((to, from, next) => {
    if (to.name === "login") {
        next();
        return;
    }

    if (!store.getters.routers) {
        next({name: "login"});
        return;
    }

    if (store.getters.routers.indexOf(to.name) !== -1) {
        next();
        return;
    }

    next({name: store.getters.routers[0]});
})

export default router
