<template>
    <el-dialog width="30%" :title="obj.title" v-model='obj.dialogVisible'>
        <div>
            <el-form :model="obj.form" label-width="80px">

                <el-form-item v-for="field in obj.fields" style="margin-top: 24px;"
                              :prop="field.name"
                              :error="obj.errors[field.name]"
                              :label="field.label">

                    <el-input v-if="field.widget==='input'" v-model="obj.form[field.name]"
                              :placeholder="'请输入'+field.label"></el-input>


                    <el-switch v-if="field.widget==='switch'" v-model="obj.form[field.name]"></el-switch>

                    <el-select v-if="field.widget==='select'" v-model="obj.form[field.name]">
                        <el-option v-for="item in obj.options[field.name]" :label="item.label" :value="item.value" :key="item.value"></el-option>
                    </el-select>

                    <el-select v-if="field.widget==='multi_select'" v-model="obj.form[field.name]" multiple>
                        <el-option v-for="item in obj.options[field.name]" :label="item.label" :value="item.value" :key="item.value"></el-option>
                    </el-select>


                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="obj.doSubmit">提 交</el-button>
                </el-form-item>

            </el-form>
        </div>
    </el-dialog>
</template>

<script setup>
import {defineProps} from "vue";

defineProps(['obj'])


</script>

<style scoped>

</style>