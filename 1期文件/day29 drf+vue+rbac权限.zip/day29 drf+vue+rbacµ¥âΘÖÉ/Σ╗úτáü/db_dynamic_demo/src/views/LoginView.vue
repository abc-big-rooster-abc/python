<template>
    <div class="box">
        <p>
            <input type="text" placeholder="用户名" v-model="state.form.user">
        </p>
        <p>
            <input type="text" placeholder="密码" v-model="state.form.password">
        </p>
        <p>
            <input type="button" value="登录" @click="doLogin"/>
        </p>
    </div>
</template>

<script setup>

import {getCurrentInstance, reactive} from "vue";
import {useStore} from "vuex";
import {useRouter} from "vue-router";
import {ElMessage} from "element-plus";

const store = useStore();
const router = useRouter()
const {proxy} = getCurrentInstance()

const state = reactive({
    form: {
        user: "wupeiqi",
        password: "123",
    }
})

function doLogin() {
    //1.向后台发送请求且登录成功
    //2.返回信息
    // const context = {
    //     routers: ["menu", 'role', 'user', 'more'],
    //     menus: [
    //         {
    //             id: 1,
    //             title: "权限管理",
    //             icon: "User",
    //             children: [
    //                 {name: "menu", title: "菜单"},
    //                 {name: "role", title: "角色"},
    //                 {name: "user", title: "用户"},
    //             ]
    //         },
    //         {
    //             id: 2,
    //             title: "VIP中心",
    //             icon: "Box",
    //             children: [
    //                 {name: "more", title: "更多"},
    //             ]
    //         }
    //     ],
    //     permissions: {
    //         "more": ["GET", "POST"],
    //         "more-detail": ["GET", "PUT", "DELETE"],
    //     },
    //     token: "fe4892c7-dc9d-4dae-a2f6-02f0c63ea752"
    // };

    proxy.$axios.post(`/api/login/`,state.form).then((res) => {
        let context = res.data.data;
        //3.保存vuex
        store.commit("login", context);
        //4.跳转后台
        router.replace({name: context.routers[0]})
    });



}


</script>

<style scoped>
.box {
    border: 1px solid #ddd;
    width: 300px;
    margin-top: 200px;
    margin-left: auto;
    margin-right: auto;
    padding: 30px;
}
</style>