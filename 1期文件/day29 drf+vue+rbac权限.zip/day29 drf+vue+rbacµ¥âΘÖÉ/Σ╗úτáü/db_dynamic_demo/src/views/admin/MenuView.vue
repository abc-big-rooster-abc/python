<template>
    <div>
        <el-row :gutter="20">
            <el-col :span="5" v-loading="state.firstLoading">
                <el-card class="box-card" shadow="never" :body-style="{ padding: '0px'}">
                    <template #header>
                        <div class="card-header">
                            <span>一级菜单</span>
                            <el-button size="small" type="success" class="button"
                                       @click="state.firstDialog.dialogVisible=true">新建
                            </el-button>

                        </div>
                    </template>
                    <el-table :data="state.firstList" style="width: 100%;" size="small"
                              :row-class-name="doRowClass(state.firstSelected)">
                        <el-table-column prop="title" label="标题" align="center">
                            <template #default="scope">
                                <el-link @click="clickFirstRow(scope.row)" style="font-size: 12px" :underline="false">
                                    {{ scope.row.title }}
                                </el-link>
                            </template>
                        </el-table-column>
                        <el-table-column prop="icon" label="图标" align="center">
                            <template #default="scope">
                                <el-icon>
                                    <component :is="scope.row.icon"></component>
                                </el-icon>
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" align="center">

                            <template #default="scope">
                                <el-popconfirm
                                    cancel-button-type="danger"
                                    confirm-button-text="确认"
                                    cancel-button-text="取消"
                                    @confirm="confirmFirstDelete(scope.row)"
                                    title="是否确定删除?">
                                    <template #reference>
                                        <el-button size="small" type="danger" icon="Delete"
                                                   class="confirm-delete"></el-button>
                                    </template>
                                </el-popconfirm>

                            </template>
                        </el-table-column>
                    </el-table>
                </el-card>
            </el-col>

            <el-col :span="8" v-loading="state.secondLoading">
                <el-card class="box-card" :body-style="{ padding: '0px'}">
                    <template #header>
                        <div class="card-header">
                            <span>二级菜单（路由）</span>
                            <el-button @click="state.secondDialog.dialogVisible=true" v-if="state.firstSelected"
                                       size="small" type="success" class="button">
                                新建
                            </el-button>
                        </div>
                    </template>
                    <el-table :data="state.secondList" style="width: 100%;" size="small"
                              :row-class-name="doRowClass(state.secondSelected)">
                        <el-table-column prop="title" label="标题" align="center">
                            <template #default="scope">
                                <el-link @click="clickSecondRow(scope.row)" style="font-size: 12px" :underline="false">
                                    {{ scope.row.title }}
                                </el-link>
                            </template>
                        </el-table-column>
                        <el-table-column prop="name" label="路由" align="center"/>
                        <el-table-column prop="is_menu" label="是否菜单" align="center"/>
                        <el-table-column label="操作" align="center">
                            <template #default="scope">
                                <el-popconfirm
                                    cancel-button-type="danger"
                                    confirm-button-text="确认"
                                    cancel-button-text="取消"
                                    @confirm="confirmSecondDelete(scope.row)"
                                    title="是否确定删除?">
                                    <template #reference>
                                        <el-button size="small" type="danger" icon="Delete"
                                                   class="confirm-delete"></el-button>
                                    </template>
                                </el-popconfirm>

                            </template>
                        </el-table-column>
                    </el-table>

                </el-card>
            </el-col>

            <el-col :span="11">

                <el-card class="box-card" :body-style="{ padding: '0px'}">
                    <template #header>
                        <div class="card-header">
                            <span>权限列表</span>
                            <el-button @click="state.thirdDialog.dialogVisible=true" v-if="state.secondSelected"
                                       size="small" type="success" class="button">新建
                            </el-button>
                        </div>
                    </template>
                    <el-table :data="state.thirdList" style="width: 100%;" size="small">
                        <el-table-column prop="title" label="标题" align="center"/>
                        <el-table-column prop="name" label="API代码" align="center"/>
                        <el-table-column prop="method" label="方法" align="center"/>
                        <el-table-column label="操作" align="center">
                            <template #default="scope">
                                <el-popconfirm
                                    cancel-button-type="danger"
                                    confirm-button-text="确认"
                                    cancel-button-text="取消"
                                    @confirm="confirmThirdDelete(scope.row)"
                                    title="是否确定删除?">
                                    <template #reference>
                                        <el-button size="small" type="danger" icon="Delete"
                                                   class="confirm-delete"></el-button>
                                    </template>
                                </el-popconfirm>

                            </template>
                        </el-table-column>
                    </el-table>

                </el-card>

            </el-col>
        </el-row>
    </div>

    <el-dialog v-model="state.firstDialog.dialogVisible" title="一级菜单" width="30%">
        <div>
            <el-form :model="state.firstDialog.form" ref="smsRef" label-width="80px">


                <el-form-item style="margin-top: 24px;" prop="title" :error="state.firstDialog.errors.title" label="标题">
                    <el-input v-model="state.firstDialog.form.title" placeholder="请输入标题"></el-input>
                </el-form-item>


                <el-form-item style="margin-top: 24px;" prop="title" :error="state.firstDialog.errors.icon" label="标题">

                    <el-select v-model="state.firstDialog.form.icon">
                        <el-option :label="item" :value="item" :key="item"
                                   v-for="item in state.firstDialog.options.icon">
                             <span style="float: left">
                                  <el-icon>
                                      <component :is="item"></component>
                                  </el-icon>
                              </span>
                            <span style="float: right; color: #8492a6; font-size: 13px">{{ item }}</span>
                        </el-option>
                    </el-select>

                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="doFirstSubmit">提 交</el-button>
                </el-form-item>


            </el-form>
        </div>
    </el-dialog>

    <MineDialog :obj="state.secondDialog"/>

    <MineDialog :obj="state.thirdDialog"/>
</template>

<script setup>

import {reactive, onMounted, getCurrentInstance} from "vue";
import {ElMessage} from "element-plus";
import {clearFormError, validateFormError} from "@/plugins/form";
import MineDialog from '@/components/MineDialog'

const {proxy} = getCurrentInstance()
const state = reactive({
    firstLoading: false,
    firstList: [],
    firstSelected: 0,
    firstDialog: {
        dialogVisible: false,
        form: {
            title: "",
            icon: ""
        },
        errors: {
            title: "",
            icon: ""
        },
        options: {
            icon: ['User', 'Setting', "Search", "Notification", "PieChart", 'CreditCard', "Wallet"],
        }
    },

    secondLoading: false,
    secondSelected: 0,
    secondList: [],
    secondDialog: {
        title:"新建路由",
        dialogVisible: false,
        form: {
            title: "",
            name: "",
            is_menu: false,
        },
        fields: [
            {name: "title", label: "标题", widget: 'input'},
            {name: "name", label: "路由", widget: 'input'},
            {name: "is_menu", label: "是否菜单", widget: 'switch'},
        ],
        errors: {
            title: "",
            name: "",
            is_menu: "",
        },
        doSubmit: doSecondSubmit
    },


    thirdLoading: false,
    thirdList: [],
    thirdDialog: {
        title:"新建权限",
        dialogVisible: false,
        form: {
            title: "",
            name: "",
            method: "",
        },
        fields: [
            {name: "title", label: "标题", widget: 'input'},
            {name: "name", label: "API代码", widget: 'input'},
            {name: "method", label: "方法", widget: 'select'},
        ],
        options: {
            method: [
                {label: "GET", value: "GET"},
                {label: "POST", value: "POST"},
                {label: "PUT", value: "PUT"},
                {label: "PATCH", value: "PATCH"},
                {label: "DELETE", value: "DELETE"},
            ]
        },
        errors: {
            title: "",
            name: "",
            method: "",
        },
        doSubmit: doThirdSubmit
    },
})


onMounted(() => {
    initFirst();
})

function initFirst() {
    state.firstLoading = true;
    proxy.$axios.get(`/api/folder/`).then((res) => {
        if (res.data.code === 0) {
            state.firstList = res.data.data;
            state.firstLoading = false;
        } else {
            ElMessage.error("请求失败");
        }
    });
}

function clickFirstRow(row) {
    // 1.已选择的行ID
    state.firstSelected = row.id;

    // 2.二级菜单清空
    state.secondList = [];
    state.secondSelected = 0;

    // 3.权限列表清空
    state.thirdList = [];


    // 4.发送请求获取二级菜单   /api/router/?folder=1  /api/router/?folder=2
    state.secondLoading = true;
    proxy.$axios.get(`/api/router/`, {params: {folder: row.id}}).then((res) => {
        if (res.data.code === 0) {
            state.secondList = res.data.data;
            state.secondLoading = false;
        } else {
            ElMessage.error("请求失败");
        }
    });


}

function doRowClass(target) {
    return function ({row}) {
        if (row.id === target) {
            return "row-active";
        }
        return "";
    }
}


function confirmFirstDelete(row) {
    proxy.$axios.delete(`/api/folder/${row.id}/`).then((res) => {
        if (res.data) {
            if (res.data.code !== 0) {
                ElMessage.error(res.data.detail);
            }
        } else {
            state.firstList = state.firstList.filter((item) => {
                return item.id !== row.id;
            });
            if (row.id === state.firstSelected) {
                state.firstSelected = 0;
                state.secondList = [];
            }
            ElMessage.success("删除成功");
        }
    })
}

function clickSecondRow(row) {
    // 1.已选择的行ID
    state.secondSelected = row.id;
    state.thirdList = [];

    // 2.发送请求，获取下属的权限   /api/permision/?router=1    /api/permision/?router=2
    state.thirdLoading = true;
    proxy.$axios.get(`/api/permission/`, {params: {router: row.id}}).then((res) => {
        if (res.data.code === 0) {
            state.thirdList = res.data.data;
            state.thirdLoading = false;
        } else {
            ElMessage.error("请求失败");
        }
    });
}

function confirmSecondDelete(row) {
    proxy.$axios.delete(`/api/router/${row.id}/`).then((res) => {
        if (res.data) {
            if (res.data.code !== 0) {
                ElMessage.error(res.data.detail);
            }
        } else {
            state.secondList = state.secondList.filter((item) => {
                return item.id !== row.id;
            });
            if (row.id === state.secondSelected) {
                state.secondSelected = 0;
            }
            ElMessage.success("删除成功");
        }
    })

}

function confirmThirdDelete(row) {
    proxy.$axios.delete(`/api/permission/${row.id}/`).then((res) => {
        if (res.data) {
            if (res.data.code !== 0) {
                ElMessage.error(res.data.detail);
            }
        } else {
            state.thirdList = state.thirdList.filter((item) => {
                return item.id !== row.id;
            });

            ElMessage.success("删除成功");
        }
    })
}


function doFirstSubmit() {
    // 清除自定义错误
    clearFormError(state.firstDialog.errors);

    console.log(state.firstDialog.form);
    proxy.$axios.post(`/api/folder/`, state.firstDialog.form).then((res) => {
        if (res.data.code === 0) {
            // 1.对话框关闭
            state.firstDialog.dialogVisible = false;

            // 2.新数据加入列表
            state.firstList.push(res.data.data);

            // 3.对话框置空
            for (let key in state.firstDialog.form) {
                state.firstDialog.form[key] = "";
            }
        } else if (res.data.code === 1005) {
            validateFormError(state.firstDialog.errors, res.data.detail)
        } else {
            ElMessage.error("请求失败");
        }

    });
}


function doSecondSubmit() {
    console.log(state.secondDialog.form);

    // 清除自定义错误
    clearFormError(state.secondDialog.errors);

    let form = state.secondDialog.form;
    form.folder = state.firstSelected;

    proxy.$axios.post(`/api/router/`, form).then((res) => {
        if (res.data.code === 0) {
            // 1.对话框关闭
            state.secondDialog.dialogVisible = false;

            // 2.新数据加入列表
            state.secondList.push(res.data.data);

            // 3.对话框置空
            for (let key in state.secondDialog.form) {
                if (key === "is_menu") {
                    state.secondDialog.form[key] = false;
                } else {
                    state.secondDialog.form[key] = "";
                }
            }

        } else if (res.data.code === 1005) {
            validateFormError(state.secondDialog.errors, res.data.detail)
        } else {
            ElMessage.error("请求失败");
        }

    });

}

function doThirdSubmit() {
    console.log(state.thirdDialog.form);
    // 清除自定义错误
    clearFormError(state.thirdDialog.errors);

    let form = state.thirdDialog.form;
    form.router = state.secondSelected;

    proxy.$axios.post(`/api/permission/`, form).then((res) => {
        if (res.data.code === 0) {
            // 1.对话框关闭
            state.thirdDialog.dialogVisible = false;

            // 2.新数据加入列表
            state.thirdList.push(res.data.data);

            // 3.对话框置空
            for (let key in state.thirdDialog.form) {
                state.thirdDialog.form[key] = "";
            }

        } else if (res.data.code === 1005) {
            validateFormError(state.thirdDialog.errors, res.data.detail)
        } else {
            ElMessage.error("请求失败");
        }

    });
}
</script>

<style scoped>
.card-header {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}

.confirm-delete {
    padding: 0 2px;
    font-size: 12px;
    height: 18px;
    width: 18px;
}
</style>

<style>
.el-table .row-active {
    --el-table-tr-bg-color: var(--el-color-primary-light-9);
}

.el-table .row-active .el-link__inner {
    color: #409eff;
}
</style>