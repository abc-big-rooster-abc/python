<template>
    <div v-permission="['admin-list','POST']" style="margin-bottom: 8px">
        <el-button type="success" @click="state.addDialog.dialogVisible=true">新建用户</el-button>
    </div>


    <el-table :data="state.userList" style="width: 100%;" size="small" border>
        <el-table-column prop="user" label="用户名" align="center"/>
        <el-table-column prop="password" label="密码" align="center"/>
        <el-table-column label="角色" align="left">
            <template #default="scope">
                <el-tag style="margin-right: 5px;" v-for="item in scope.row.role_display" :key="item.id">{{
                        item.title
                    }}
                </el-tag>
            </template>
        </el-table-column>

        <el-table-column label="操作" align="center">
            <template #default="scope">
                <el-popconfirm
                    cancel-button-type="danger"
                    confirm-button-text="确认"
                    cancel-button-text="取消"
                    @confirm="confirmRoleDelete(scope.row)"
                    title="是否确定删除?">
                    <template #reference>
                        <el-button size="small" type="danger" icon="Delete"
                                   class="confirm-delete"></el-button>
                    </template>
                </el-popconfirm>

            </template>
        </el-table-column>
    </el-table>

    <MineDialog :obj="state.addDialog"/>
</template>

<script setup>

import {getCurrentInstance, onMounted, reactive} from "vue";
import MineDialog from '@/components/MineDialog'
import {validateFormError} from "@/plugins/form";
import {ElMessage} from "element-plus";

const {proxy} = getCurrentInstance()

const state = reactive({
    userList: [],
    addDialog: {
        title: "新建用户",
        dialogVisible: false,
        form: {
            user: "",
            password: "",
            roles: ""
        },
        fields: [
            {name: "user", label: "用户名", widget: 'input'},
            {name: "password", label: "密码", widget: 'input'},
            {name: "roles", label: "角色", widget: 'multi_select'},
        ],
        options: {
            roles: [
                {label: "谢新雪", value: "xxx"}
            ]
        },
        errors: {
            title: "",
            name: "",
            is_menu: "",
        },
        doSubmit: doAddSubmit
    },
})


onMounted(() => {
    initUser();
    initRoleList();
})

function initUser() {
    proxy.$axios.get(`/api/admin/`).then((res) => {
        state.userList = res.data.data;
    });
}

function initRoleList() {
    proxy.$axios.get(`/api/admin_role/`).then((res) => {
        // console.log(res.data.data);

        let roleList = res.data.data.map((item) => {
            return {label: item.title, value: item.id}
        });

        state.addDialog.options.roles = roleList;
    });
}

function doAddSubmit() {
    // {user:?,password:?,roles:?}
    proxy.$axios.post(`/api/admin/`, state.addDialog.form).then((res) => {
        if (res.data.code === 0) {
            state.addDialog.dialogVisible = false;
            ElMessage.success("新建成功");
            state.userList.push(res.data.data);
        }
    });
}

function confirmRoleDelete(row) {
    proxy.$axios.delete(`/api/admin/${row.id}/`).then((res) => {
        if (res.data) {
            if (res.data.code !== 0) {
                ElMessage.error(res.data.detail);
            }
        } else {
            state.userList = state.userList.filter((item) => {
                return item.id !== row.id;
            });
            ElMessage.success("删除成功");
        }
    });
}
</script>

<style scoped>

</style>