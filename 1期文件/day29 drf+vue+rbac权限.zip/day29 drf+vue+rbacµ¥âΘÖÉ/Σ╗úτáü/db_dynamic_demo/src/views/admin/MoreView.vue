<template>
    <h1>More</h1>
    <ul>
        <li v-if="hasPermission('more','POST')">新增</li>
        <li v-permission="['more-detail','PUT']">修改</li>
        <li>删除</li>
    </ul>
</template>

<script setup>
import {hasPermission} from "@/store/permission";


</script>

<style scoped>

</style>