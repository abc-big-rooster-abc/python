<template>
    <div>
        <el-row :gutter="20">
            <el-col :span="5" v-loading="state.roleLoading">
                <el-card class="box-card" shadow="never" :body-style="{ padding: '0px'}">
                    <template #header>
                        <div class="card-header">
                            <span>角色列表</span>
                            <el-button @click="state.roleDialog.dialogVisible=true" size="small" type="success"
                                       class="button">新建
                            </el-button>

                        </div>
                    </template>
                    <el-table :data="state.roleList" style="width: 100%;" size="small"
                              :row-class-name="doRowClass(state.roleSelected)">
                        <el-table-column prop="title" label="标题" align="center">
                            <template #default="scope">
                                <el-link @click="clickRoleRow(scope.row)" style="font-size: 12px" :underline="false">
                                    {{ scope.row.title }}
                                </el-link>
                            </template>
                        </el-table-column>

                        <el-table-column label="操作" align="center">
                            <template #default="scope">
                                <el-popconfirm
                                    cancel-button-type="danger"
                                    confirm-button-text="确认"
                                    cancel-button-text="取消"
                                    @confirm="confirmRoleDelete(scope.row)"
                                    title="是否确定删除?">
                                    <template #reference>
                                        <el-button size="small" type="danger" icon="Delete"
                                                   class="confirm-delete"></el-button>
                                    </template>
                                </el-popconfirm>

                            </template>
                        </el-table-column>
                    </el-table>
                </el-card>
            </el-col>

            <el-col :span="19" v-loading="state.permissionLoading">
                <el-card class="box-card" shadow="never" :body-style="{ padding: '0px'}">
                    <template #header>
                        <div class="card-header">
                            <span>分配权限</span>
                            <el-button @click="doSavePermission" v-if="state.roleSelected>0" size="small" type="success"
                                       class="button">保存
                            </el-button>
                        </div>
                    </template>

                    <div style="color: #d4d4d4;padding:10px  5px;font-size: 13px;border-bottom: 1px solid #e4e7ed">
                        提示：请先选择角色，然后再分配权限
                    </div>

                    <el-tree
                        :data="state.permissionList"
                        :show-checkbox="state.roleSelected>0"
                        node-key="id"
                        ref="permissionTree"
                        default-expand-all
                        :expand-on-click-node="false"
                        :props="{ class: customNodeClass }"
                        :check-on-click-node="true"
                    />

                </el-card>
            </el-col>

        </el-row>
    </div>


    <MineDialog :obj="state.roleDialog"/>
</template>

<script setup>

import {getCurrentInstance, onMounted, reactive} from "vue";
import {ElMessage} from "element-plus";
import MineDialog from '@/components/MineDialog'
import {clearFormError, validateFormError} from "@/plugins/form";


const {proxy} = getCurrentInstance()
const state = reactive({
    roleLoading: false,
    roleSelected: 0,
    roleList: [],
    roleDialog: {
        title: "新建角色",
        dialogVisible: false,
        form: {
            title: ""
        },
        fields: [
            {name: "title", label: "名称", widget: 'input'}
        ],
        errors: {
            title: ""
        },
        doSubmit: doRoleSubmit
    },

    permissionLoading: false,
    permissionList: []
})


onMounted(() => {
    initRole();
    initTotalPermission();
})

function initTotalPermission() {
    // 获取所有的权限信息
    // state.permissionList = [
    //     {
    //         id: 1,
    //         label: '目录1',
    //         children: [
    //             {
    //                 id: 3,
    //                 label: '路由1',
    //                 isPenultimate: true,
    //                 children: [
    //                     {
    //                         id: 9,
    //                         label: 'Level three 1-1-1',
    //                     },
    //                     {
    //                         id: 10,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                 ],
    //             },
    //             {
    //                 id: 4,
    //                 label: '路由2',
    //                 isPenultimate: true,
    //                 children: [
    //                     {
    //                         id: 9,
    //                         label: 'Level three 1-1-1',
    //                     },
    //                     {
    //                         id: 10,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                     {
    //                         id: 11,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                     {
    //                         id: 12,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                     {
    //                         id: 13,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                     {
    //                         id: 14,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                 ],
    //             },
    //         ],
    //     },
    //     {
    //         id: 2,
    //         label: '目录1',
    //         children: [
    //             {
    //                 id: 5,
    //                 label: '路由1',
    //                 isPenultimate: true,
    //                 children: [
    //                     {
    //                         id: 19,
    //                         label: 'Level three 1-1-1',
    //                     },
    //                     {
    //                         id: 110,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                 ],
    //             },
    //             {
    //                 id: 6,
    //                 label: '路由2',
    //                 isPenultimate: true,
    //                 children: [
    //                     {
    //                         id: 29,
    //                         label: 'Level three 1-1-1',
    //                     },
    //                     {
    //                         id: 120,
    //                         label: 'Level three 1-1-2',
    //                     },
    //                 ],
    //             },
    //         ],
    //     },
    // ]

    proxy.$axios.get(`/api/permission/total/`).then((res) => {
        state.permissionList = res.data.data;
    });

}

function customNodeClass(data) {
    if (data.child_horizontal) {
        return 'is-penultimate'
    }
    return null
}

function initRole() {
    state.roleLoading = true;
    proxy.$axios.get(`/api/role/`).then((res) => {
        if (res.data.code === 0) {
            state.roleList = res.data.data;
            state.roleLoading = false;
        } else {
            ElMessage.error("请求失败");
        }
    });
}

function doRoleSubmit() {
    // 清除自定义错误
    clearFormError(state.roleDialog.errors);

    proxy.$axios.post(`/api/role/`, state.roleDialog.form).then((res) => {
        if (res.data.code === 0) {
            // 1.对话框关闭
            state.roleDialog.dialogVisible = false;

            // 2.新数据加入列表
            state.roleList.push(res.data.data);

            // 3.对话框置空
            for (let key in state.roleDialog.form) {
                state.roleDialog.form[key] = "";
            }
        } else if (res.data.code === 1005) {
            validateFormError(state.roleDialog.errors, res.data.detail)
        } else {
            ElMessage.error("请求失败");
        }
    });
}

function confirmRoleDelete(row) {
    proxy.$axios.delete(`/api/role/${row.id}/`).then((res) => {
        if (res.data) {
            if (res.data.code !== 0) {
                ElMessage.error(res.data.detail);
            }
        } else {
            state.roleList = state.roleList.filter((item) => {
                return item.id !== row.id;
            });
            if (row.id === state.roleSelected) {
                state.roleSelected = 0;
            }
            ElMessage.success("删除成功");
        }
    })
}

function doRowClass(target) {
    return function ({row}) {
        if (row.id === target) {
            return "row-active";
        }
        return "";
    }
}


function clickRoleRow(row) {
    // 1.已选择的行ID
    state.roleSelected = row.id;

    state.permissionLoading = true;
    // 2.发送请求，获取当前角色具备的权限
    proxy.$axios.get(`/api/role/${row.id}/permission/`).then((res) => {
        //proxy.$refs.permissionTree.setCheckedKeys([5,4]);
        proxy.$refs.permissionTree.setCheckedKeys(res.data.data);
        state.permissionLoading = false;
    });
}

function doSavePermission() {
    //1.获取选中的权限列表
    let checkedList = proxy.$refs.permissionTree.getCheckedKeys(true)
    checkedList = checkedList.filter((item) => {
        return typeof item === "number"
    });

    //2.发送后端API
    state.permissionLoading = true;
    proxy.$axios.post(`/api/role/${state.roleSelected}/update/permission/`, {permissions: checkedList}).then((res) => {
        state.permissionLoading = false;
        console.log(res);
        if (res.data.code === 0) {
            ElMessage.success("分配成功");
        } else {
            ElMessage.error("分配失败");
        }
    });

}
</script>


<style scoped>
.card-header {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}

.confirm-delete {
    padding: 0 2px;
    font-size: 12px;
    height: 18px;
    width: 18px;
}
</style>

<style>
.el-table .row-active {
    --el-table-tr-bg-color: var(--el-color-primary-light-9);
}

.el-table .row-active .el-link__inner {
    color: #409eff;
}

.is-penultimate > .el-tree-node__content {
    /*color: #626aef;*/
}

.el-tree-node__content {
    padding: 5px;
}

.el-tree-node.is-expanded.is-penultimate > .el-tree-node__children {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
}

.is-penultimate > .el-tree-node__children > div {
    width: 25%;
}
</style>

