# info_dict = {
# }
#
# item = [11, 22, 33]
#
# info_dict["xx"] = item
#
# # info_dict['xx'].append(999)
# # print(item) # 有没有999？
#
# item.append(999)
# print(info_dict['xx']) # # 有没有999？