from rest_framework import serializers
from rest_framework.permissions import BasePermission
from rest_framework.authentication import BaseAuthentication
from rest_framework import exceptions
from rest_framework.filters import BaseFilterBackend
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.mixins import ListModelMixin, CreateModelMixin

from api import models

from utils.viewsets import ModelViewSet, GenericViewSet
from utils.exceptions import ExtraException


class FolderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Folder
        fields = "__all__"


class FolderView(ModelViewSet):
    queryset = models.Folder.objects.all()
    serializer_class = FolderSerializer

    def perform_destroy(self, instance):
        if models.Router.objects.filter(folder=instance).exists():
            raise ExtraException("无法删除，请先处理下级关联数据")
        instance.delete()


class RouterSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Router
        fields = "__all__"


class RouterFilterBackend(BaseFilterBackend):
    def filter_queryset(self, request, queryset, view):
        folder = request.query_params.get('folder')
        if folder:
            queryset = queryset.filter(folder_id=folder)
        return queryset


class RouterView(ModelViewSet):
    queryset = models.Router.objects.all()
    serializer_class = RouterSerializer
    filter_backends = [RouterFilterBackend]

    def perform_destroy(self, instance):
        if models.Permission.objects.filter(router=instance).exists():
            raise ExtraException("无法删除，请先处理下级关联数据")
        instance.delete()


class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Permission
        fields = "__all__"


class PermissionFilterBackend(BaseFilterBackend):
    def filter_queryset(self, request, queryset, view):
        router = request.query_params.get('router')
        if router:
            queryset = queryset.filter(router_id=router)
        return queryset


class PermissionView(ModelViewSet):
    queryset = models.Permission.objects.all()
    serializer_class = PermissionSerializer
    filter_backends = [PermissionFilterBackend]

    @action(detail=False, methods=['get'], url_path="total", url_name='total')
    def total(self, request):
        # 获取所有的权限信息+路由+目录（构造上下级关系）

        # 1.获取目录 [obj,obj,obj]  [{"id":1,"title":xxx},..]
        # folder_queryset = models.Folder.objects.all()
        # folder_queryset = models.Folder.objects.all().values("id", 'title')

        folder_queryset = models.Folder.objects.all().extra(select={"label": "title"}).values("id", 'label')

        # folder_dict = {
        #     "folder-1": {'label': '权限管理', 'id': "folder-1", "children": [
        #         {'label': '用户管理', 'id': 'router-2', 'folder_id': 1, "child_horizontal": True, "children": []}
        #     ]},
        #     "folder-5": {'label': 'VIP中心', 'id': "folder-5", "children": []}
        # }
        folder_dict = {}
        for item in folder_queryset:
            item['id'] = f"folder-{item['id']}"
            item['children'] = []
            folder_dict[item['id']] = item

        # 2.获取路由
        router_queryset = models.Router.objects.all().extra(select={"label": "title"}).values("id", 'label',
                                                                                              "folder_id", "is_menu")

        # router_dict = {
        #     'router-2': {'label': '用户管理', 'id': 'router-2', 'folder_id': 1, "child_horizontal": True, "children": []}
        # }
        router_dict = {}

        for item in router_queryset:
            item['id'] = f"router-{item['id']}"
            item['child_horizontal'] = True
            item['children'] = []

            if item['is_menu']:
                item['label'] = f"{item['label']} (菜单) "

            router_dict[item['id']] = item

            folder_id = f"folder-{item['folder_id']}"
            folder_dict[folder_id]['children'].append(item)

        # 3.获取权限
        permission_queryset = models.Permission.objects.all().extra(select={'label': "title"}).values("id", "label",
                                                                                                      'router_id')
        for item in permission_queryset:
            router_id = f"router-{item['router_id']}"
            router_dict[router_id]['children'].append(item)

        return Response(folder_dict.values())


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Role
        fields = ['id', 'title']


class RoleView(ModelViewSet):
    queryset = models.Role.objects.all()
    serializer_class = RoleSerializer

    # /api/role/12/permission    role-permission
    @action(detail=True, methods=['get'], url_path="permission", url_name='permission')
    def permission(self, request, pk):
        instance = self.get_object()
        queryset = instance.permissions.all()
        permission_list = [item.id for item in queryset]
        return Response(permission_list)

    @action(detail=True, methods=['post'], url_path="update/permission", url_name='update_permission')
    def update_permission(self, request, pk):
        # 获取权限ID列表
        permission_id_list = request.data.get("permissions")
        print(permission_id_list)  # [1, 3, 4, 5]

        # 权限赋值给当前角色
        instance = self.get_object()
        instance.permissions.set(permission_id_list)

        return Response("ok")


class AdminRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Role
        fields = ['id', 'title']


class AdminSerializer(serializers.ModelSerializer):
    # more = serializers.SerializerMethodField()
    role_display = AdminRoleSerializer(many=True, source='roles')

    class Meta:
        model = models.Admin
        fields = "__all__"

    # def get_more(self, obj):
    #     return [{"id": row.id, 'title': row.title} for row in obj.roles.all()]


class AdminCreateSerializer(serializers.ModelSerializer):
    role_display = AdminRoleSerializer(many=True, read_only=True, source='roles')

    class Meta:
        model = models.Admin
        fields = "__all__"


class AdminView(ModelViewSet):
    queryset = models.Admin.objects.all()
    serializer_class = AdminSerializer

    def get_serializer_class(self):
        if self.request.method == "POST":
            return AdminCreateSerializer
        return AdminSerializer


class AdminRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Role
        fields = ['id', 'title']


class AdminRoleView(ListModelMixin, GenericViewSet):
    queryset = models.Role.objects.all()
    serializer_class = AdminRoleSerializer


class LoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Admin
        fields = ['user', 'password']


class LoginView(CreateModelMixin, GenericViewSet):
    queryset = models.Admin.objects.all()
    serializer_class = LoginSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        print(serializer.data)  # 用户名和密码
        # 根据用户名和密码获取相应的信息：token、permission、router、menu
        # 1.登录
        admin_object = models.Admin.objects.filter(**serializer.data).first()
        if not admin_object:
            raise ExtraException("用户名或密码错误", ret_code=9999)

        # 2.获取各种 permission、router、folder
        # [Role object,Role object]
        result = admin_object.roles.all().values(
            "id", "title",
            "permissions__title", "permissions__name", "permissions__method", "permissions__router_id",
            "permissions__router__title", "permissions__router__name", "permissions__router__is_menu",
            "permissions__router__folder_id",
            "permissions__router__folder__title", "permissions__router__folder__icon"
        )

        # 3.提取路由
        routers = set()
        permissions = {}
        folder_dict = {}
        router_dict = {}

        for item in result:
            # print(item)
            # 路由
            router_name = item['permissions__router__name']
            routers.add(router_name)

            # 权限
            permission_name = item['permissions__name']
            permission_method = item['permissions__method']
            if permission_name not in permissions:
                permissions[permission_name] = {permission_method}
            else:
                permissions[permission_name].add(permission_method)

            # 目录
            folder_id = item['permissions__router__folder_id']
            folder_dict[folder_id] = {
                'id': item['permissions__router__folder_id'],
                'title': item['permissions__router__folder__title'],
                'icon': item['permissions__router__folder__icon'],
                'children': []
            }

            # 路由
            router_id = item['permissions__router_id']
            if item["permissions__router__is_menu"]:
                router_dict[router_id] = {
                    'id': item['permissions__router_id'],
                    'title': item['permissions__router__title'],
                    'name': item['permissions__router__name'],
                    'folder_id': item['permissions__router__folder_id'],
                }

        for item in router_dict.values():
            folder_id = item['folder_id']
            folder_dict[folder_id]['children'].append(item)

        context = {
            'routers': routers,
            'permissions': permissions,
            "menus": folder_dict.values(),
            "token": "fe4892c7-dc9d-4dae-a2f6-02f0c63ea752"
        }

        return Response(context)
