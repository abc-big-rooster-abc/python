# day27 django权限相关

> 本节是drf+vue权限校验的前置课



本节主要跟大家聊聊权限相关的内容，涉及的知识点：

- django内置组件
- django自定义组件



# 1.django内置组件

django内置的权限是在auth组件中实现的，而auth组件又依赖信号、content types、admin组件，所以，我们需要先了解这些组件然后再学习django内置权限的实现机制。



## 1.1 信号

### 1.1.1 自定义信号

- 定义信号

  ```python
  import django.dispatch
  
  # 自定义信号
  cut_info_signal = django.dispatch.Signal()
  ```

- 注册回调

  ```python
  from utils.signals import cut_info_signal
  
  
  def callback_1(sender, **kwargs):
      print("callback-1")
  
  
  def callback_2(sender, **kwargs):
      print("callback-2")
  
  
  cut_info_signal.connect(callback_1)
  cut_info_signal.connect(callback_2)
  ```

- 触发信号

  ```python
  from utils.signals import cut_info_signal
  cut_info_signal.send("demo")
  ```

将某些动作都注册在一个信号中，一旦达到条件则触发信号(所有回调都执行)。



### 1.1.2 内置信号

```Python
Model signals
    pre_init                    # django的modal执行其构造方法前，自动触发
    post_init                   # django的modal执行其构造方法后，自动触发
    pre_save                    # django的modal对象保存前，自动触发
    post_save                   # django的modal对象保存后，自动触发
    pre_delete                  # django的modal对象删除前，自动触发
    post_delete                 # django的modal对象删除后，自动触发
    m2m_changed                 # django的modal中使用m2m字段操作第三张表
                                # （add,remove,clear）前后，自动触发
    class_prepared              # 程序启动时，检测已注册的app中modal类，对于每一个类，自动触发
Management signals
    pre_migrate                 # 执行migrate命令前，自动触发
    post_migrate                # 执行migrate命令后，自动触发
    
Request/response signals
    request_started             # 请求到来前，自动触发
    request_finished            # 请求结束后，自动触发
    got_request_exception       # 请求异常后，自动触发
    
Test signals
    setting_changed             # 使用test测试修改配置文件时，自动触发
    template_rendered           # 使用test测试渲染模板时，自动触发
    
Database Wrappers
    connection_created          # 创建数据库连接时，自动触发
```



- 注册信号回调

  ```python
  from django.core.signals import request_finished
  from django.core.signals import request_started
  from django.core.signals import got_request_exception
  
  from django.db.models.signals import class_prepared
  from django.db.models.signals import pre_init, post_init
  from django.db.models.signals import pre_save, post_save
  from django.db.models.signals import pre_delete, post_delete
  from django.db.models.signals import m2m_changed
  from django.db.models.signals import pre_migrate, post_migrate
  
  from django.test.signals import setting_changed
  from django.test.signals import template_rendered
  
  from django.db.backends.signals import connection_created
  
  
  def callback(sender, **kwargs):
      print("xxoo_callback")
  
  post_save.connect(callback) # 例如:插入一条数据，如何进行日志记录？
  ```

- 触发信号

  ```python
  from app01 import models
  
  def demo(request):
      models.NewBB.objects.create(name='v1')
      return HttpResponse("ok")
  ```

  

## 1.2 contenttypes

contenttypes组件的内部帮我们讲django的ORM中定义的所有表都自动手机起来，并保存至

![image-20230205000106942](assets/image-20230205000106942.png)



后续开发中如果遇到 一张表 与 其他n张表进行关联，就可以基于contenttypes实现。

![image-20230205001037128](assets/image-20230205001037128.png)



例如：早期某飞项目在设计时，有两种课程：学位课、普通课程，如果想要给课程定价的话，可以这样。

![image-20230205001527589](assets/image-20230205001527589.png)

```python
from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.contrib.contenttypes.models import ContentType


class DegreeCourse(models.Model):
    """学位课程"""
    name = models.CharField(max_length=128, unique=True)

    # 用于GenericForeignKey反向查询，不会生成表字段
    # degree_price_policy = GenericRelation("PricePolicy")


class Course(models.Model):
    """课程"""
    name = models.CharField(max_length=128, unique=True)
    # 用于GenericForeignKey反向查询，不会生成表字段
    # price_policy = GenericRelation("PricePolicy")


class PricePolicy(models.Model):
    """价格与有课程效期表"""
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)  # 关联course or degree_course
    object_id = models.PositiveIntegerField()

    # 方便设置值，不会生成表字段（直接设置为对象，自动生成 content_type和object_id）
    content_object = GenericForeignKey('content_type', 'object_id')

    price = models.IntegerField()
```



- 新建数据

  ```python
  
  def demo(request):
      from app03 import models
      # models.Course.objects.create(name="APP逆向") # 1
      # models.Course.objects.create(name="django项目") # 2
      # models.Course.objects.create(name="小程序") # 3
      #
      # models.DegreeCourse.objects.create(name="Python全栈")  # 1
      # models.DegreeCourse.objects.create(name="爬虫")  # 2
      # models.DegreeCourse.objects.create(name="Linux")  # 3
  
      # models.PricePolicy.objects.create(
      #     content_object=models.DegreeCourse.objects.get(name="Python全栈"),
      #     priod="3个月",
      #     price=100
      # )
      #
      # models.PricePolicy.objects.create(
      #     content_object=models.Course.objects.get(name="django项目"),
      #     priod="6个月",
      #     price=150
      # )
  
      queryset = models.PricePolicy.objects.all()
      for obj in queryset:
          print(obj.id, obj.priod, obj.price, obj.content_object, obj.content_object.name)
  
      return HttpResponse("ok")
  ```

- 查询

  ```python
  price_policy_queryset = models.PricePolicy.objects.all()
  for obj in price_policy_queryset:
      print(obj.content_object, obj.price)
      
  """
  DegreeCourse object (1) 100
  Course object (1) 200
  """
  ```

  ```python
  obj = models.DegreeCourse.objects.filter(name="Python全栈").first()
  
  print(  obj.degree_price_policy.all()  )
  
  """
  <QuerySet [<PricePolicy: PricePolicy object (2)>]>
  """
```
  
  



## 1.3 admin

admin是django中提供的一套可视化工具：用于对ORM中定义的表进行增删改查。

### 1.3.1 概览

在django项目启动时，自动找到注册到admin中的所有model中定义的类，然后为这些类生成一系列的URL和视图函数，实现基本增删改查等功能。

```
admin.site.register(models.UserInfo)
```

```
/admin/app名称/model名称/
/admin/app名称/model名称/add/
/admin/app名称/model名称/ID值/history/
/admin/app名称/model名称/ID值/change/
/admin/app名称/model名称/ID值/delete/
```

![image-20230205063639875](assets/image-20230205063639875.png)



### 1.3.2 基本使用

- 创建超级用户，用于登录admin

  ```
  python manage.py createsuperuser
  ```

- 登录
  ![image-20230205071631627](assets/image-20230205071631627.png)

- 配置
  ![image-20230205071743541](assets/image-20230205071743541.png)

- 访问
  ![image-20230205071822890](assets/image-20230205071822890.png)



### 1.3.3 源码分析

#### 1.加载admin.py

当**启动**django项目时，会先去加载每个app目录下载admin.py文件。

![image-20230205065624641](assets/image-20230205065624641.png)

![image-20230205065648363](assets/image-20230205065648363.png)



#### 2.加载类

在admin.py中对ORM中的表进行配置，根据配置定义其在admin组件中展示的增删改查，例如：

![image-20230205065951558](assets/image-20230205065951558.png)

![image-20230205070658842](assets/image-20230205070658842.png)

![image-20230205070552741](assets/image-20230205070552741.png)



#### 3.自动构造URL

![image-20230205070943201](assets/image-20230205070943201.png)

![image-20230205071119912](assets/image-20230205071119912.png)

![image-20230205071315285](assets/image-20230205071315285.png)

![image-20230205071451657](assets/image-20230205071451657.png)



### 1.3.4 常见配置

详见：https://www.cnblogs.com/wupeiqi/articles/7444717.html



### 1.3.5 自定义stark组件

参照admin的源码，构建自己更便捷的实现增删改查的组件。

- 文档

  ```
  https://www.cnblogs.com/wupeiqi/tag/crm%E9%A1%B9%E7%9B%AE/
  ```

- 视频

  ```
  链接: https://pan.baidu.com/s/1UJ51lZqzcgcy9tgC_dmqTg 提取码: pll4 
  ```

  

## 1.4 auth

auth组件在django中提供：admin登录、权限的配置等功能。

![image-20230205074603793](assets/image-20230205074603793.png)

![image-20230205074914570](assets/image-20230205074914570.png)

![image-20230205074957062](assets/image-20230205074957062.png)





### 1.4.1 创建用户

- 命令

  ```
  python manange.py createsuperuser
  ```

- 函数

  ```python
  from django.contrib import admin
  from django.urls import path
  from django.shortcuts import HttpResponse
  
  
  def demo(request):
      from django.contrib.auth import models
      models.User.objects.create_user("user-1", "xxx@live.com", "xxxxxxx123123")
      models.User.objects.create_superuser("user-2", "xxx@live.com", "xxxxxxx123123")
  
      return HttpResponse("ok")
  
  
  urlpatterns = [
      path('admin/', admin.site.urls),
      path('demo/', demo),
  ]
  ```

  

![image-20230205075140265](assets/image-20230205075140265.png)

![image-20230205075201328](assets/image-20230205075201328.png)



### 1.4.2 权限表

由于admin中为每个model类都会生成URL（增、删、改、查），所以在django中就以这些生成的URL的name值为权限标识（codename），后续用户访问时，根据请求url的name中来判断用户是否有权方法。

![image-20230205075410418](assets/image-20230205075410418.png)



#### 1.权限表内容

权限表内容是django内部自动生成，在我们执行migrate命令时，会自动触发 根据表创建权限的操作。

![image-20230205075824328](assets/image-20230205075824328.png)

![image-20230205080000504](assets/image-20230205080000504.png)



#### 2.分配权限

在admin中，给用户可以分配权限。

![image-20230205080140413](assets/image-20230205080140413.png)



![image-20230205080109932](assets/image-20230205080109932.png)



#### 3.权限校验

由于admin为每个表生成的增删改查的方法分别是：`changelist_view`、`add_view`、`delete_view`、`change_view`，所以每个权限的判断都定义在了相应的视图函数中。

![image-20230205071451657](assets/image-20230205071451657.png)



![image-20230205080746796](assets/image-20230205080746796.png)

![image-20230205080818474](assets/image-20230205080818474.png)

![image-20230205080844458](assets/image-20230205080844458.png)



判断权限：

![image-20230205080943178](assets/image-20230205080943178.png)

#### 4.组和权限

![image-20230205081439528](assets/image-20230205081439528.png)

![image-20230205081455186](assets/image-20230205081455186.png)



![image-20230205081614527](assets/image-20230205081614527.png)

![image-20230205081753180](assets/image-20230205081753180.png)

![image-20230205081722202](assets/image-20230205081722202.png)



![image-20230205081913071](assets/image-20230205081913071.png)

![image-20230205081930800](assets/image-20230205081930800.png)

![image-20230205082033210](assets/image-20230205082033210.png)





### 1.4.3 自定义权限组件

django内置的不够通用且集成在admin中，所以一般不会在公司的项目中直接应用。

可以自定义权限组件：

- 文档

  ```
  https://www.cnblogs.com/wupeiqi/tag/crm%E9%A1%B9%E7%9B%AE/
  ```

- 视频

  ```
  链接: https://pan.baidu.com/s/1UJ51lZqzcgcy9tgC_dmqTg 提取码: pll4 
  ```

  



# 2.权限案例

- 基于配置文件的权限（订单系统）
- 基于数据的权限（crm系统）



























