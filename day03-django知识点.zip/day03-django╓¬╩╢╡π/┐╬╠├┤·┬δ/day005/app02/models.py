from django.db import models


# Create your models here.

class XX(models.Model):
    count = models.IntegerField(verbose_name="数量")
