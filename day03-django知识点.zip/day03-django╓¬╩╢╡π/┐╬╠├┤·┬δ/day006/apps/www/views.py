from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse

from django.urls.resolvers import ResolverMatch


def login(request):
    print(request.resolver_match)
    return HttpResponse("欢迎登陆")


def info(request, v1):
    print(v1)
    print(request.GET)
    return HttpResponse("欢迎登陆")


def other(request, v1, v2):
    print(v1)
    print(v2)
    return HttpResponse("欢迎登陆")


def xx(request, v2):
    print(v2)
    return HttpResponse("欢迎登陆")


def yy(request, a1, a2, a3):
    print(a1, a2, a3)
    return HttpResponse("欢迎登陆")
