"""
URL configuration for day006 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from apps.www import views

from django.urls import URLPattern, ResolverMatch
from django.urls.resolvers import RoutePattern


class MyRoutePattern(RoutePattern):

    def match(self, path):
        match = self.regex.search(path)
        if match:
            # RoutePattern doesn't allow non-named groups so args are ignored.
            kwargs = match.groupdict()
            for key, value in kwargs.items():
                converter = self.converters[key]
                try:
                    kwargs[key] = converter.to_python(value)
                except ValueError:
                    return None
            return path[match.end():], (), kwargs
        return None


class MyURLPattern(URLPattern):

    def resolve(self, path):
        # login/
        match = self.pattern.match(path)
        if match:
            new_path, args, captured_kwargs = match
            # Pass any default args as **kwargs.
            kwargs = {**captured_kwargs, **self.default_args}
            return ResolverMatch(
                self.callback,
                args,
                kwargs,
                self.pattern.name,
                route=str(self.pattern),
                captured_kwargs=captured_kwargs,
                extra_kwargs=self.default_args,
            )


urlpatterns = [
    # MyURLPattern.resolve   -> RoutePattern.match
    MyURLPattern(MyRoutePattern("login/", name=None, is_endpoint=True), views.login, None, None),

    # URLPattern.resolve   -> RoutePattern.match
    URLPattern(RoutePattern("login/", name=None, is_endpoint=True), views.login, None, None),

    # resolve -> RoutePattern.match
    path('login/', views.login),  # resolve

    # http://127.0.0.1:8000  /info/2222/
    # http://127.0.0.1:8000  /info/2222/?a1=1&b1=2
    # path('info/<int:v1>/', views.info),

    # http://127.0.0.1:8000/other/11/wupeiqi/
    # http://127.0.0.1:8000/other/222/alex/
    # path('other/<int:v1>/<str:v2>/', views.other),

    # path('xx/<path:v2>/', views.xx),
    # path('xx/<uuid:v2>/', views.xx),

    # http://127.0.0.1:8000/yy/2014-11-11
    # re_path(r'yy/(\d{4})-(\d{2})-(\d{2})/', views.yy),
]
