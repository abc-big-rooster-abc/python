# http://www.chinatelecom.com.cn/news/

import socket

client = socket.socket()
# 链接服务器
client.connect(('www.chinatelecom.com.cn', 80))

# 构建请求包
content_list = []
content_list.append("GET /news/ HTTP/1.1\r\n")
content_list.append("host: www.chinatelecom.com.cn\r\n")
content_list.append("\r\n")
content_string = "".join(content_list)

# 向服务器发送
client.sendall(content_string.encode('utf-8'))

# 读取服务端返回的数据
chunk = client.recv(8096)
header, body = chunk.split(b"\r\n\r\n", maxsplit=1)

print(header.decode('utf-8'))
print(body.decode('utf-8'))

# 关闭
client.close()