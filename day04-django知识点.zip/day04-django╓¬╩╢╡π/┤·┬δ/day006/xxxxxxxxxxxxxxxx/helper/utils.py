
CITY = "北京"

def md5():
    return 123


def encrypt():
    return 999