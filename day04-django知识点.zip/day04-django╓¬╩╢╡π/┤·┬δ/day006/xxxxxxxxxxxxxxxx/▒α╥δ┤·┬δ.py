namespace = {'name': 'wupeiqi', 'data': [18, 73, 84]}
code = '''def hellocute():return  "name %s ,age %d" %(name,data[0],) '''
func = compile(code, '<string>', "exec")
exec(func, namespace)
result = namespace['hellocute']()
print(result)


info="""
def _execute():
    _buffer = []
    _buffer.append("<h1>")
    _buffer.append(name)
    _buffer.append("123")
    _buffer.append("</h1>")
    return "".join(_buffer)
"""
func = compile(info, '<string>', "exec")
exec(func, namespace)
result = namespace['_execute']()
print(result)
