# import importlib
#
# # 模块级别（py文件）
# utils = importlib.import_module("helper.utils")
#
# v1 = getattr(utils, "CITY", None)
# print(v1)
#
# v2 = getattr(utils, "md5")
# print(v2)
# result = v2()
# print(result)


# import importlib
from importlib import import_module
path = "apps.www.apps.WwwConfig"
md_path, cls_name = path.rsplit(".", maxsplit=1)

# 模块级别（py文件）
# md = importlib.import_module("apps.www.apps")
md = import_module(md_path)

# cls = getattr(md, "WwwConfig")
cls = getattr(md, cls_name)
