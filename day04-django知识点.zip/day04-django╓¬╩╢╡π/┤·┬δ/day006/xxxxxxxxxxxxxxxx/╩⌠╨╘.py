# class Info:
#
#     @property
#     def f1(self):
#         return 999
#
#     def _get_post(self):
#         return 123
#
#     def _set_post(self, x):
#         return 123
#
#     POST = property(_get_post, _set_post)
#
#
# obj = Info()
# ret = obj.POST
# obj.POST = 123
# print(ret)
import json

info = {"status": True, "name": "武沛齐"}
c = json.dumps(info,ensure_ascii=False)
print(c)