from django.urls import path
from apps.www import views

urlpatterns = [
    path('index/', views.login),
    path('info/', views.login)
]

