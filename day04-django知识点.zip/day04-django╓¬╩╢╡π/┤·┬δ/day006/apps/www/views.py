import datetime

from django.shortcuts import render
from django.http import HttpResponse
from django.views import View


def login(request):
    if request.method == "GET":
        pass
    elif request.method == "POST":
        pass
    elif request.method == "PUT":
        pass
    return HttpResponse("欢迎登陆")


class UserView(View):

    def get(self, request):
        return HttpResponse("User GET")

    def post(self, request):
        return HttpResponse("User POST")

    def put(self, request):
        return HttpResponse("User POST")

    def delete(self, request):
        return HttpResponse("User POST")


def info(request, v1):
    # 去request和参数中读取请求相关数据
    # 业务处理（登录、注册、上传Excel、删除数据库）
    # ...
    # 得到结果
    result = {"status": True, "name": "武沛齐"}

    from django.http import HttpResponse
    from django.http import JsonResponse
    from django.shortcuts import render, redirect

    # `构建` 响应体和响应头
    # return HttpResponse("中国北京")
    # return JsonResponse({"status": True, "name": "武沛齐"}, json_dumps_params={"ensure_ascii": False})
    # return render(request, "demo.txt")
    return redirect("https://www.baidu.com", permanent=False)  # 301/302


class MineView(View):
    def get(self, request, *args, **kwargs):
        print(request, *args, **kwargs)
        print(self.request, self.args, self.kwargs)
        return HttpResponse("....")


def text(request, *args, **kwargs):
    pass


def demo(request):
    title = "测试"
    return render(request, "demo.html", {'title': title})


def order(request):
    title = "订单"
    return render(request, "order.html", {'title': title})


def excel(request):
    title = "批量导入"
    return render(request, "excel.html", {'title': title})


def nb(request):
    # 1.读取nb.html文件的内容
    # 2.渲染=替换，替换完成后
    # 3.将替换后的值封装HttpReponse
    # 4.以响应体的方式返回到浏览器的界面

    # return render(request, "nb.html", {'info': 999})
    # return render(request, "nb.html", {'info': "张开"})
    # return render(request, "nb.html", {'info': [11, 22, 33, 44]})
    return render(
        request,
        "nb.html",
        {
            'num': [11, 22, 33, 44],
            "name": "zhangkai",
            'ctime': datetime.datetime.now()
        }
    )
