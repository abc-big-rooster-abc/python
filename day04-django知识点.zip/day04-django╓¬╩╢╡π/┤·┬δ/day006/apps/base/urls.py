from django.urls import path
from apps.base import views

urlpatterns = [
    path('user1/', views.user,name='v3'),
    path('user2/', views.user,name='v4')
]
