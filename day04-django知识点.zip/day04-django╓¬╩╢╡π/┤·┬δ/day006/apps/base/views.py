from django.shortcuts import render, HttpResponse
from django.urls import reverse

def user(request):
    # url = reverse("web:v2")
    # print(url)
    return HttpResponse("user")
