from django.shortcuts import render, HttpResponse
from django import forms
from app01 import models


class BootStrapForm(object):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs = {"class": "form-control"}


class LoginForm(forms.Form):
    username = forms.CharField(label="用户名", required=True, widget=forms.TextInput)
    pwd = forms.CharField(label="密码", required=True, widget=forms.PasswordInput)


class LoginFormParent(LoginForm):
    username = forms.CharField(label="密码", required=True, widget=forms.PasswordInput)


class LoginFormExt(LoginFormParent):
    code = forms.CharField(label="密码", required=True, widget=forms.PasswordInput)


def login(request):
    if request.method == "GET":
        form = LoginForm()
        return render(request, 'login2.html', {"form": form})
    form = LoginForm(data=request.POST)
    if not form.is_valid():
        return render(request, 'login2.html', {"form": form})

    # 校验成功
    # print(form.cleaned_data) # {'username': '123', 'pwd': '123'}
    exists = models.User.objects.filter(username=form.cleaned_data['username'],
                                        password=form.cleaned_data['pwd']).exists()
    if not exists:
        # 主动在form中添加一个错误
        form.add_error("pwd", "用户名或密码错误")
        return render(request, 'login2.html', {"form": form, 'msg': "用户名或密码错误"})
    else:
        # 用户信息保存Session、Cookie返回凭证
        return HttpResponse("登录成功")


class UserAddModelForm(forms.ModelForm):
    x1 = forms.CharField(label="测试")

    class Meta:
        model = models.User
        fields = ["username", "password", "age", "email", "x1"]
        # fields = "__all__"
        # exclude = ["password"]


def user_add(request):
    if request.method == "GET":
        form = UserAddModelForm()
        return render(request, "user_add2.html", {"form": form})
    form = UserAddModelForm(data=request.POST)
    if not form.is_valid():
        return render(request, "user_add2.html", {"form": form})

    # 校验成功
    form.instance.phone = "12123"
    form.save()

    return HttpResponse("新建成功")


class UserEditModelForm(forms.ModelForm):
    class Meta:
        model = models.User
        fields = "__all__"


def user_edit(request, nid):
    if request.method == "GET":
        # 去数据库获取这一行数据
        user_object = models.User.objects.filter(id=nid).first()
        form = UserEditModelForm(instance=user_object)
        return render(request, 'user_edit2.html', {"form": form})

    user_object = models.User.objects.filter(id=nid).first()
    form = UserEditModelForm(data=request.POST, instance=user_object)
    if not form.is_valid():
        return render(request, "user_edit2.html", {"form": form})

    # 校验成功
    form.save()

    return HttpResponse("修改成功")
