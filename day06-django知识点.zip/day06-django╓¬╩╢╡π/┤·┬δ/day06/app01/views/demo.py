from django.shortcuts import render, HttpResponse
from django import forms
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from app01 import models


class RegisterForm(forms.Form):
    v1 = forms.CharField(
        label="手机号",
        required=True,
        # max_length=19,
        # min_length=6,
        initial="武沛齐",
        validators=[RegexValidator(r'^\d{11}$', "手机号格式错误"), ],
        widget=forms.TextInput(attrs={"id": "xx1"})
    )
    v2 = forms.CharField(
        label="备注",
        required=True,
        widget=forms.Textarea
    )

    # 钩子方法 = Hook 方法
    def clean_v1(self):
        value = self.cleaned_data['v1']

        # 根据value去数据库进行校验：链接数据、根据value校验是否存在，不存在
        # raise ValidationError("手机号已存在")
        # raise forms.ValidationError

        return value


def register(request):
    if request.method == "GET":
        # form = RegisterForm(initial={"v1": "武沛齐", "v2": "张开"})
        form = RegisterForm()
        return render(request, 'register.html', {'form': form})

    form = RegisterForm(data=request.POST)
    if form.is_valid():
        # 成功 {'v1': '111', 'v2': '222'}
        print(form.cleaned_data)
        return HttpResponse("成功")
    else:
        # 最后汇总环节
        # 失败 {"v1":["这个字段是必填项。"], "v2":["This field is required."]}
        print(form.errors)
        print(type(form.errors))  # django.forms.utils.ErrorDict
        from django.forms.utils import ErrorDict

        return render(request, 'register.html', {'form': form})


class BootStrapForm(object):
    def __init__(self, *args, **kwargs):
        # 不是找父类
        # 根据类的mro（继承关系），去找上个类
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            # field.widget.attrs
            field.widget.attrs = {"class": "form-control"}


# class BootStrapForm(forms.Form):
#     def __init__(self, *args, **kwargs):
#         # 不是找父类
#         # 根据类的mro（继承关系），去找上个类
#         # super().__init__(*args, **kwargs)
#         for name, field in self.fields.items():
#             field.widget.attrs = {"class": "form-control"}

class LoginForm(BootStrapForm, forms.Form):
    user = forms.CharField(label="用户名", widget=forms.TextInput)
    pwd = forms.CharField(label="密码", widget=forms.TextInput)


class LoginModelForm(BootStrapForm, forms.ModelForm):
    mobile = forms.CharField(label="手机号", widget=forms.TextInput)

    class Meta:
        model = models.UserInfo
        fields = ["name", "age", "mobile"]
        widgets = {
            "age": forms.TextInput,
        }
        labels = {
            "age": "x2",
        }

    def clean_name(self):
        value = self.cleaned_data['name']
        # raise ValidationError("....")
        return value


def login(request):
    user_object = models.UserInfo.objects.filter(id=1).first()
    form = LoginModelForm(instance=user_object, initial={"mobile": "武沛齐"})
    return render(request, "login.html", {"form": form})
