from django.shortcuts import HttpResponse, render
from django.template.loader import get_template

from django import forms


def v1(request):
    template = get_template("v1.html")
    text = template.render({"text": "张开"}, request)
    print(text)

    return HttpResponse("OK")


def v2(request):
    # 1.执行 TextInput的 __init__方法
    obj = forms.TextInput(attrs={'class': "c1", "id": "xx1"})
    data_string = obj.render(name="user", value="张开")
    print(data_string)  # <input type='text' name='user' value="张开" class="c1"  id="xx1" />

    obj2 = forms.PasswordInput(attrs={'class': "c2"}, render_value=True)
    data_string = obj2.render(name="user", value="张开")
    print(data_string)

    return HttpResponse("OK")


class LoginForm(forms.Form):
    username = forms.CharField(label="用户名", required=True, widget=forms.TextInput)
    pwd = forms.CharField(label="密码", required=True, widget=forms.PasswordInput)


def v3(request):
    if request.method == "GET":
        form = LoginForm()
        return render(request, "v3.html", {"form": form})

    # 表单的验证？
    # form = LoginForm(data=request.POST)
    # if not form.is_valid():
    #     return render(request, 'login2.html', {"form": form})