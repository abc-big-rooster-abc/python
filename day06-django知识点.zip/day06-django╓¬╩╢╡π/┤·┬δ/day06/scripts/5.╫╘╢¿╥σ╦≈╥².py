class Foo(object):

    def __getitem__(self, item):
        return 999


obj = Foo()

print(obj)
print(obj['xxxx'])
