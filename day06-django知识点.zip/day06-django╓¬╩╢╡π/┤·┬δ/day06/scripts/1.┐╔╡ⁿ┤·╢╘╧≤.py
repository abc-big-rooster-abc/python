class MyForm(object):

    def __str__(self):
        return "<form>...</form>"

    def __iter__(self):
        return iter([11, 22, 33, 44])


obj = MyForm()
print(obj)  # <__main__.MyForm object at 0x0000026D5A9B6760>
print(obj)  # <form>...</form>

# 'MyForm' object is not iterable（可迭代对象、迭代器、生成器）
for item in obj:
    print(item)
