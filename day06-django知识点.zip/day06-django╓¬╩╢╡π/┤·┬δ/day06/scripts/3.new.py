class Foo(object):
    def __init__(self, name):
        print("init初始化", self)
        self.name = name

    def __new__(cls, *args, **kwargs):
        obj = super().__new__(cls)
        print("new创建对象", obj)
        return obj


instance = Foo("wupeiqi")
print("得到对象", instance)
