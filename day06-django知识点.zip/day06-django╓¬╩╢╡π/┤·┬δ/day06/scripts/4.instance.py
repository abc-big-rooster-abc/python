class Field(object):
    pass


class CharField(Field):
    pass


class EmailField(Field):
    pass


class ImageField(Field):
    pass


obj1 = CharField()
obj2 = EmailField()
obj3 = ImageField()

print(isinstance(obj1, Field))
print(isinstance(obj2, Field))
print(isinstance(obj3, Field))
