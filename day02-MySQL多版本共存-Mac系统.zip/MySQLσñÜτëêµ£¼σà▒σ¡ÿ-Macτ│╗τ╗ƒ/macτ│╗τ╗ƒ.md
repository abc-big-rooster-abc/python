# MySQL多版本共存（Mac系统）

想要在Mac系统上同时安装【MySQL5.7 】+【**MySQL8.0**】版本，需要进行如下的操作和配置。

想要同时安装两个版本可以采取如下方案：

- 方案1：【讲解】

  ```
  MySQL57，用安装包进行安装。
  MySQL80，用压缩包进行免安装处理。
  ```

- 方案2：

  ```
  MySQL57，用压缩包进行免安装处理。
  MySQL80，用压缩包进行免安装处理。
  ```

如果使用安装包的形式会将MySQL安装到 `/usr/local/mysql` 目录下，所以，两个版本都使用安装的话，会导致老版本自动卸载。













# 1.MySQL5.7



## 第1步：安装和初始化

https://downloads.mysql.com/archives/community/

<img src="../../../../../路飞学城相关/视频-全栈开发v2/课件-路飞全栈开发v2/day25 MySQL入门/笔记/assets/image-20210508103830229.png" alt="image-20210508103830229"  />

<img src="../../../../../路飞学城相关/视频-全栈开发v2/课件-路飞全栈开发v2/day25 MySQL入门/笔记/assets/image-20210508165414794.png" alt="image-20210508165414794" style="zoom:50%;" />



<img src="../../../../../路飞学城相关/视频-全栈开发v2/课件-路飞全栈开发v2/day25 MySQL入门/笔记/assets/image-20210508171059416.png" alt="image-20210508171059416" style="zoom:50%;" />



这个基于dmg文件的安装过程，其实包含了：

```
/usr/local/mysql/
/usr/local/mysql-5.7.31-macos10.14-x86_64/
```

- 安装，默认安装在了 `/usr/local/mysql-5.7.31-macos10.14-x86_64/`目录。
- 初始化，在安装目录下创建data目录用于存放数据； 初始化模块数据库以及账户相关等，例如： 账cd

![image-20210510103342842](assets/image-20210510103342842.png)



## 第2步：创建配置文件

```
/usr/local/mysql
/usr/local/mysql-5.7.31-macos10.14-x86_64
```

![image-20230619003013005](assets/image-20230619003013005.png)



```
[mysqld]

port=3306

basedir=/usr/local/mysql

datadir=/usr/local/mysql/data

socket=/tmp/mysql57.sock

user=root
```



为了避免多个版本共存时，配置文件混乱的问题，建议大家还是把配置文件放在当前MySQL的安装目录下。



## 第3步：启动和环境变量

在Mac系统中启动MySQL常见的有2种方式：

- 安装目录中自带 `mysql.server` 脚本（建议）

  ```python
  sudo /usr/local/mysql/support-files/mysql.server start
  # 输入电脑密码
  
  sudo mysql.server start
  # 输入电脑密码
  ```

  ```
  sudo /usr/local/mysql/support-files/mysql.server stop
  ```

  ![image-20210510162854578](assets/image-20210510162854578.png)


  为了避免每次执行命令都需要些路径，可以将路径 `/usr/local/mysql/support-files`加入到环境变量中。

![image-20210510165107737](assets/image-20210510165107737.png)

  操作完成之后，再在终端执行下命令：`source ~/.zprofile` 让设置的环境变量立即生效。

```
export PATH=$PATH:/usr/local/mysql/support-files
export PATH=$PATH:/usr/local/mysql/bin
```



  注意：mac系统的版本如果比较老，会显示空白的 `zprofile` 文件，此就要去打开   `bash_profile` 文件。


  这样设置好之后，以后就可以使用下面的命令去启动和关闭MySQL了。

  ```
sudo mysql.server start
sudo mysql.server stop
  ```

  

- 系统偏好设置（不推荐）

<img src="../../../../../路飞学城相关/视频-全栈开发v2/课件-路飞全栈开发v2/day25 MySQL入门/笔记/assets/image-20210510104009559.png" alt="image-20210510104009559" style="zoom: 33%;" />





第一种`mysql.server`脚本的形式，内部是使用 `mysqld_safe`运行，可以守护我们的MySQL进程，如意外挂掉可自动重启。



## 第4步：连接&设置密码

安装并启动MySQL之后，就可以连接MySQL来测试是否已正确安装并启动成功。

![image-20210510153336093](assets/image-20210510153336093.png)

以后在开发时，肯定是要用Python代码来连接MySQL并且进行数据操作（后面讲）。

在安装MySQL时，其实也自动安装了一个工具（客户端），让我们快速实现连接MySQL并发送指令。

![image-20230619003148961](assets/image-20230619003148961.png)

```
mysql --socket=/tmp/mysql57.sock -u root -p
```

```
set password=password("root123");
```

注意：`/usr/local/mysql/bin`也可以加入到环境变量。



至此，在Mac系统中关于MySQL的安装和配置就完成了。



# 2.MySQL8.0

## 第1步：下载和解压

https://downloads.mysql.com/archives/community/

![image-20230618224457417](assets/image-20230618224457417.png)

![image-20230618224956749](assets/image-20230618224956749.png)



## 第2步：创建配置文件

![image-20230619003235780](assets/image-20230619003235780.png)

```
[mysqld]

port=3307

basedir=/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64

datadir=/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64/data

socket=/tmp/mysql80.sock

user=root
```



## 第3步：初始化

```
/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64/bin/mysqld   --initialize-insecure
```

![image-20230618231122072](assets/image-20230618231122072.png)





## 第4步：修改mysql.server

默认`mysql.server`管理的是 `/usr/local/mysql`目录下的MySQL进程（MySQL5.7），所以需要对他进行修改才能让他去管理我们的MySQL8.0。

- 原文件

  ```
  basedir=
  datadir=
  ```

- 修改后

  ```
  basedir=/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64/
  datadir=/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64/data/
  ```

![image-20230618230304334](assets/image-20230618230304334.png)



## 第5步：环境变量和启动

```
export PATH=$PATH:/Users/wupeiqi/service/mysql-8.0.33-macos13-x86_64/support-files
```

![image-20230618230529496](assets/image-20230618230529496.png)



为了防止冲突，再改个名字，修改为：`mysql8.server`

![image-20230618230603662](assets/image-20230618230603662.png)



启动服务：

```
sudo mysql8.server start
```

![image-20230618231310702](assets/image-20230618231310702.png)







## 第6步：连接&设置密码

```
mysql --socket=/tmp/mysql80.sock -u root -P 3307 -p
```

```
ALTER USER 'root'@'localhost' IDENTIFIED WITH MYSQL_NATIVE_PASSWORD BY 'root123';
```

![image-20230619003402121](assets/image-20230619003402121.png)





















